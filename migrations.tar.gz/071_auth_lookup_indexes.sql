-- +goose Up
-- SaaS's per-tenant databases mean users/api_keys/password_reset_tokens no
-- longer live in one shared database services/auth can query directly by
-- email / key hash / reset token — those are exactly the identifiers auth
-- has to resolve BEFORE it knows which org (and therefore which tenant
-- database) it's even looking at. These three tables are thin, control-plane
-- routing indexes only: they answer "which org/tenant database owns this
-- identifier," never the authoritative record itself — every read still
-- re-verifies the real row (password hash, revoked_at, expires_at, etc.)
-- against the resolved tenant database. Self-hosted never populates these
-- (it has one org and queries its single database directly, unchanged).
CREATE TABLE IF NOT EXISTS user_login_index (
    user_id TEXT PRIMARY KEY,
    org_id  TEXT NOT NULL,
    email   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_user_login_index_email ON user_login_index (email);

CREATE TABLE IF NOT EXISTS api_key_index (
    key_hash TEXT PRIMARY KEY,
    org_id   TEXT NOT NULL,
    key_id   TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_api_key_index_org_key ON api_key_index (org_id, key_id);

CREATE TABLE IF NOT EXISTS password_reset_index (
    token_hash TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL,
    token_id   TEXT NOT NULL,
    user_id    TEXT NOT NULL
);

-- +goose Down
DROP TABLE IF EXISTS password_reset_index;
DROP TABLE IF EXISTS api_key_index;
DROP TABLE IF EXISTS user_login_index;
