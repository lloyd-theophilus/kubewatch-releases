-- +goose Up
-- agent_token_index is a control-plane routing index, same shape and purpose
-- as 071_auth_lookup_indexes.sql's user_login_index/api_key_index: agent_id
-- (from an Authorization: Bearer <token> push, see services/ingestion's
-- validateAgentToken) carries no org_id of its own once agents live in a
-- per-tenant database, so this maps it to the org whose tenant database
-- holds the real agents row. It is a router only — the actual token_hash
-- check still happens against that tenant row, never trusted from here
-- alone. Self-hosted-compatible (harmless/unused there, exactly like the
-- three tables in 071).
CREATE TABLE IF NOT EXISTS agent_token_index (
    agent_id TEXT PRIMARY KEY,
    org_id   TEXT NOT NULL
);

-- +goose Down
DROP TABLE IF EXISTS agent_token_index;
