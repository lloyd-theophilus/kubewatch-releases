-- +goose Up
-- Disaster recovery: scheduled Postgres backups (services/backup's loop,
-- see installer/docker-compose.selfhost.yml) uploaded to S3-compatible
-- object storage, plus an automated restore-test that verifies each backup
-- by restoring it into a scratch database on the same Postgres server (never
-- the real "kubewatch" database) and checking a basic row count, before
-- dropping the scratch database again. Self-hosted only for now (gated the
-- same way "Update Now" is, via KUBEWATCH_MODE) — instance-wide, not
-- per-org, since a single Postgres database backs every org on the instance.
CREATE TABLE IF NOT EXISTS dr_backups (
    id TEXT PRIMARY KEY,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'running', -- running | success | failed
    size_bytes BIGINT,
    s3_key TEXT,
    error TEXT,
    triggered_by TEXT NOT NULL DEFAULT 'scheduled' -- scheduled | manual
);

CREATE TABLE IF NOT EXISTS dr_restore_tests (
    id TEXT PRIMARY KEY,
    backup_id TEXT REFERENCES dr_backups(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at TIMESTAMPTZ,
    status TEXT NOT NULL DEFAULT 'running', -- running | passed | failed
    error TEXT,
    verified_org_count INTEGER
);

CREATE INDEX IF NOT EXISTS idx_dr_backups_started_at ON dr_backups (started_at DESC);
CREATE INDEX IF NOT EXISTS idx_dr_restore_tests_backup_id ON dr_restore_tests (backup_id);

-- +goose Down
DROP TABLE IF EXISTS dr_restore_tests;
DROP TABLE IF EXISTS dr_backups;
