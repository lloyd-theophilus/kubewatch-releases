-- +goose Up
-- Per-destination backup outcomes: an instance can push each backup to more
-- than one destination at once (e.g. S3 AND SFTP for redundancy), configured
-- via a comma-separated BACKUP_DESTINATIONS env var (see the "backup"
-- compose service and services/query/backup.go) — one row here per
-- destination actually attempted for a given backup. dr_backups.status
-- reflects the overall outcome (pg_dump itself, plus whether at least one
-- destination succeeded); this table has the per-destination detail.
-- dr_backups.s3_key/error predate multi-destination support and are no
-- longer written to, superseded by this table's "location"/"error" per row;
-- left in place rather than dropped since they're harmless nullable columns.
CREATE TABLE IF NOT EXISTS dr_backup_destinations (
    id TEXT PRIMARY KEY,
    backup_id TEXT NOT NULL REFERENCES dr_backups(id) ON DELETE CASCADE,
    kind TEXT NOT NULL, -- s3 | sftp | webhook | azure
    status TEXT NOT NULL DEFAULT 'running', -- running | success | failed
    location TEXT, -- s3 key / sftp remote path / azure blob URL / webhook note
    error TEXT,
    completed_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_dr_backup_destinations_backup_id ON dr_backup_destinations (backup_id);

-- +goose Down
DROP TABLE IF EXISTS dr_backup_destinations;
