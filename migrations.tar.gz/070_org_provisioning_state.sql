-- +goose Up
-- Tracks per-org SaaS database-per-tenant provisioning (see shared/db
-- package). db_name is the tenant's Postgres database name (== the org id
-- itself today; kept as its own column rather than assumed, so a later
-- phase could repoint an org at a different physical database without a
-- data model change). db_provisioned_at is set once the tenant database and
-- its admin user both exist. Self-hosted ignores both columns — it never
-- provisions a per-org database, so they stay NULL there, harmlessly.
--
-- `status` also gains two new values used during signup/creation:
-- 'provisioning' (org row exists, tenant database not ready yet) and
-- 'provisioning_failed' (tenant database creation or migration failed).
-- `status` has always been a free-form TEXT column with no CHECK
-- constraint, so no schema change is needed for the new values themselves.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS db_name TEXT;
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS db_provisioned_at TIMESTAMPTZ;

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS db_name;
ALTER TABLE organizations DROP COLUMN IF EXISTS db_provisioned_at;
