-- +goose Up
-- User-chosen retention window, independent of the plan ceiling enforced in
-- services/query/metrics.go's retentionDaysForPlan -- NULL means "use my
-- plan's default", set means "cap my own history at this many days even if
-- my plan allows more" (never the other way around: the effective window is
-- always min(this value, the plan ceiling), enforced in application code,
-- not this constraint). Fixed set of choices, not a free-form number, to
-- keep the UI and the enforcement code in exact agreement.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS retention_preference_days INTEGER
    CHECK (retention_preference_days IS NULL OR retention_preference_days IN (30, 90, 180));

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS retention_preference_days;
