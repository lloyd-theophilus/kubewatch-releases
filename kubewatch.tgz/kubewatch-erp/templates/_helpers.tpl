{{/*
Expand the name of the chart.
*/}}
{{- define "kubewatch-erp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kubewatch-erp.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Common labels applied to every resource in this chart.
Usage: {{ include "kubewatch-erp.labels" . | nindent 4 }}
*/}}
{{- define "kubewatch-erp.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ include "kubewatch-erp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels (subset used in matchLabels / Service selectors).
Usage: {{ include "kubewatch-erp.selectorLabels" (dict "root" . "component" "gateway") | nindent 6 }}
*/}}
{{- define "kubewatch-erp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubewatch-erp.name" .root }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Resolve the VictoriaMetrics insert URL — prefer external override, fall back to in-cluster service.
*/}}
{{- define "kubewatch-erp.vmInsertURL" -}}
{{- if .Values.victoriametrics.externalInsertURL -}}
{{- .Values.victoriametrics.externalInsertURL -}}
{{- else -}}
http://{{ .Release.Name }}-victoriametrics:8480
{{- end -}}
{{- end }}

{{/*
Resolve the VictoriaMetrics select URL — prefer external override, fall back to in-cluster service.
*/}}
{{- define "kubewatch-erp.vmSelectURL" -}}
{{- if .Values.victoriametrics.externalSelectURL -}}
{{- .Values.victoriametrics.externalSelectURL -}}
{{- else -}}
http://{{ .Release.Name }}-victoriametrics:8481
{{- end -}}
{{- end }}

{{/*
Resolve the VictoriaLogs URL — prefer external override, fall back to in-cluster service.
*/}}
{{- define "kubewatch-erp.vlURL" -}}
{{- if .Values.victorialogs.externalURL -}}
{{- .Values.victorialogs.externalURL -}}
{{- else -}}
http://{{ .Release.Name }}-victorialogs:9428
{{- end -}}
{{- end }}

{{/*
Resolve the NATS URL — prefer external override, fall back to in-cluster service.
*/}}
{{- define "kubewatch-erp.natsURL" -}}
{{- if .Values.nats.externalURL -}}
{{- .Values.nats.externalURL -}}
{{- else -}}
nats://{{ .Release.Name }}-nats:4222
{{- end -}}
{{- end }}
