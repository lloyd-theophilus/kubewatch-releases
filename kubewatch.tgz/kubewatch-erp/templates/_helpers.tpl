{{/*
Expand the name of the chart.
*/}}
{{- define "kubewatch-erp.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kubewatch-erp.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{/*
Common labels applied to every resource in this chart.
Usage: {{ include "kubewatch-erp.labels" . | nindent 4 }}
*/}}
{{- define "kubewatch-erp.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ include "kubewatch-erp.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels (subset used in matchLabels / Service selectors).
Usage: {{ include "kubewatch-erp.selectorLabels" (dict "root" . "component" "gateway") | nindent 6 }}
*/}}
{{- define "kubewatch-erp.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubewatch-erp.name" .root }}
app.kubernetes.io/instance: {{ .root.Release.Name }}
app.kubernetes.io/component: {{ .component }}
{{- end }}

{{/*
Resolve the Mimir write (remote_write) URL -- this is the distributor's own
endpoint, the only component that accepts writes. Prefer an external
override, fall back to in-cluster service. mimir replaces victoriametrics
as of the Mimir migration, so guard against the key being absent entirely
on a `helm upgrade --reuse-values` against a release that predates it.
*/}}
{{- define "kubewatch-erp.mimirWriteURL" -}}
{{- $mimir := default dict .Values.mimir -}}
{{- if $mimir.externalWriteURL -}}
{{- $mimir.externalWriteURL -}}
{{- else -}}
http://{{ .Release.Name }}-mimir-distributor:8080
{{- end -}}
{{- end }}

{{/*
Resolve the Mimir read (Prometheus query API) URL -- this is the
query-frontend's own endpoint (Mimir 3.x has no direct frontend<->querier
mode; both go through query-scheduler instead, see infrastructure.yaml's
mimir-config ConfigMap). Prefer an external override, fall back to
in-cluster service. Same guard reasoning as mimirWriteURL above.
*/}}
{{- define "kubewatch-erp.mimirReadURL" -}}
{{- $mimir := default dict .Values.mimir -}}
{{- if $mimir.externalReadURL -}}
{{- $mimir.externalReadURL -}}
{{- else -}}
http://{{ .Release.Name }}-mimir-query-frontend:8080
{{- end -}}
{{- end }}

{{/*
Resolve the Loki write (push API) URL -- this is the distributor's own
endpoint, the only component that accepts writes. Prefer an external
override, fall back to in-cluster service. loki replaces victorialogs as of
the Loki migration, so guard against the key being absent entirely on a
`helm upgrade --reuse-values` against a release that predates it -- same
reasoning as mimirWriteURL above.
*/}}
{{- define "kubewatch-erp.lokiWriteURL" -}}
{{- $loki := default dict .Values.loki -}}
{{- if $loki.externalWriteURL -}}
{{- $loki.externalWriteURL -}}
{{- else -}}
http://{{ .Release.Name }}-loki-distributor:3100
{{- end -}}
{{- end }}

{{/*
Resolve the Loki read (query API) URL -- this is the query-frontend's own
endpoint (Loki 3.x has no direct frontend<->querier mode; both go through
query-scheduler instead, see infrastructure.yaml's loki-config ConfigMap).
Prefer an external override, fall back to in-cluster service. Same guard
reasoning as mimirReadURL above.
*/}}
{{- define "kubewatch-erp.lokiReadURL" -}}
{{- $loki := default dict .Values.loki -}}
{{- if $loki.externalReadURL -}}
{{- $loki.externalReadURL -}}
{{- else -}}
http://{{ .Release.Name }}-loki-query-frontend:3100
{{- end -}}
{{- end }}

{{/*
Env entries every Mimir component container needs to expand mimir.yaml's
${MIMIR_S3_ENDPOINT}/${MIMIR_S3_ACCESS_KEY}/${MIMIR_S3_SECRET_KEY} placeholders
(via -config.expand-env=true) -- sourced from the Secret (secret.yaml),
never inlined directly here, since the access/secret key are credentials.
Usage: {{ include "kubewatch-erp.mimirS3Env" . | nindent 12 }}
*/}}
{{- define "kubewatch-erp.mimirS3Env" -}}
- name: MIMIR_S3_ENDPOINT
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: MIMIR_S3_ENDPOINT
- name: MIMIR_S3_ACCESS_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: MIMIR_S3_ACCESS_KEY
- name: MIMIR_S3_SECRET_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: MIMIR_S3_SECRET_KEY
{{- end }}

{{/*
Env entries every Loki component container needs to expand loki.yaml's
${LOKI_S3_ENDPOINT}/${LOKI_S3_ACCESS_KEY}/${LOKI_S3_SECRET_KEY} placeholders
(via -config.expand-env=true) -- sourced from the Secret (secret.yaml),
never inlined directly here, since the access/secret key are credentials.
Same shape as mimirS3Env above.
Usage: {{ include "kubewatch-erp.lokiS3Env" . | nindent 12 }}
*/}}
{{- define "kubewatch-erp.lokiS3Env" -}}
- name: LOKI_S3_ENDPOINT
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: LOKI_S3_ENDPOINT
- name: LOKI_S3_ACCESS_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: LOKI_S3_ACCESS_KEY
- name: LOKI_S3_SECRET_KEY
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: LOKI_S3_SECRET_KEY
{{- end }}

{{/*
Env entries for the bundled MinIO StatefulSet and its minio-init Job --
sourced from the Secret (secret.yaml's own MINIO_ROOT_USER/PASSWORD keys,
kept separate from MIMIR_S3_ACCESS_KEY/SECRET_KEY, see that file's
comment), never a literal `value:` -- these are MinIO's actual root
credentials, bucket-wide admin access to every org's metrics blocks, not
just Mimir's own S3 client config.
Usage: {{ include "kubewatch-erp.minioEnv" . | nindent 12 }}
*/}}
{{- define "kubewatch-erp.minioEnv" -}}
- name: MINIO_ROOT_USER
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: MINIO_ROOT_USER
- name: MINIO_ROOT_PASSWORD
  valueFrom:
    secretKeyRef:
      name: {{ .Release.Name }}-secret
      key: MINIO_ROOT_PASSWORD
{{- end }}

{{/*
Resolve the NATS URL — prefer external override, fall back to in-cluster service.
*/}}
{{- define "kubewatch-erp.natsURL" -}}
{{- if .Values.nats.externalURL -}}
{{- .Values.nats.externalURL -}}
{{- else -}}
nats://{{ .Release.Name }}-nats:4222
{{- end -}}
{{- end }}

{{/* Normal Jobs start alongside workloads; init containers wait on their DB
     release marker. A post-install hook would deadlock with helm --wait. */}}
{{- define "kubewatch-erp.schemaInit" -}}
{{- $root := .root -}}
initContainers:
  - name: wait-for-schema
    image: "{{ $root.Values.gateway.image.repository }}:{{ $root.Values.global.imageTag | default $root.Values.gateway.image.tag }}"
    imagePullPolicy: {{ $root.Values.imagePullPolicy }}
    command:
      - /schema-migrate
      - -check
      - -wait=30m
      {{- if has .component (list "auth" "alert-engine" "incidents" "query") }}
      - {{ printf "-notification-url=http://%s-notification:%d/readyz" $root.Release.Name ($root.Values.notification.port | int) | quote }}
      {{- end }}
    envFrom:
      - configMapRef:
          name: {{ $root.Release.Name }}-config
      - secretRef:
          name: {{ $root.Release.Name }}-secret
    securityContext:
      allowPrivilegeEscalation: false
      capabilities:
        drop: ["ALL"]
      seccompProfile:
        type: RuntimeDefault
    resources:
      requests:
        cpu: 10m
        memory: 32Mi
      limits:
        memory: 128Mi
{{- end }}

{{- define "kubewatch-erp.applicationProbes" -}}
startupProbe:
  httpGet:
    path: {{ .live }}
    port: {{ .port }}
  periodSeconds: 5
  timeoutSeconds: 3
  failureThreshold: 60
readinessProbe:
  httpGet:
    path: {{ .ready }}
    port: {{ .port }}
  periodSeconds: 10
  timeoutSeconds: 3
  failureThreshold: 2
livenessProbe:
  tcpSocket:
    port: {{ .port }}
  periodSeconds: 20
  timeoutSeconds: 3
  failureThreshold: 3
{{- end }}
