-- +goose Up
-- Incident Management is a purely SaaS-side feature (no cluster RBAC
-- dimension) — gated the same way as SSO: one plan_limits column, enforced
-- via a fresh DB join in services/incidents rather than a trusted header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS incident_management_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET incident_management_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS incident_management_enabled;
