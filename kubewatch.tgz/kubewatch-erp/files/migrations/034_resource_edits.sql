-- +goose Up
-- Resource edit requests (Read-Write Cluster IDE, Phase 4 — "the risk cliff").
--
-- Unlike scaling_policies (a continuously re-evaluated policy), this is a
-- discrete, user-initiated request: one row per request, mirroring
-- scaling_decisions' append-only audit shape (019_scaling.sql) plus the
-- workflow state a policy row would otherwise carry, since there's no
-- separate "policy" object here to hold that state.
--
-- Mandatory two-person approval is enforced in application code
-- (approved_by must differ from requested_by — see
-- services/live-data/workload_edits.go), not by a SQL constraint, since
-- Postgres has no clean way to express "these two columns, when both set,
-- must differ" without a CHECK that breaks on NULL comparisons.
CREATE TABLE IF NOT EXISTS resource_edits (
    id                 TEXT PRIMARY KEY,   -- edit_<hex>
    org_id             TEXT NOT NULL,
    agent_id           TEXT NOT NULL,
    namespace          TEXT NOT NULL,
    kind               TEXT NOT NULL,      -- Deployment | StatefulSet | DaemonSet
    name               TEXT NOT NULL,
    container          TEXT NOT NULL,      -- which container the image edit targets
    requested_by       TEXT NOT NULL,
    requested_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    requested_image    TEXT,               -- NULL if this edit doesn't change the image
    requested_replicas INTEGER,            -- NULL if this edit doesn't change replicas, or kind=DaemonSet
    previous_state     JSONB NOT NULL,     -- snapshot of {image, replicas} before this edit — rollback source
    approved_by        TEXT,
    approved_at        TIMESTAMPTZ,
    denied_by          TEXT,
    denied_at          TIMESTAMPTZ,
    outcome            TEXT NOT NULL DEFAULT 'pending_approval',
        -- pending_approval | approved_pending_apply | applied | apply_failed | denied
    apply_error        TEXT,
    applied_at         TIMESTAMPTZ,
    reverts_id         TEXT REFERENCES resource_edits(id) -- set when this row rolls back another
);
CREATE INDEX IF NOT EXISTS idx_resource_edits_org_status ON resource_edits (org_id, outcome);
CREATE INDEX IF NOT EXISTS idx_resource_edits_agent ON resource_edits (agent_id, outcome);

-- +goose Down
DROP TABLE IF EXISTS resource_edits;
