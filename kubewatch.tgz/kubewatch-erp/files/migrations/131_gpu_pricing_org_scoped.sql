-- +goose Up
-- gpu_pricing (061_gpu_scaling.sql) was created with no org_id at all,
-- keyed only on gpu_type, and lives in the shared control-plane database
-- (services/query/gpu.go queries it via s.controlDB, never a per-org
-- tenant database). Every org shares the exact same row per GPU type: any
-- authenticated member of ANY org can overwrite or delete another org's
-- self-hosted-hardware amortized cost entry (upsertGPUPricing/
-- deleteGPUPricing have no way to scope by org because the column doesn't
-- exist), corrupting that org's GPU cost dashboard and cost-attribution
-- figures with no error and no audit trail visible to the victim org.
--
-- Fixed by adding org_id and re-keying on (org_id, gpu_type) rather than
-- moving the table into each org's own tenant database -- this table's
-- access pattern (a handful of hand-entered rows, read/written directly by
-- org-scoped HTTP handlers already resolving orgID from the verified
-- request context) fits the same "shared database, org_id-scoped rows"
-- shape organizations/plan_limits/licenses already use in this same
-- database, and a live cross-database data move for an already-deployed
-- SaaS table is a materially riskier change than adding a column.
--
-- Existing rows predate any org attribution and can't be safely assigned
-- to a specific org (the bug this migration fixes is exactly that no
-- record of "which org entered this" exists) -- they're deleted rather
-- than guessed at; re-entering a hand-typed hourly cost is a trivial ask
-- for the org(s) that had set one.
DELETE FROM gpu_pricing;
ALTER TABLE gpu_pricing ADD COLUMN org_id TEXT;
ALTER TABLE gpu_pricing DROP CONSTRAINT IF EXISTS gpu_pricing_pkey;
ALTER TABLE gpu_pricing ALTER COLUMN org_id SET NOT NULL;
ALTER TABLE gpu_pricing ADD PRIMARY KEY (org_id, gpu_type);

-- +goose Down
DELETE FROM gpu_pricing;
ALTER TABLE gpu_pricing DROP CONSTRAINT IF EXISTS gpu_pricing_pkey;
ALTER TABLE gpu_pricing DROP COLUMN org_id;
ALTER TABLE gpu_pricing ADD PRIMARY KEY (gpu_type);
