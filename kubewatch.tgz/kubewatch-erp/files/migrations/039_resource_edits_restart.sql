-- +goose Up
-- Deployment/StatefulSet/DaemonSet restart (Read-Write Cluster IDE, Phase 5b)
-- — the kubectl-rollout-restart equivalent: patches
-- spec.template.metadata.annotations["kubewatchlabs.com/restartedAt"] with a
-- fresh timestamp to trigger a rolling restart with no image/replica
-- change. Reuses resource_edits rather than a new table: restart is a
-- strict subset of the existing edit envelope (same three kinds, same apps
-- update/patch verbs, same rbac.allowEditWorkloads flag, same plan gate) —
-- it never touches raw YAML or a new object kind, so a parallel
-- manifest_applies-style row would be the wrong tool for this risk level.
ALTER TABLE resource_edits ADD COLUMN IF NOT EXISTS requested_restart BOOLEAN NOT NULL DEFAULT false;

-- +goose Down
ALTER TABLE resource_edits DROP COLUMN IF EXISTS requested_restart;
