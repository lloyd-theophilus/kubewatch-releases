-- +goose Up
-- 003_plan_limits.sql's CREATE TABLE has always used IF NOT EXISTS, so on any
-- database where the table was first created before log_streaming/sso_enabled
-- were added to that file's column list, those two columns were NEVER
-- actually added — CREATE TABLE IF NOT EXISTS silently no-ops against an
-- existing table instead of altering it. 056_plan_log_streaming_fix.sql and
-- 058_plan_limits_base_columns_fix.sql both assume the columns already exist
-- and only UPDATE them; on an affected database their UPDATE statements fail
-- outright ("column does not exist") and get silently swallowed by this
-- project's migrate runner (psql -v ON_ERROR_STOP=0 || true per file — see
-- installer/docker-compose.selfhost.yml's migrate service). This migration
-- is the actual fix: add the columns if missing, then set the same final
-- values 058 already establishes, so it's self-contained even if the affected
-- database has never once run 056/058 successfully.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS log_streaming BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS sso_enabled BOOLEAN NOT NULL DEFAULT false;

UPDATE plan_limits SET max_agents = 2, max_users = 1, retention_days = 3, max_alert_rules = 5, log_streaming = false, sso_enabled = false WHERE plan = 'free';
UPDATE plan_limits SET max_agents = 20, max_users = 10, retention_days = 30, max_alert_rules = 50, log_streaming = true, sso_enabled = false WHERE plan = 'pro';
UPDATE plan_limits SET max_agents = -1, max_users = -1, retention_days = 365, max_alert_rules = -1, log_streaming = true, sso_enabled = true WHERE plan = 'enterprise';

-- +goose Down
-- No-op, same reasoning as 058: reverting to "whatever drifted value/absence
-- happened to be there before" isn't a meaningful rollback.
