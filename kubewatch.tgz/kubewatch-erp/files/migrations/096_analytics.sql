-- +goose Up
-- Mirrors infra/tenant-migrations/042_analytics.sql (self-hosted/control-
-- plane copy). See that file's header comment for the full design; see
-- services/analytics/service.go for the service itself.

CREATE TABLE IF NOT EXISTS analytics_connections (
    id                  TEXT PRIMARY KEY,
    org_id              TEXT NOT NULL,
    type                TEXT NOT NULL CHECK (type IN ('postgres','mysql','redshift','s3')),
    name                TEXT NOT NULL,
    host                TEXT NOT NULL DEFAULT '',
    port                INTEGER NOT NULL DEFAULT 0,
    database_name       TEXT NOT NULL DEFAULT '',
    username            TEXT NOT NULL DEFAULT '',
    encrypted_password  TEXT NOT NULL DEFAULT '',
    tls_enabled         BOOLEAN NOT NULL DEFAULT TRUE,
    s3_bucket           TEXT NOT NULL DEFAULT '',
    s3_prefix           TEXT NOT NULL DEFAULT '',
    s3_region           TEXT NOT NULL DEFAULT '',
    encrypted_access_key_id     TEXT NOT NULL DEFAULT '',
    encrypted_secret_access_key TEXT NOT NULL DEFAULT '',
    status              TEXT NOT NULL DEFAULT 'unknown',
    last_checked_at     TIMESTAMPTZ,
    last_error          TEXT NOT NULL DEFAULT '',
    created_by          TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_analytics_connections_org ON analytics_connections(org_id);

CREATE TABLE IF NOT EXISTS analytics_cleaning_jobs (
    id                          TEXT PRIMARY KEY,
    org_id                      TEXT NOT NULL,
    connection_id               TEXT NOT NULL REFERENCES analytics_connections(id) ON DELETE CASCADE,
    name                        TEXT NOT NULL,
    source_config               JSONB NOT NULL DEFAULT '{}',
    steps                       JSONB NOT NULL DEFAULT '[]',
    schedule_interval_minutes   INTEGER,
    enabled                     BOOLEAN NOT NULL DEFAULT TRUE,
    created_by                  TEXT,
    created_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_analytics_cleaning_jobs_org ON analytics_cleaning_jobs(org_id);

CREATE TABLE IF NOT EXISTS analytics_cleaning_runs (
    id              TEXT PRIMARY KEY,
    org_id          TEXT NOT NULL,
    job_id          TEXT NOT NULL REFERENCES analytics_cleaning_jobs(id) ON DELETE CASCADE,
    trigger_source  TEXT NOT NULL,
    triggered_by    TEXT,
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    outcome         TEXT NOT NULL DEFAULT 'pending',
    rows_read       BIGINT NOT NULL DEFAULT 0,
    rows_output     BIGINT NOT NULL DEFAULT 0,
    duration_ms     BIGINT,
    error_message   TEXT NOT NULL DEFAULT '',
    dataset_id      TEXT
);
CREATE INDEX IF NOT EXISTS idx_analytics_cleaning_runs_job ON analytics_cleaning_runs(job_id, requested_at DESC);
CREATE INDEX IF NOT EXISTS idx_analytics_cleaning_runs_org_outcome ON analytics_cleaning_runs(org_id, outcome);
CREATE INDEX IF NOT EXISTS idx_analytics_cleaning_runs_pending ON analytics_cleaning_runs(id) WHERE outcome = 'pending';

CREATE TABLE IF NOT EXISTS analytics_datasets (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL,
    job_id      TEXT NOT NULL REFERENCES analytics_cleaning_jobs(id) ON DELETE CASCADE,
    run_id      TEXT NOT NULL REFERENCES analytics_cleaning_runs(id) ON DELETE CASCADE,
    columns     JSONB NOT NULL DEFAULT '[]',
    row_count   INTEGER NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_analytics_datasets_job ON analytics_datasets(job_id, created_at DESC);

CREATE TABLE IF NOT EXISTS analytics_dataset_rows (
    dataset_id  TEXT NOT NULL REFERENCES analytics_datasets(id) ON DELETE CASCADE,
    row_index   INTEGER NOT NULL,
    data        JSONB NOT NULL,
    PRIMARY KEY (dataset_id, row_index)
);

CREATE TABLE IF NOT EXISTS analytics_saved_charts (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL,
    job_id      TEXT NOT NULL REFERENCES analytics_cleaning_jobs(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    chart_type  TEXT NOT NULL CHECK (chart_type IN ('line','bar','area')),
    x_column    TEXT NOT NULL,
    y_columns   JSONB NOT NULL DEFAULT '[]',
    created_by  TEXT,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_analytics_saved_charts_org ON analytics_saved_charts(org_id);

-- +goose Down
DROP TABLE IF EXISTS analytics_saved_charts;
DROP TABLE IF EXISTS analytics_dataset_rows;
DROP TABLE IF EXISTS analytics_datasets;
DROP TABLE IF EXISTS analytics_cleaning_runs;
DROP TABLE IF EXISTS analytics_cleaning_jobs;
DROP TABLE IF EXISTS analytics_connections;
