-- +goose Up
-- Autoscaler Phase 2: live Kubernetes apply + rollback.
--
-- The Scaling-Engine renders each live (non-dry-run) policy's HorizontalPodAutoscaler
-- / NodePool manifest and persists it here as desired state. The in-cluster agent
-- pulls desired state, server-side-applies it (KubeWatch field manager), and reports
-- the object's status back — which is mirrored into the policy's live-status columns
-- (KubeWatch_ERP_Autoscaler_Architecture.md §5).
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS desired_manifest TEXT;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS spec_hash        TEXT;
-- apply_health: pending (desired changed, not yet applied) | applied | error
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS apply_health     TEXT;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS apply_error      TEXT;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS applied_at       TIMESTAMPTZ;

-- +goose Down
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS applied_at;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS apply_error;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS apply_health;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS spec_hash;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS desired_manifest;
