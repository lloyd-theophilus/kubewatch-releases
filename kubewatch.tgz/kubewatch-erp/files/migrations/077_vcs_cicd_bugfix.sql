-- +goose Up
-- VCS & CI/CD Observability bug-sweep fixes — control-plane / self-hosted
-- copy. SaaS's per-org copy lives in
-- infra/tenant-migrations/028_vcs_cicd_bugfix.sql (same DDL).
--
-- 1) uq_code_events_natural_key (075_vcs_cicd.sql) compared commit_sha
--    directly instead of COALESCE(commit_sha, '') like every other column in
--    that same index — Postgres treats every NULL as distinct from every
--    other NULL, so two code events with an identical
--    (connection_id, event_type, branch) and both NULL commit_sha (e.g. a
--    tag/release event, which has no commit) never actually conflict. A
--    replayed Agent push (the exact case this index exists to guard against,
--    per that migration's own comment) double-inserts instead of no-opping.
DROP INDEX IF EXISTS uq_code_events_natural_key;
CREATE UNIQUE INDEX IF NOT EXISTS uq_code_events_natural_key
    ON code_events (connection_id, event_type, COALESCE(commit_sha, ''), COALESCE(branch, ''));

-- 2) stages had no unique constraint at all, so every re-push of an active
--    pipeline run (services/live-data/vcs_cicd.go inserts one stages row per
--    push, unconditionally) appended a fresh copy of every stage instead of
--    updating the existing one — a run polled N times accumulates N x its
--    real stage count, corrupting the run-detail timeline.
CREATE UNIQUE INDEX IF NOT EXISTS uq_stages_natural_key
    ON stages (pipeline_run_id, name);

-- +goose Down
DROP INDEX IF EXISTS uq_stages_natural_key;
DROP INDEX IF EXISTS uq_code_events_natural_key;
CREATE UNIQUE INDEX IF NOT EXISTS uq_code_events_natural_key
    ON code_events (connection_id, event_type, commit_sha, COALESCE(branch, ''));
