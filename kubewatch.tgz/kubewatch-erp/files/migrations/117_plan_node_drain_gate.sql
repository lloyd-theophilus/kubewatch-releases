-- +goose Up
-- Node cordon + drain is gated at the same tier as RBAC edit
-- (105_plan_rbac_edit_gate.sql) — comparably sensitive: it's a
-- cluster-wide, single-admin-approved write action (see
-- infra/tenant-migrations/059_node_drains.sql for the actual request/
-- approval table, which lives in the tenant database like every other
-- per-org feature table).
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_node_drain_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_node_drain_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_node_drain_enabled;
