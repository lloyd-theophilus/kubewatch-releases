-- +goose Up
-- Plan gate for cloud VM power actions (Restart/Stop/Terminate a node),
-- mirroring cluster_helm_lifecycle_enabled (042_plan_helm_lifecycle_gate.sql).
-- Independent of every other cluster_*_enabled flag.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_node_actions_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_node_actions_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_node_actions_enabled;
