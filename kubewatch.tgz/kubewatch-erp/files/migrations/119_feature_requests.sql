-- +goose Up
-- Public feature-request board on the marketing site: anyone can submit a
-- request (no login) and upvote existing ones; the operator console shows
-- every request (including declined) for the KubeWatch team to triage.
-- Control-plane table (not tenant-scoped): a request isn't owned by any one
-- org, so it lives here rather than in infra/tenant-migrations/.
CREATE TABLE IF NOT EXISTS feature_requests (
    id              TEXT PRIMARY KEY,
    title           TEXT NOT NULL,
    description     TEXT NOT NULL,
    submitter_email TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'open', -- open | planned | shipped | declined
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- One vote per (request, fingerprint). voter_fingerprint is a hash of the
-- submitter's best-effort IP + user agent -- not a real identity, just
-- enough to stop the same browser/IP from upvoting the same request twice.
-- See services/tenant-mgmt/feature_requests.go's voterFingerprint.
CREATE TABLE IF NOT EXISTS feature_request_votes (
    id                TEXT PRIMARY KEY,
    request_id        TEXT NOT NULL REFERENCES feature_requests(id) ON DELETE CASCADE,
    voter_fingerprint TEXT NOT NULL,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (request_id, voter_fingerprint)
);

CREATE INDEX IF NOT EXISTS idx_feature_requests_status ON feature_requests(status);
CREATE INDEX IF NOT EXISTS idx_feature_request_votes_request_id ON feature_request_votes(request_id);

-- +goose Down
DROP TABLE IF EXISTS feature_request_votes;
DROP TABLE IF EXISTS feature_requests;
