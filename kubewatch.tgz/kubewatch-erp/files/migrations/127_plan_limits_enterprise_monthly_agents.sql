-- +goose Up
-- SaaS Enterprise's monthly agent cap drops from 1,000 to 200, widening the
-- gap between monthly and yearly billing (2,000) as a stronger incentive to
-- commit annually, rather than the two being close enough that period barely
-- mattered for large accounts.
UPDATE plan_limits SET max_agents = 200 WHERE plan = 'enterprise' AND period = 'monthly';

-- +goose Down
UPDATE plan_limits SET max_agents = 1000 WHERE plan = 'enterprise' AND period = 'monthly';
