-- +goose Up
-- Log Intelligence spec §2/§9: "Can be woken by a direct user request or by
-- Alert-Engine (existing) via a new optional notify_log_intelligence field
-- on alert rules." Defaults true so every existing and new rule keeps
-- today's behavior (every firing alert gets diagnosed, subject to the
-- existing per-org rate limit) unless an admin deliberately opts a specific
-- rule out -- e.g. a high-frequency rule that would otherwise burn through
-- the diagnosis budget for everything else.
ALTER TABLE alert_rules ADD COLUMN IF NOT EXISTS notify_log_intelligence BOOLEAN NOT NULL DEFAULT true;
