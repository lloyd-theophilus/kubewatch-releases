-- +goose Up
-- Autoscaler subsystem (Phase 1: Kubernetes dry-run).
--
-- One ScalingPolicy record per monitored workload, regardless of runtime
-- (KubeWatch_ERP_Autoscaler_Architecture.md §4). The Scaling-Engine reads
-- enabled policies, evaluates thresholds against Mimir, and — in
-- dry-run — records what it WOULD do in the append-only scaling_decisions log
-- without applying any native object.
CREATE TABLE IF NOT EXISTS scaling_policies (
    id                            TEXT PRIMARY KEY,
    org_id                        TEXT NOT NULL,
    name                          TEXT NOT NULL,
    -- Identity (§4.1)
    workload_id                   TEXT,
    runtime                       TEXT NOT NULL DEFAULT 'kubernetes', -- kubernetes | docker
    target_ref                    TEXT NOT NULL,                      -- namespace/deployment | host-pool/container-group
    enabled                       BOOLEAN NOT NULL DEFAULT TRUE,
    dry_run                       BOOLEAN NOT NULL DEFAULT TRUE,
    -- Mode (§4.1) — strategy is derived from runtime, not independently set (§7.1)
    strategy                      TEXT NOT NULL DEFAULT 'pods',       -- pods | containers
    min_replicas                  INTEGER NOT NULL DEFAULT 1,
    max_replicas                  INTEGER NOT NULL DEFAULT 10,
    step_size                     INTEGER NOT NULL DEFAULT 1,
    -- Asymmetric cooldown / stabilization windows (§5.1, §7.2)
    cooldown_scale_up_seconds     INTEGER NOT NULL DEFAULT 30,
    cooldown_scale_down_seconds   INTEGER NOT NULL DEFAULT 300,
    -- Thresholds (§4.1) — CPU and memory are optional; a policy can scale on either
    cpu_target_percent            INTEGER,
    memory_target_percent         INTEGER,
    node_pressure_target_percent  INTEGER,                            -- Kubernetes-only (Karpenter, §5.3)
    metric_source                 TEXT NOT NULL DEFAULT 'agent',      -- agent | prometheus
    -- Ownership (§4.1, §9.1)
    team_id                       TEXT,
    approval_required             BOOLEAN NOT NULL DEFAULT FALSE,
    -- Native link (§4.1) — populated after first successful apply (Phase 2)
    hpa_ref                       TEXT,
    nodepool_ref                  TEXT,
    lb_pool_ref                   TEXT,
    -- Live status (§4.1) — mirrored, read-only from the UI's perspective
    current_replicas              INTEGER,
    desired_replicas              INTEGER,
    last_observed_value           DOUBLE PRECISION,
    last_evaluated_at             TIMESTAMPTZ,
    last_scaled_at                TIMESTAMPTZ,
    last_decision                 TEXT,
    previous_state                JSONB,                              -- what a rollback restores from (§6.5, Phase 2)
    created_by                    TEXT,
    updated_by                    TEXT,
    created_at                    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_scaling_policies_org ON scaling_policies (org_id);
CREATE INDEX IF NOT EXISTS idx_scaling_policies_enabled ON scaling_policies (enabled) WHERE enabled = TRUE;

-- Append-only decision log (§2.1, §8.6, §9.3). Every entry is a new row; a
-- rollback references the entry it reverts rather than mutating it.
CREATE TABLE IF NOT EXISTS scaling_decisions (
    id                BIGSERIAL PRIMARY KEY,
    org_id            TEXT NOT NULL,
    policy_id         TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    runtime           TEXT NOT NULL,
    trigger_metric    TEXT,                       -- cpu_percent | memory_percent | node_pressure_percent
    trigger_value     DOUBLE PRECISION,
    threshold         DOUBLE PRECISION,
    direction         TEXT NOT NULL DEFAULT 'none', -- up | down | none
    from_replicas     INTEGER,
    to_replicas       INTEGER,
    action            TEXT NOT NULL,              -- dry_run | applied | proposed | skipped_cooldown | rollback
    dry_run           BOOLEAN NOT NULL DEFAULT TRUE,
    rendered_manifest TEXT,                       -- the HPA/NodePool YAML it would apply
    outcome           TEXT,
    actor             TEXT NOT NULL DEFAULT 'system',
    reverts_id        BIGINT                      -- set when this entry is a rollback of another (§9.3)
);
CREATE INDEX IF NOT EXISTS idx_scaling_decisions_org_ts ON scaling_decisions (org_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_scaling_decisions_policy_ts ON scaling_decisions (policy_id, ts DESC);

-- +goose Down
DROP TABLE IF EXISTS scaling_decisions;
DROP TABLE IF EXISTS scaling_policies;
