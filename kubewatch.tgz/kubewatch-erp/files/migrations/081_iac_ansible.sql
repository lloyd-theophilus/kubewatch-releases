-- +goose Up
-- Ansible support for Infrastructure Automation, alongside the existing
-- OpenTofu Stacks — a Stack is now either kind, distinguished by
-- stack_type, sharing the same working_directory/runs/approval-gate
-- machinery rather than a parallel set of tables. An Ansible stack's
-- playbook_file/inventory_file are paths within working_directory in the
-- project's own Git repo, matching how an OpenTofu stack's .tf files are
-- just files in that same directory — nothing here is stored outside Git.
ALTER TABLE iac_stacks ADD COLUMN IF NOT EXISTS stack_type TEXT NOT NULL DEFAULT 'opentofu' CHECK (stack_type IN ('opentofu', 'ansible'));
ALTER TABLE iac_stacks ADD COLUMN IF NOT EXISTS playbook_file TEXT;
ALTER TABLE iac_stacks ADD COLUMN IF NOT EXISTS inventory_file TEXT;

-- ssh_key secrets authenticate an Ansible run's SSH connection to its
-- target hosts (materialized to a 0600 temp file by the worker, never
-- passed as a CLI argument — see services/iac-worker/executor.go).
ALTER TABLE iac_secrets DROP CONSTRAINT IF EXISTS iac_secrets_type_check;
ALTER TABLE iac_secrets ADD CONSTRAINT iac_secrets_type_check CHECK (type IN ('generic', 'api_token', 'cloud_credential', 'ssh_key'));

-- 'check' (Ansible's --check --diff dry-run) and 'run' (the real
-- execution) are this feature's Ansible operations — 'run' requires a
-- succeeded, approved 'check' run on the same stack, exactly the same
-- plan-before-apply guardrail 'plan'/'apply' already enforce for OpenTofu
-- (see services/iac/stacks.go's createRun and planOperationFor).
ALTER TABLE iac_runs DROP CONSTRAINT IF EXISTS iac_runs_operation_check;
ALTER TABLE iac_runs ADD CONSTRAINT iac_runs_operation_check CHECK (operation IN ('plan', 'plan_destroy', 'apply', 'destroy', 'refresh', 'check', 'run'));

-- +goose Down
ALTER TABLE iac_runs DROP CONSTRAINT IF EXISTS iac_runs_operation_check;
ALTER TABLE iac_runs ADD CONSTRAINT iac_runs_operation_check CHECK (operation IN ('plan', 'plan_destroy', 'apply', 'destroy', 'refresh'));
ALTER TABLE iac_secrets DROP CONSTRAINT IF EXISTS iac_secrets_type_check;
ALTER TABLE iac_secrets ADD CONSTRAINT iac_secrets_type_check CHECK (type IN ('generic', 'api_token', 'cloud_credential'));
ALTER TABLE iac_stacks DROP COLUMN IF EXISTS stack_type;
ALTER TABLE iac_stacks DROP COLUMN IF EXISTS playbook_file;
ALTER TABLE iac_stacks DROP COLUMN IF EXISTS inventory_file;
