-- +goose Up
-- Plan gate for triggering a Kubernetes control-plane version upgrade
-- (EKS/GKE/AKS) from KubeWatch -- a destructive, high-privilege
-- infrastructure action, same tier as cluster_node_actions_enabled
-- (086_plan_node_actions_gate.sql) and cluster_namespace_delete_enabled
-- (088_plan_namespace_delete_gate.sql). Enterprise-only.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_upgrade_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_upgrade_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_upgrade_enabled;
