-- +goose Up
-- Plan gate for generic manifest apply (Phase 5), mirroring
-- cluster_edit_enabled (035_plan_edit_gate.sql). Independent of every other
-- cluster_*_enabled flag.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_generic_apply_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_generic_apply_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_generic_apply_enabled;
