-- +goose Up
-- Mirrors infra/tenant-migrations/055_image_scan_attempts.sql exactly --
-- self-hosted uses this shared control-plane DB directly (never runs
-- tenant-migrations), SaaS gets the same table per-org via that mirror.
--
-- Backs automatic (discovery-triggered) vulnerability scanning: a record per
-- scan attempt, success or failure, distinct from image_vulnerabilities
-- (111_vulnerability_scanning.sql) which only ever holds the latest findings
-- for a digest -- a clean scan (zero vulnerabilities) leaves no row there at
-- all, so it can't be used to tell "have we already tried this image
-- recently" or "how many auto-scans has this org triggered this hour" the
-- way this table can.
CREATE TABLE IF NOT EXISTS image_scan_attempts (
    id           BIGSERIAL PRIMARY KEY,
    org_id       TEXT NOT NULL,
    image_digest TEXT NOT NULL,
    image_ref    TEXT NOT NULL,
    trigger      TEXT NOT NULL DEFAULT 'manual' CHECK (trigger IN ('manual', 'auto')),
    success      BOOLEAN NOT NULL,
    error        TEXT NOT NULL DEFAULT '',
    attempted_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_image_scan_attempts_org_time ON image_scan_attempts (org_id, attempted_at);
CREATE INDEX IF NOT EXISTS idx_image_scan_attempts_org_digest_time ON image_scan_attempts (org_id, image_digest, attempted_at);

-- +goose Down
DROP TABLE IF EXISTS image_scan_attempts;
