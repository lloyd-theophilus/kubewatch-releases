-- +goose Up
-- Self-Hosted AI Stack Observability (AI-Ops roadmap Feature 3, Phase 2 —
-- see assets/KUBEWATCH-AI-OPS-COMPLETE.md). Inference-engine metrics
-- already flow through the existing agent scraper (inference_snapshots /
-- inference_* VictoriaMetrics series) — this adds the two genuinely new
-- pieces: a model registry (which models, versions, roles) and the
-- Sovereign Fallback Health Checker's synthetic-probe history.
CREATE TABLE IF NOT EXISTS model_registry (
    id                     TEXT PRIMARY KEY,
    org_id                 TEXT NOT NULL REFERENCES organizations(id),
    model_name             TEXT NOT NULL,
    engine                 TEXT NOT NULL DEFAULT 'vllm', -- vllm | ollama | sglang | tgi
    endpoint               TEXT NOT NULL,
    role                   TEXT NOT NULL DEFAULT 'primary', -- primary | fallback
    version_hash           TEXT,
    check_interval_seconds INTEGER NOT NULL DEFAULT 300,
    check_prompt           TEXT NOT NULL DEFAULT 'Respond with the single word: OK',
    check_timeout_ms       INTEGER NOT NULL DEFAULT 5000,
    deployed_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_model_registry_org ON model_registry (org_id);

-- Append-only (never mutated), same convention as scaling_decisions /
-- agent_policy_decisions.
CREATE TABLE IF NOT EXISTS fallback_health_checks (
    id           BIGSERIAL PRIMARY KEY,
    org_id       TEXT NOT NULL,
    model_id     TEXT NOT NULL REFERENCES model_registry(id) ON DELETE CASCADE,
    checked_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    success      BOOLEAN NOT NULL,
    latency_ms   INTEGER,
    error_detail TEXT
);
CREATE INDEX IF NOT EXISTS idx_fallback_health_checks_model_ts ON fallback_health_checks (model_id, checked_at DESC);

-- Enterprise-only, same tier as ai_observability_enabled (this is the
-- sovereignty/self-hosted-stack-focused sibling feature).
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS self_hosted_ai_observability_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET self_hosted_ai_observability_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS self_hosted_ai_observability_enabled;
DROP TABLE IF EXISTS fallback_health_checks;
DROP TABLE IF EXISTS model_registry;
