-- +goose Up
-- User-chosen retention window for logs and metrics, entirely the org's own
-- call -- there's no plan-tiered retention promise to interact with (that
-- would need either a paid Mimir Enterprise license or a
-- multi-instance storage split to actually enforce; deferred until
-- customers ask for it). NULL means no preference set (unclamped); set
-- means "cap my own history at this many days" (services/query/metrics.go's
-- effectiveRetentionDays, and bulklogs.go's searchBulkLogs for logs). Fixed
-- set of choices, not a free-form number, to keep the UI and the
-- enforcement code in exact agreement.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS retention_preference_days INTEGER
    CHECK (retention_preference_days IS NULL OR retention_preference_days IN (30, 90, 180));

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS retention_preference_days;
