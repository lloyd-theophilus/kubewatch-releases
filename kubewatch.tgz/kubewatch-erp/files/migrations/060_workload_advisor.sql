-- +goose Up
-- Docker-vs-Kubernetes Workload Advisor (AI-Ops roadmap Feature 4, Phase 1 —
-- see assets/KUBEWATCH-AI-OPS-COMPLETE.md). Purely additive and read-only:
-- reads workload metadata and VictoriaMetrics history that already exist, no
-- new command types, no rollback model (§7 of the feature spec — this
-- feature takes no automated action).
CREATE TABLE IF NOT EXISTS placement_recommendations (
    id                             TEXT PRIMARY KEY,
    org_id                         TEXT NOT NULL REFERENCES organizations(id),
    workload_id                    TEXT NOT NULL,
    workload_kind                  TEXT,
    workload_namespace             TEXT,
    workload_name                  TEXT,
    current_runtime                TEXT NOT NULL,             -- kubernetes | docker
    recommended_runtime            TEXT NOT NULL,             -- kubernetes | docker | no_change
    confidence_score               NUMERIC NOT NULL,          -- 0-1; low-confidence results are not surfaced (see spec §6)
    rationale                      JSONB NOT NULL DEFAULT '[]', -- array of {factor, value, weight} objects
    estimated_monthly_savings_usd  NUMERIC,
    generated_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    dismissed                      BOOLEAN NOT NULL DEFAULT FALSE,
    dismissed_at                   TIMESTAMPTZ,
    created_at                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (org_id, workload_id)   -- a new run replaces, never accumulates alongside, the prior recommendation
);
CREATE INDEX IF NOT EXISTS idx_placement_recommendations_org ON placement_recommendations (org_id, generated_at DESC);

ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS workload_advisor_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET workload_advisor_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS workload_advisor_enabled;
DROP TABLE IF EXISTS placement_recommendations;
