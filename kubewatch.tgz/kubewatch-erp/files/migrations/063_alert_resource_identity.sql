-- +goose Up
-- Prerequisite fix for Autonomous Remediation (AI-Ops roadmap Feature 5,
-- Phase 3 — see assets/KUBEWATCH-AI-OPS-COMPLETE.md). Alert-Engine
-- (services/alert-engine/engine.go) previously read only the first
-- Mimir series for a rule and discarded every label, so
-- resource_type was never populated and resource_id was always empty for
-- every metric-threshold rule (only agent_silent_minutes, which queries
-- Postgres directly, ever set a resource identity). A playbook can't target
-- a restart action without knowing which container/pod/node fired. This adds
-- a structured label bag (the full Mimir label set at fire time —
-- container_id/container_name, pod/namespace/node/owner_kind/owner_name, or
-- node — whichever apply) so Remediation Engine never needs a second query
-- to resolve a restart target.
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS labels JSONB;

-- Per-resource dedup: engine.go now creates one alert per (rule_id,
-- resource_id) instead of one per rule_id, so N containers breaching the
-- same rule each get their own alert/resolve lifecycle instead of only the
-- first-seen one ever showing up.
CREATE INDEX IF NOT EXISTS idx_alerts_rule_resource_active
    ON alerts (rule_id, resource_id)
    WHERE state IN ('firing', 'acknowledged');

-- +goose Down
DROP INDEX IF EXISTS idx_alerts_rule_resource_active;
ALTER TABLE alerts DROP COLUMN IF EXISTS labels;
