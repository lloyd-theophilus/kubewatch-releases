-- +goose Up
-- Agent self-update (Docker: stop/remove/recreate with the new image;
-- Kubernetes: patch the agent's own DaemonSet image tag) — see
-- services/live-data/agent_updates.go's doc comment for the full design.
-- Deliberately its own table (not another manifest_applies/resource_edits
-- extension), matching this codebase's "one feature, one table" convention
-- for risky cluster-write actions.
--
-- No agent-reported "success" column by design: the agent process that
-- would report success is the same one being restarted/replaced by the
-- update, so it can't be relied on to report back reliably. 'applied' is
-- set instead by a background check that treats the agent's next normal
-- version-bearing heartbeat (>= target_version) as the success signal —
-- the same agents.version column the outdated-agent banner already
-- compares via shared/semver. 'apply_failed' IS agent-reported, since that
-- only ever fires when the update couldn't even start (Docker socket
-- rejected, Kubernetes RBAC denied), before anything self-destructive has
-- happened and the process is certainly still alive to report it.
-- 'stuck' is set by a timeout sweep when no matching-version heartbeat
-- arrives within a fixed window, so a request never shows "updating..."
-- forever.
CREATE TABLE IF NOT EXISTS agent_updates (
    id              TEXT PRIMARY KEY,   -- aupdate_<hex>
    org_id          TEXT NOT NULL,
    agent_id        TEXT NOT NULL,
    from_version    TEXT NOT NULL,
    target_version  TEXT NOT NULL,
    requested_by    TEXT NOT NULL,
    requested_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_by     TEXT,
    approved_at     TIMESTAMPTZ,
    outcome         TEXT NOT NULL DEFAULT 'pending_approval',
        -- pending_approval | approved_pending_apply | applied | apply_failed | stuck
    apply_error     TEXT
);
CREATE INDEX IF NOT EXISTS idx_agent_updates_org_outcome ON agent_updates(org_id, outcome);
CREATE INDEX IF NOT EXISTS idx_agent_updates_agent ON agent_updates(agent_id);

-- +goose Down
DROP TABLE IF EXISTS agent_updates;
