-- +goose Up
-- VCS & CI/CD Observability Phase 2 (Alerting & Correlation) — control-plane
-- copy. alert_rules.target_metric lives in the tenant DB in SaaS mode (see
-- infra/tenant-migrations/027_vcs_cicd_phase2.sql); this ALTER is the
-- harmless self-hosted mirror, same convention as every prior migration
-- pair this feature added.
ALTER TABLE alert_rules ADD COLUMN IF NOT EXISTS target_metric TEXT;

-- vcs_connection_index is a control-plane routing table (same shape/purpose
-- as dr_schedule_index/agent_token_index): the Webhook Gateway receives a
-- webhook with no KubeWatch org context at all, only a connection_id in the
-- URL, so it needs a cheap way to find which org's tenant database owns
-- that connection without scanning every org. Written-through by
-- services/pipelines whenever a connection enables/disables its webhook or
-- is deleted (see connections.go's enableWebhook/disableWebhook/
-- deleteConnection).
CREATE TABLE IF NOT EXISTS vcs_connection_index (
    connection_id TEXT PRIMARY KEY,
    org_id        TEXT NOT NULL,
    provider      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_vcs_connection_index_org_id ON vcs_connection_index (org_id);

-- +goose Down
DROP TABLE IF EXISTS vcs_connection_index;
ALTER TABLE alert_rules DROP COLUMN IF EXISTS target_metric;
