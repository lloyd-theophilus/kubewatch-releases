-- +goose Up
-- Generic manifest apply (Read-Write Cluster IDE, Phase 5) — the arbitrary-
-- kind counterpart to resource_edits (034_resource_edits.sql). Deliberately a
-- separate table rather than an overload: resource_edits' shape (single
-- kind/namespace/name/container, typed image/replica columns) is
-- fundamentally single-object and workload-typed, while generic apply is
-- multi-object and kind-agnostic. Same audit-log workflow shape otherwise:
-- request -> [snapshot] -> pending_approval -> approve/deny -> apply ->
-- applied/apply_failed, with rollback as a brand-new request, never a
-- shortcut.
CREATE TABLE IF NOT EXISTS manifest_applies (
    id                 TEXT PRIMARY KEY,   -- mapply_<hex>
    org_id             TEXT NOT NULL,
    agent_id           TEXT NOT NULL,
    requested_by       TEXT NOT NULL,
    requested_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    -- NULL only for is_rollback rows: a rollback's substance is the per-
    -- object rollback_action/previous_state on manifest_apply_objects, not
    -- a single coherent YAML manifest (a rollback can mix "reapply" and
    -- "delete" actions across its objects).
    requested_manifest TEXT,
    approved_by        TEXT,
    approved_at        TIMESTAMPTZ,
    denied_by          TEXT,
    denied_at          TIMESTAMPTZ,
    outcome            TEXT NOT NULL DEFAULT 'pending_snapshot',
        -- pending_snapshot | snapshot_failed | pending_approval |
        -- approved_pending_apply | applied | apply_failed | denied
    apply_error        TEXT,
    applied_at         TIMESTAMPTZ,
    reverts_id         TEXT REFERENCES manifest_applies(id),
    is_rollback        BOOLEAN NOT NULL DEFAULT false
);
CREATE INDEX IF NOT EXISTS idx_manifest_applies_org_status ON manifest_applies (org_id, outcome);
CREATE INDEX IF NOT EXISTS idx_manifest_applies_agent ON manifest_applies (agent_id, outcome);

-- One row per document within a (possibly multi-document) manifest, so a
-- create-and-update mix in a single request is tracked and rolled back
-- correctly per object: previous_state IS NULL means this document's object
-- was confirmed absent before applying (a create; rollback = delete),
-- non-NULL means it already existed (an update; rollback = reapply the
-- stored previous_state).
CREATE TABLE IF NOT EXISTS manifest_apply_objects (
    id                TEXT PRIMARY KEY,   -- mobj_<hex>
    manifest_apply_id TEXT NOT NULL REFERENCES manifest_applies(id),
    doc_index         INTEGER NOT NULL,
    api_version       TEXT NOT NULL,
    kind              TEXT NOT NULL,
    namespace         TEXT NOT NULL,
    name              TEXT NOT NULL,
    previous_state    JSONB,
    rollback_action   TEXT,   -- NULL on originals; 'reapply' | 'delete' on rollback rows
    applied_at        TIMESTAMPTZ,
    apply_error       TEXT
);
CREATE INDEX IF NOT EXISTS idx_manifest_apply_objects_parent ON manifest_apply_objects (manifest_apply_id);

-- +goose Down
DROP TABLE IF EXISTS manifest_apply_objects;
DROP TABLE IF EXISTS manifest_applies;
