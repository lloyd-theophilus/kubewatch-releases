-- +goose Up
-- The platform superadmin's own org (org_platform, seeded by
-- services/auth/seed.go for internal testing/operations) should see every
-- plan-gated feature regardless of its own plan column, without touching
-- how effective plan is computed for real customer orgs. Every plan gate in
-- the codebase already joins org_effective_plan, so hardcoding this one org
-- to 'enterprise' here is a single-point fix instead of threading a
-- superadmin bypass through every xEnabledForPlan function individually.
CREATE OR REPLACE VIEW org_effective_plan AS
SELECT
    id AS org_id,
    CASE
        WHEN id = 'org_platform'
        THEN 'enterprise'
        WHEN license_type = 'trial'
         AND trial_ends_at IS NOT NULL
         AND trial_ends_at > NOW()
        THEN 'enterprise'
        ELSE plan
    END AS effective_plan
FROM organizations;

-- +goose Down
CREATE OR REPLACE VIEW org_effective_plan AS
SELECT
    id AS org_id,
    CASE
        WHEN license_type = 'trial'
         AND trial_ends_at IS NOT NULL
         AND trial_ends_at > NOW()
        THEN 'enterprise'
        ELSE plan
    END AS effective_plan
FROM organizations;
