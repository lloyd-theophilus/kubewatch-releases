-- Log Intelligence spec (intelligence_log/KUBEWATCH-LOG-INTELLIGENCE.md) §4/§6:
-- "New command types carry previous_state, matching the existing rollback
-- pattern" -- for k8s.resource.adjust (services/remediation-engine/engine.go,
-- agent/internal/k8sapply.Applier.AdjustContainerResources), the container
-- name and previous/new memory limit the Agent actually applied, populated
-- by services/live-data's reportResult once the command reports success, so
-- a human reviewing this execution can revert it manually even though it
-- ran unattended.
ALTER TABLE remediation_executions ADD COLUMN IF NOT EXISTS previous_state JSONB;
