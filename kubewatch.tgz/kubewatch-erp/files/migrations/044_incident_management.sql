-- +goose Up
-- Incident Management: detect (declare), respond (acknowledge/mitigate,
-- with dynamic routing to whoever's on call), resolve, and learn
-- (postmortems). See services/incidents for the service that owns these
-- tables; this migration exists for parity with the other core shared-schema
-- tables (alerts, notification_channels) — services/incidents also
-- self-migrates the same DDL on startup so it works standalone.
CREATE TABLE IF NOT EXISTS incidents (
    id              TEXT PRIMARY KEY,
    org_id          TEXT NOT NULL REFERENCES organizations(id),
    title           TEXT NOT NULL,
    description     TEXT DEFAULT '',
    severity        TEXT NOT NULL DEFAULT 'medium',
    status          TEXT NOT NULL DEFAULT 'declared',
    alert_id        TEXT DEFAULT '',
    alert_rule_id   TEXT DEFAULT '',
    commander_id    TEXT DEFAULT '',
    created_by      TEXT NOT NULL,
    started_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    acknowledged_at TIMESTAMPTZ,
    resolved_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_incidents_org ON incidents (org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_incidents_org_status ON incidents (org_id, status);

CREATE TABLE IF NOT EXISTS incident_timeline_events (
    id          TEXT PRIMARY KEY,
    incident_id TEXT NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    event_type  TEXT NOT NULL,
    actor_id    TEXT DEFAULT '',
    message     TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_incident_timeline_incident ON incident_timeline_events (incident_id, created_at);

CREATE TABLE IF NOT EXISTS incident_responders (
    id          TEXT PRIMARY KEY,
    incident_id TEXT NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
    user_id     TEXT NOT NULL,
    role        TEXT NOT NULL DEFAULT 'responder',
    added_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (incident_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_incident_responders_incident ON incident_responders (incident_id);

CREATE TABLE IF NOT EXISTS oncall_schedules (
    id         TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL REFERENCES organizations(id),
    name       TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_oncall_schedules_org ON oncall_schedules (org_id);

CREATE TABLE IF NOT EXISTS oncall_shifts (
    id          TEXT PRIMARY KEY,
    schedule_id TEXT NOT NULL REFERENCES oncall_schedules(id) ON DELETE CASCADE,
    user_id     TEXT NOT NULL,
    starts_at   TIMESTAMPTZ NOT NULL,
    ends_at     TIMESTAMPTZ NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_oncall_shifts_schedule ON oncall_shifts (schedule_id, starts_at);

CREATE TABLE IF NOT EXISTS postmortems (
    id           TEXT PRIMARY KEY,
    incident_id  TEXT NOT NULL UNIQUE REFERENCES incidents(id) ON DELETE CASCADE,
    summary      TEXT NOT NULL DEFAULT '',
    created_by   TEXT NOT NULL,
    published_at TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS postmortem_action_items (
    id            TEXT PRIMARY KEY,
    postmortem_id TEXT NOT NULL REFERENCES postmortems(id) ON DELETE CASCADE,
    description   TEXT NOT NULL,
    assignee_id   TEXT DEFAULT '',
    status        TEXT NOT NULL DEFAULT 'open',
    due_date      DATE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_action_items_postmortem ON postmortem_action_items (postmortem_id);

-- +goose Down
DROP TABLE IF EXISTS postmortem_action_items;
DROP TABLE IF EXISTS postmortems;
DROP TABLE IF EXISTS oncall_shifts;
DROP TABLE IF EXISTS oncall_schedules;
DROP TABLE IF EXISTS incident_responders;
DROP TABLE IF EXISTS incident_timeline_events;
DROP TABLE IF EXISTS incidents;
