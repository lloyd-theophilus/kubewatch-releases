-- +goose Up
-- Per-outcome breakdown for a load test (HTTP status codes and transport errors,
-- each with a count) so the Performance page can show what was tested, what
-- succeeded, and what failed, rather than only aggregate counts.
ALTER TABLE load_tests ADD COLUMN IF NOT EXISTS outcomes JSONB;

-- +goose Down
ALTER TABLE load_tests DROP COLUMN IF EXISTS outcomes;
