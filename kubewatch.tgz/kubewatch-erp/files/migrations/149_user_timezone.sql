-- +goose Up
-- Mirrors infra/tenant-migrations/079_user_timezone.sql. Per-viewer display
-- preference (matches Grafana/Datadog's own "Browser Time vs UTC" pattern),
-- not an org-wide setting -- see services/auth/service.go's handleMe/
-- handleUpdateTimezone and frontend/dashboard/lib/timezone.ts.
--
-- `timezone` is always a concrete, ready-to-use value regardless of mode --
-- either a real IANA zone name (resolved client-side via
-- Intl.DateTimeFormat().resolvedOptions().timeZone when mode='browser') or
-- the literal string "UTC" (when mode='utc'). `timezone_mode` exists only so
-- the Settings toggle can render its own current state without having to
-- reverse-engineer "is this exact IANA string what the browser would
-- currently report" -- backend/email formatting only ever needs to read
-- `timezone` directly via Go's time.LoadLocation, never `timezone_mode`.
ALTER TABLE users ADD COLUMN IF NOT EXISTS timezone_mode TEXT NOT NULL DEFAULT 'browser';
ALTER TABLE users ADD COLUMN IF NOT EXISTS timezone TEXT NOT NULL DEFAULT 'UTC';

-- +goose Down
ALTER TABLE users DROP COLUMN IF EXISTS timezone_mode;
ALTER TABLE users DROP COLUMN IF EXISTS timezone;
