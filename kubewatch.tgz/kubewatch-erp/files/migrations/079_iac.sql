-- +goose Up
-- Infrastructure Automation (control-plane / self-hosted copy). SaaS's
-- per-org copy lives in infra/tenant-migrations/030_iac.sql (same DDL).
--
-- Seven tables: iac_projects (Git-synced containers) -> iac_stacks
-- (OpenTofu code units) and iac_vaults (secret containers) -> iac_secrets
-- (versioned, encrypted); iac_variables (non-secret, project- or
-- stack-scoped); iac_runs (plan/apply/destroy/refresh executions);
-- iac_project_members (project-scoped RBAC, on top of the org-wide plan
-- gate below).
--
-- iac_secrets.encrypted_value is the one deliberate exception to this
-- codebase's "no at-rest encryption primitive" convention (see
-- infra/tenant-migrations/025_disaster_recovery.sql's comment on that
-- convention) — this column holds shared/crypto.Vault.EncryptString
-- output, never plaintext, because this feature's secrets are cloud
-- provider credentials and SSH private keys: a leak here is a full
-- infrastructure compromise, not a leaked webhook URL.
CREATE TABLE IF NOT EXISTS iac_projects (
    id                TEXT PRIMARY KEY,
    org_id            TEXT NOT NULL,
    name              TEXT NOT NULL,
    description       TEXT,
    git_repo_url      TEXT,
    git_branch        TEXT NOT NULL DEFAULT 'main',
    -- References iac_secrets(id) without a DB-level FK constraint, purely
    -- to avoid a creation-order cycle (iac_secrets itself references
    -- iac_vaults which references this table) — validated at the
    -- application layer instead.
    git_credential_id TEXT,
    environment       TEXT NOT NULL DEFAULT 'production',
    created_by        TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iac_projects_org_id ON iac_projects (org_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_iac_projects_org_name ON iac_projects (org_id, name);

CREATE TABLE IF NOT EXISTS iac_vaults (
    id         TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL,
    project_id TEXT NOT NULL REFERENCES iac_projects(id) ON DELETE CASCADE,
    name       TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iac_vaults_project_id ON iac_vaults (project_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_iac_vaults_project_name ON iac_vaults (project_id, name);

CREATE TABLE IF NOT EXISTS iac_secrets (
    id              TEXT PRIMARY KEY,
    org_id          TEXT NOT NULL,
    vault_id        TEXT NOT NULL REFERENCES iac_vaults(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    type            TEXT NOT NULL DEFAULT 'generic', -- generic | api_token | cloud_credential (ssh_key added in a later phase)
    encrypted_value TEXT NOT NULL,
    version         INTEGER NOT NULL DEFAULT 1,
    created_by      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iac_secrets_vault_id ON iac_secrets (vault_id);
-- Append-only versioning: a new version of a named secret is a NEW row
-- (same vault_id+name, version = previous max + 1), never an UPDATE of an
-- existing row's encrypted_value — the current value is whichever row has
-- the highest version; older rows stay for history exactly as-is.
CREATE UNIQUE INDEX IF NOT EXISTS uq_iac_secrets_vault_name_version ON iac_secrets (vault_id, name, version);

CREATE TABLE IF NOT EXISTS iac_stacks (
    id                TEXT PRIMARY KEY,
    org_id            TEXT NOT NULL,
    project_id        TEXT NOT NULL REFERENCES iac_projects(id) ON DELETE CASCADE,
    name              TEXT NOT NULL,
    -- Path within the project's Git repo where the .tf/.tofu files live.
    -- State storage is deliberately not modeled here: it lives wherever
    -- the stack's own backend block says (S3, GCS, Terraform Cloud, ...),
    -- exactly like running `tofu` by hand — this platform runs the CLI
    -- against whatever backend the code declares, it doesn't own state.
    working_directory TEXT NOT NULL DEFAULT '.',
    created_by        TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iac_stacks_project_id ON iac_stacks (project_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_iac_stacks_project_name ON iac_stacks (project_id, name);

CREATE TABLE IF NOT EXISTS iac_variables (
    id         TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL,
    project_id TEXT NOT NULL REFERENCES iac_projects(id) ON DELETE CASCADE,
    stack_id   TEXT REFERENCES iac_stacks(id) ON DELETE CASCADE, -- NULL = project-wide, shared across every stack in it
    key        TEXT NOT NULL,
    value      TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iac_variables_project_id ON iac_variables (project_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_iac_variables_scope_key ON iac_variables (project_id, COALESCE(stack_id, ''), key);

CREATE TABLE IF NOT EXISTS iac_runs (
    id           TEXT PRIMARY KEY,
    org_id       TEXT NOT NULL,
    stack_id     TEXT NOT NULL REFERENCES iac_stacks(id) ON DELETE CASCADE,
    -- plan_destroy is a distinct operation (runs `tofu plan -destroy`) from
    -- plan specifically so a destroy can never be authorized by a plan that
    -- only ever showed a create/update diff — see plan_run_id below.
    operation    TEXT NOT NULL CHECK (operation IN ('plan', 'plan_destroy', 'apply', 'destroy', 'refresh')),
    status       TEXT NOT NULL DEFAULT 'queued', -- queued | running | succeeded | failed | cancelled
    triggered_by TEXT,
    -- For an apply/destroy run: the plan run it was reviewed and approved
    -- from — enforces the plan-before-apply guardrail (see services/iac's
    -- run-creation handler): apply requires a same-stack, succeeded,
    -- approved 'plan' run; destroy requires a same-stack, succeeded,
    -- approved 'plan_destroy' run. The unique index below additionally
    -- ensures a given plan run authorizes at most one apply/destroy ever —
    -- an approval is consumed, not indefinitely replayable, since the
    -- state a plan reviewed may no longer match reality by the time it's
    -- reused otherwise.
    plan_run_id  TEXT REFERENCES iac_runs(id) ON DELETE SET NULL,
    approved_by  TEXT,
    approved_at  TIMESTAMPTZ,
    log_ref      TEXT, -- pointer into Loki, same convention as pipeline_runs/stages
    exit_code    INTEGER,
    started_at   TIMESTAMPTZ,
    finished_at  TIMESTAMPTZ,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_iac_runs_stack_id ON iac_runs (stack_id);
CREATE INDEX IF NOT EXISTS idx_iac_runs_org_id ON iac_runs (org_id);
CREATE INDEX IF NOT EXISTS idx_iac_runs_created_at ON iac_runs (created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_iac_runs_plan_run_once ON iac_runs (plan_run_id) WHERE plan_run_id IS NOT NULL;

-- Project-scoped RBAC, on top of (not instead of) the org-wide plan gate
-- below — a project member's role only ever narrows what an
-- already-plan-gated org member can do within one specific project.
CREATE TABLE IF NOT EXISTS iac_project_members (
    id         TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL,
    project_id TEXT NOT NULL REFERENCES iac_projects(id) ON DELETE CASCADE,
    user_id    TEXT NOT NULL,
    role       TEXT NOT NULL DEFAULT 'viewer', -- viewer | operator | admin
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_iac_project_members_project_user ON iac_project_members (project_id, user_id);

-- Enterprise-only: this feature holds live cloud credentials and executes
-- against real infrastructure, a materially higher blast radius than the
-- rest of the platform's Pro-tier features.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS iac_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET iac_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS iac_enabled;
DROP TABLE IF EXISTS iac_project_members;
DROP TABLE IF EXISTS iac_runs;
DROP TABLE IF EXISTS iac_variables;
DROP TABLE IF EXISTS iac_stacks;
DROP TABLE IF EXISTS iac_secrets;
DROP TABLE IF EXISTS iac_vaults;
DROP TABLE IF EXISTS iac_projects;
