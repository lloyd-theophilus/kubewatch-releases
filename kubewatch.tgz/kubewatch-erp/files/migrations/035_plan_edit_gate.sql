-- +goose Up
-- Plan gate for workload editing (Phase 4), mirroring cluster_exec_enabled
-- (030_plan_exec_gate.sql), cluster_portforward_enabled
-- (032_plan_portforward_gate.sql), and cluster_secrets_enabled
-- (033_plan_secrets_gate.sql). Independent of all three — a customer may
-- want any combination of these four capabilities enabled.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_edit_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_edit_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_edit_enabled;
