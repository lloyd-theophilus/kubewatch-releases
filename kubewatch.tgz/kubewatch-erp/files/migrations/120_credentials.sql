-- +goose Up
-- Credentials vault (control-plane / self-hosted copy). SaaS's per-org copy
-- lives in infra/tenant-migrations/062_credentials.sql (same DDL).
--
-- Two tables: credentials (login credentials — password/API key/SSH key,
-- encrypted at rest) and credential_members (per-credential viewer/
-- operator/admin RBAC, same shape as iac_project_members — a credential is
-- only visible to whoever it was explicitly shared with, not to every
-- member of the org just by being in it).
--
-- secret_encrypted/passphrase_encrypted are this feature's whole reason to
-- exist as the second deliberate exception to this codebase's "no at-rest
-- encryption primitive" convention (see
-- infra/tenant-migrations/025_disaster_recovery.sql's comment on that
-- convention, and infra/migrations/079_iac.sql for the first exception) —
-- these columns hold shared/crypto.Vault.EncryptString output, never
-- plaintext.
CREATE TABLE IF NOT EXISTS credentials (
    id                   TEXT PRIMARY KEY,
    org_id               TEXT NOT NULL,
    name                 TEXT NOT NULL,
    type                 TEXT NOT NULL,
    username             TEXT,
    secret_encrypted     TEXT NOT NULL,
    passphrase_encrypted TEXT,
    notes                TEXT,
    created_by           TEXT,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_credentials_org_id ON credentials (org_id);

CREATE TABLE IF NOT EXISTS credential_members (
    credential_id TEXT NOT NULL REFERENCES credentials(id) ON DELETE CASCADE,
    org_id        TEXT NOT NULL,
    user_id       TEXT NOT NULL,
    role          TEXT NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (credential_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_credential_members_user ON credential_members (org_id, user_id);

-- +goose Down
DROP TABLE IF EXISTS credential_members;
DROP TABLE IF EXISTS credentials;
