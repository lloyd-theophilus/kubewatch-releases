-- +goose Up
-- The database-per-tenant migration (070/071/072) never backfilled orgs that
-- signed up before it landed: they have no tenant database (db_name IS NULL)
-- and no user_login_index row, so their users can never log in again (the
-- login path only resolves an org via user_login_index; see
-- services/auth/service.go's handleLogin). That pre-existing data was
-- confirmed disposable test/dev data, so rather than leaving unreachable
-- zombie orgs around (cluttering the operator console and able to collide
-- on organizations.slug for a fresh re-signup), this purges them outright.
-- org_default and org_platform are intentionally excluded: neither ever gets
-- a tenant database by design (self-hosted's single org, and the internal
-- platform/superadmin org respectively), so db_name IS NULL is expected and
-- fine for those two.
--
-- created_at < NOW() - INTERVAL '1 day' guards against this migration
-- itself: this migration runner re-applies every file on every deploy (no
-- applied-migrations tracking), and a brand-new org's db_name is briefly
-- NULL while its tenant database is still being provisioned. Without this
-- guard, any real signup caught mid-provisioning at the moment of a deploy
-- would be silently, permanently deleted by this "one-time" cleanup on
-- every subsequent deploy -- not just once, forever. One day is generous
-- enough to cover any realistic provisioning delay while still safely
-- catching the actual pre-migration orgs this file exists to remove (all
-- of which already predate 070/071/072 by definition).
DELETE FROM users                       WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM api_keys                    WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM agents                      WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM alert_rules                 WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM alerts                      WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM notification_channels       WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM billing_events              WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM integrations                WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM sso_configs                 WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM password_reset_tokens       WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM incidents                   WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM oncall_schedules            WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM agent_registrations         WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM agent_policies              WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM placement_recommendations   WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM model_registry              WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM remediation_playbooks       WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM device_offline_windows      WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');

-- Plain org_id columns with no FK — would just orphan rather than block the
-- organizations delete below, but clean them up too rather than leave junk.
DELETE FROM scheduled_emails            WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM ai_events                    WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM gpu_snapshots                WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM inference_snapshots          WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM latency_probes               WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM api_request_events           WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM app_logs                     WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM scaling_policies             WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM scaling_decisions            WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM agent_commands               WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM load_tests                   WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM exec_sessions                WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM resource_edits               WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM manifest_applies             WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM helm_trusted_repos           WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM helm_releases_requests       WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM agent_policy_decisions       WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');

-- Control-plane routing tables (071/072) — expected to already be empty for
-- these orgs (that's the bug this migration cleans up after), included for
-- safety in case any partial signup left a stray row.
DELETE FROM user_login_index            WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM api_key_index                WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM password_reset_index         WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');
DELETE FROM agent_token_index            WHERE org_id IN (SELECT id FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day');

DELETE FROM organizations WHERE db_name IS NULL AND id NOT IN ('org_default', 'org_platform') AND created_at < NOW() - INTERVAL '1 day';

-- +goose Down
-- Irreversible: the data purged above no longer exists to restore.
