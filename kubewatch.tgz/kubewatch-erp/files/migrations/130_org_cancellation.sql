-- +goose Up
-- Self-serve subscription cancellation (Settings > License). Cancelling
-- does not touch license_expires_at/status -- there is no recurring charge
-- to stop (Paystack checkout is a one-time charge per period, see
-- services/billing/service.go's loadPlanPrices comment), so access simply
-- runs out at the end of the period already paid for, exactly like
-- non-renewal already works. This column only records the customer's
-- stated intent, so we can (a) show it back to them in the dashboard and
-- (b) stop nagging them with renewal-reminder emails they've already said
-- they don't want (services/tenant-mgmt/jobs/license.go).
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS cancel_requested_at TIMESTAMPTZ;

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS cancel_requested_at;
