-- Control-plane cache for live cloud instance pricing (AWS Price List API,
-- Azure Retail Prices API, GCP Cloud Billing Catalog API), fetched lazily by
-- services/cloud/livepricing.go and shared across every org — the returned
-- prices are public catalog data, not tenant-specific, so one shared cache
-- table (like gpu_pricing in 061_gpu_scaling.sql) is correct, not a
-- per-tenant one.
--
-- instance_type is either a real instance/VM type ("c5.xlarge",
-- "Standard_D4s_v3" — AWS/Azure, exact price in hourly_usd) or a synthetic
-- "family:<prefix>" key ("family:e2" — GCP, whose Billing Catalog API has
-- no single exact-match query per machine type, so this instead caches a
-- blended per-vCPU/per-GB rate in per_vcpu_hour/per_gb_hour for that
-- family+region).
CREATE TABLE IF NOT EXISTS live_pricing_cache (
    id BIGSERIAL PRIMARY KEY,
    provider TEXT NOT NULL,
    region TEXT NOT NULL,
    instance_type TEXT NOT NULL,
    hourly_usd DOUBLE PRECISION,
    per_vcpu_hour DOUBLE PRECISION,
    per_gb_hour DOUBLE PRECISION,
    fetched_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (provider, region, instance_type)
);
