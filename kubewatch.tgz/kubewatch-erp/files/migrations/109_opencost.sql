-- +goose Up
-- Latest per-namespace cost allocation from a customer-run OpenCost instance
-- (agent/internal/collectors/opencost.go), replacing the "Namespace Cost
-- Allocation" table's manual-rate usage-share estimate when configured.
-- Mirrors inference_snapshots' "replace the latest snapshot per agent" shape
-- (014_inference.sql).
CREATE TABLE IF NOT EXISTS opencost_snapshots (
    org_id       TEXT NOT NULL,
    agent_id     TEXT NOT NULL,
    namespace    TEXT NOT NULL,
    cpu_cost     DOUBLE PRECISION NOT NULL DEFAULT 0,
    ram_cost     DOUBLE PRECISION NOT NULL DEFAULT 0,
    pv_cost      DOUBLE PRECISION NOT NULL DEFAULT 0,
    network_cost DOUBLE PRECISION NOT NULL DEFAULT 0,
    total_cost   DOUBLE PRECISION NOT NULL DEFAULT 0,
    window_from  TIMESTAMPTZ,
    window_to    TIMESTAMPTZ,
    updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (agent_id, namespace)
);
CREATE INDEX IF NOT EXISTS idx_opencost_snapshots_org ON opencost_snapshots (org_id);

-- +goose Down
DROP TABLE IF EXISTS opencost_snapshots;
