-- +goose Up
-- Tracks whether an org's active paid subscription is billed monthly or
-- yearly. applyUpgrade (services/billing) already computes this to work out
-- the expiry interval but never persisted it, so there was no way to show it
-- back to the org later (Settings > License).
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_period TEXT; -- monthly | yearly | NULL (trial/free)

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS license_period;
