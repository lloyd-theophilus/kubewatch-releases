-- Transactional notification queue. Do not delete pending/dead-letter rows:
-- these are the durable recovery source during producer/consumer/broker outages.
CREATE TABLE IF NOT EXISTS critical_event_outbox (
    id TEXT PRIMARY KEY,
    sequence BIGSERIAL UNIQUE NOT NULL,
    org_id TEXT NOT NULL,
    subject TEXT NOT NULL,
    payload JSONB NOT NULL,
    ordering_key TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    available_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    attempts INTEGER NOT NULL DEFAULT 0,
    delivered_at TIMESTAMPTZ,
    failed_at TIMESTAMPTZ,
    last_error TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_critical_event_pending ON critical_event_outbox (available_at, sequence)
    WHERE delivered_at IS NULL AND failed_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_critical_event_ordering ON critical_event_outbox (org_id, ordering_key, sequence)
    WHERE delivered_at IS NULL AND failed_at IS NULL;
-- Immutable receipts survive later lifecycle transitions. The existing
-- notification_deliveries table remains the user-facing latest delivery view.
CREATE TABLE IF NOT EXISTS critical_event_deliveries (
    event_id TEXT NOT NULL REFERENCES critical_event_outbox(id) ON DELETE CASCADE,
    destination TEXT NOT NULL,
    delivered_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (event_id, destination)
);
