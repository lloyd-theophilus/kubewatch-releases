-- +goose Up
-- DataOps: ETL pipeline orchestration (AWS Glue/Step Functions, Apache
-- Airflow, Azure Data Factory, GCP Dataflow/Composer) and broader
-- multi-cloud resource inventory + lifecycle control (RDS/S3/Lambda today,
-- more resource types planned). See services/dataops/service.go's doc
-- comment for the full design.
--
-- Named "dataops" (not "pipelines") because services/pipelines and
-- /pipelines already mean VCS/CI-CD in this codebase — a real naming
-- collision this avoids outright.
--
-- Deliberately has NO plan_limits gate: unlike every other live-
-- infrastructure-write feature in this codebase (iac_enabled,
-- cluster_node_actions_enabled, agent_self_update_enabled), this feature is
-- available regardless of plan tier, per explicit product decision. Only
-- isAdmin() gates the write routes.

CREATE TABLE IF NOT EXISTS dataops_connections (
    id                TEXT PRIMARY KEY,   -- dopsconn_<hex>
    org_id            TEXT NOT NULL,
    tool              TEXT NOT NULL,      -- aws_glue | aws_stepfunctions | airflow | azure_adf | gcp_dataflow | gcp_composer
    name              TEXT NOT NULL,
    -- Airflow only: flat columns, same shape services/integrations.Integration
    -- already uses for Jenkins/ArgoCD/Prometheus/Grafana (host+port+basic auth).
    host              TEXT NOT NULL DEFAULT '',
    port              INTEGER NOT NULL DEFAULT 0,
    username          TEXT NOT NULL DEFAULT '',
    password          TEXT NOT NULL DEFAULT '',
    tls_enabled       BOOLEAN NOT NULL DEFAULT TRUE,
    -- AWS/Azure/GCP tools: the org's EXISTING cloud_providers connection
    -- (already used for Cloud Costs/cluster discovery), not a duplicate
    -- credential. No DB-level FK across the services/cloud boundary
    -- (matches iac_projects.git_credential_id's convention) — validated at
    -- the application layer.
    cloud_provider_id INTEGER,
    -- Free-form tool addressing that isn't a credential (ADF factory name +
    -- resource group, Composer environment name, default state machine ARN,
    -- etc.) — JSONB so a new field never needs a migration.
    config            JSONB NOT NULL DEFAULT '{}',
    status            TEXT NOT NULL DEFAULT 'unknown', -- healthy | degraded | unreachable | unknown
    last_checked_at   TIMESTAMPTZ,
    last_error        TEXT NOT NULL DEFAULT '',
    enabled           BOOLEAN NOT NULL DEFAULT TRUE,
    created_by        TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_dataops_connections_org ON dataops_connections(org_id);

-- One "feature, one table, with an outcome enum" (the node_actions/
-- manifest_applies/agent_updates convention), covering both runs we
-- triggered (trigger_source='kubewatch') and runs a poller merely observed
-- (trigger_source='discovered').
CREATE TABLE IF NOT EXISTS dataops_etl_runs (
    id                TEXT PRIMARY KEY,   -- etlrun_<hex>
    org_id            TEXT NOT NULL,
    connection_id     TEXT NOT NULL REFERENCES dataops_connections(id) ON DELETE CASCADE,
    tool              TEXT NOT NULL,      -- denormalized from the connection, for cheap filtering
    job_name          TEXT NOT NULL,      -- Glue job name / state machine name / DAG id / ADF pipeline name / Dataflow job name
    external_run_id   TEXT NOT NULL DEFAULT '',
    trigger_source    TEXT NOT NULL,      -- kubewatch | discovered
    triggered_by      TEXT,               -- user id; null when trigger_source='discovered'
    requested_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    started_at        TIMESTAMPTZ,
    finished_at       TIMESTAMPTZ,
    outcome           TEXT NOT NULL DEFAULT 'pending',
        -- pending | running | succeeded | failed | cancelled | cancel_requested | stuck | trigger_failed
    duration_ms       BIGINT,
    error_message     TEXT NOT NULL DEFAULT '',
    metadata          JSONB NOT NULL DEFAULT '{}',  -- vendor-specific extras, no per-field migration needed
    last_polled_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_dataops_etl_runs_org_outcome ON dataops_etl_runs(org_id, outcome);
CREATE INDEX IF NOT EXISTS idx_dataops_etl_runs_connection ON dataops_etl_runs(connection_id, requested_at DESC);
-- The status poller's working set: everything not yet terminal.
CREATE INDEX IF NOT EXISTS idx_dataops_etl_runs_active ON dataops_etl_runs(org_id) WHERE outcome IN ('pending','running','cancel_requested');

-- Broader cloud resource inventory, persisted (unlike services/cloud's
-- fetched-live-per-request CloudResource) so resource actions have a stable
-- row to act against and a list page isn't a live multi-provider fetch on
-- every load. A background sync (services/dataops/poller.go) keeps this
-- fresh.
CREATE TABLE IF NOT EXISTS dataops_resources (
    id                  TEXT PRIMARY KEY,  -- dopsres_<hex>
    org_id              TEXT NOT NULL,
    cloud_provider_id   INTEGER NOT NULL,  -- which cloud_providers row this came from
    provider            TEXT NOT NULL,     -- aws | azure | gcp
    resource_type       TEXT NOT NULL,     -- rds | s3 | lambda | ... (more added in later phases)
    resource_id         TEXT NOT NULL,     -- ARN / resource URI
    name                TEXT NOT NULL,
    region              TEXT NOT NULL DEFAULT '',
    state               TEXT NOT NULL DEFAULT 'unknown', -- vendor vocabulary passed through as-is
    instance_class      TEXT NOT NULL DEFAULT '',
    size_gb             DOUBLE PRECISION,
    monthly_cost        DOUBLE PRECISION,
    metadata            JSONB NOT NULL DEFAULT '{}', -- engine+version, runtime, storage class, etc.
    last_synced_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE UNIQUE INDEX IF NOT EXISTS uq_dataops_resources_identity ON dataops_resources(org_id, cloud_provider_id, resource_id);
CREATE INDEX IF NOT EXISTS idx_dataops_resources_org_type ON dataops_resources(org_id, resource_type);

-- Control-action audit trail. Mirrors node_actions minus every approval
-- column: there is no approval step here, so the row is written AFTER
-- dispatch returns (or fails), not before — there's no "pending" state to
-- model, unlike node_actions' pending_approval.
CREATE TABLE IF NOT EXISTS dataops_resource_actions (
    id             TEXT PRIMARY KEY,  -- dopsact_<hex>
    org_id         TEXT NOT NULL,
    resource_id    TEXT NOT NULL REFERENCES dataops_resources(id) ON DELETE CASCADE,
    resource_type  TEXT NOT NULL,
    action         TEXT NOT NULL,     -- start | stop | resize | delete
    params         JSONB NOT NULL DEFAULT '{}',
    requested_by   TEXT NOT NULL,
    requested_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    outcome        TEXT NOT NULL DEFAULT 'applied', -- applied | apply_failed
    apply_error    TEXT,
    applied_at     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_dataops_resource_actions_org ON dataops_resource_actions(org_id, requested_at DESC);

-- +goose Down
DROP TABLE IF EXISTS dataops_resource_actions;
DROP TABLE IF EXISTS dataops_resources;
DROP TABLE IF EXISTS dataops_etl_runs;
DROP TABLE IF EXISTS dataops_connections;
