-- +goose Up
-- Plan gate for pod port-forward (Phase 2), mirroring cluster_exec_enabled
-- (030_plan_exec_gate.sql) and sso_enabled (003_plan_limits.sql). Independent
-- of cluster_exec_enabled — a customer may want one without the other.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_portforward_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_portforward_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_portforward_enabled;
