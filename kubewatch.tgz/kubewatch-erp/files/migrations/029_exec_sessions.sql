-- +goose Up
-- Interactive pod exec/terminal (KubeWatch Read-Write Cluster IDE, Phase 1).
--
-- Append-only audit log, one row per exec session, following the same shape
-- as scaling_decisions (019_scaling.sql): every session is a new row, never
-- mutated in place except to record its outcome as it progresses.
CREATE TABLE IF NOT EXISTS exec_sessions (
    id           TEXT PRIMARY KEY,          -- sess_<hex>
    org_id       TEXT NOT NULL,
    agent_id     TEXT NOT NULL,
    namespace    TEXT NOT NULL,
    pod_name     TEXT NOT NULL,
    container    TEXT NOT NULL,
    command      TEXT NOT NULL DEFAULT '/bin/sh',
    requested_by TEXT NOT NULL,             -- X-User-ID of the initiating browser session
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_by  TEXT,                      -- reserved for a future approval gate; unused in Phase 1
    started_at   TIMESTAMPTZ,
    ended_at     TIMESTAMPTZ,
    outcome      TEXT NOT NULL DEFAULT 'pending', -- pending | active | closed | denied | error
    close_reason TEXT,                      -- client_disconnect | agent_disconnect | ttl_expired | error
    bytes_in     BIGINT NOT NULL DEFAULT 0,
    bytes_out    BIGINT NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_exec_sessions_org_ts ON exec_sessions (org_id, requested_at DESC);
CREATE INDEX IF NOT EXISTS idx_exec_sessions_agent ON exec_sessions (agent_id, outcome);

-- +goose Down
DROP TABLE IF EXISTS exec_sessions;
