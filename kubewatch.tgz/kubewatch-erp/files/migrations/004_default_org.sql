-- +goose Up
-- Create the default organization that all pre-migration data belongs to
INSERT INTO organizations (id, name, slug, plan, status)
VALUES ('org_default', 'Default Organization', 'default', 'pro', 'active')
ON CONFLICT (id) DO NOTHING;

-- +goose Down
DELETE FROM organizations WHERE id = 'org_default';
