-- +goose Up
-- Per-link click counts for the public marketing site, for the operator
-- console's "Top links" panel (services/tenant-mgmt/marketing_link_clicks.go).
-- Control-plane table, same reasoning as marketing_traffic_daily
-- (121_marketing_traffic.sql): a click isn't owned by any one org. link_id
-- is a small curated identifier (e.g. "docs", "pricing"), not a raw URL --
-- see marketing_link_clicks.go's marketingLinkClickLabels allowlist.
CREATE TABLE IF NOT EXISTS marketing_link_clicks_daily (
    day     DATE NOT NULL,
    link_id TEXT NOT NULL,
    clicks  BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (day, link_id)
);
CREATE INDEX IF NOT EXISTS idx_marketing_link_clicks_daily_day ON marketing_link_clicks_daily (day);

-- +goose Down
DROP TABLE IF EXISTS marketing_link_clicks_daily;
