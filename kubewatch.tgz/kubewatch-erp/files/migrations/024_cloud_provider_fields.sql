-- +goose Up
-- Cloud cost page: fields the dashboard expects on a provider but that the
-- backend never stored. credit_budget is editable from the UI (PATCH); the sync
-- timestamp and last error are set when a provider's billing is fetched.
ALTER TABLE cloud_providers ADD COLUMN IF NOT EXISTS credit_budget DOUBLE PRECISION NOT NULL DEFAULT 0;
ALTER TABLE cloud_providers ADD COLUMN IF NOT EXISTS last_sync_at  TIMESTAMPTZ;
ALTER TABLE cloud_providers ADD COLUMN IF NOT EXISTS last_error    TEXT NOT NULL DEFAULT '';

-- +goose Down
ALTER TABLE cloud_providers DROP COLUMN IF EXISTS last_error;
ALTER TABLE cloud_providers DROP COLUMN IF EXISTS last_sync_at;
ALTER TABLE cloud_providers DROP COLUMN IF EXISTS credit_budget;
