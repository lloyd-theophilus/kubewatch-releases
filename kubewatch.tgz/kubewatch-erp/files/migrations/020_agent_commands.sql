-- +goose Up
-- Command channel (Autoscaler Phase 0). Gives the push-only agent fleet a way to
-- RECEIVE instructions without any inbound port: the agent long-polls this queue
-- on an outbound HTTPS request, exactly like its existing /push call
-- (KubeWatch_ERP_Autoscaler_Architecture.md §3).
--
-- One row per issued command, keyed by a server-generated command_id. Delivery is
-- at-least-once; the agent's executor is idempotent on command_id (§3.5).
CREATE TABLE IF NOT EXISTS agent_commands (
    id           TEXT PRIMARY KEY,            -- command_id, e.g. cmd_<hex>
    org_id       TEXT NOT NULL,
    agent_id     TEXT NOT NULL,
    type         TEXT NOT NULL,               -- noop | docker.scale | docker.rollback (§3.3)
    payload      JSONB,
    status       TEXT NOT NULL DEFAULT 'pending', -- pending | delivered | succeeded | failed | expired
    issued_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at   TIMESTAMPTZ NOT NULL,        -- proposed 2 minutes from issuance (§3.5)
    delivered_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    result       JSONB,
    error        TEXT,
    issued_by    TEXT                          -- acting principal ("system" or a user id)
);
CREATE INDEX IF NOT EXISTS idx_agent_commands_agent_status ON agent_commands (agent_id, status);
CREATE INDEX IF NOT EXISTS idx_agent_commands_org ON agent_commands (org_id, issued_at DESC);

-- +goose Down
DROP TABLE IF EXISTS agent_commands;
