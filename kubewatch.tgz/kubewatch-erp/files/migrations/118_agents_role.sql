-- +goose Up
-- Self-hosted mirror of infra/tenant-migrations/061_agents_role.sql -- see
-- that file's comment. Self-hosted has no per-org Resolver, so its single
-- shared database is built from this directory instead (see
-- services/live-data/service.go's tenantDBForOrg).
ALTER TABLE agents ADD COLUMN IF NOT EXISTS role TEXT NOT NULL DEFAULT 'monitor';

-- +goose Down
ALTER TABLE agents DROP COLUMN IF EXISTS role;
