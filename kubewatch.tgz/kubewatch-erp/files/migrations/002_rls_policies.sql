-- +goose Up
-- NOTE (added later, not part of the original migration): these policies
-- are dead code in the current architecture. They key off
-- current_setting('app.current_org_id', true), which no Go service ever
-- sets (grep the whole codebase for "current_org_id" -- zero hits), so
-- every one of these USING clauses always evaluates against an unset
-- setting. The real tenant-isolation mechanism, per docs/KubeWatch-ERP.md,
-- is a separate physical Postgres database per org (shared/db/tenant.go)
-- plus explicit `WHERE org_id = $N` filtering in every tenant query --
-- these control-plane tables (users/agents/alerts/etc. as they existed
-- when this migration was written) predate that model. Left in place
-- rather than dropped here since disabling RLS on a live table is a real
-- production change that deserves its own deliberate migration + review,
-- not a drive-by edit to a historical file.
--
-- Enable row-level security on all tenant-scoped tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE billing_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations ENABLE ROW LEVEL SECURITY;

-- RLS policies: app sets current_setting('app.current_org_id') per transaction
-- CREATE POLICY has no IF NOT EXISTS form in Postgres, and this migration
-- runner re-applies every file on every deploy (no applied-migrations
-- tracking) -- DROP POLICY IF EXISTS first makes each one safe to re-run
-- against a database that already has it.
DROP POLICY IF EXISTS tenant_isolation_users ON users;
CREATE POLICY tenant_isolation_users ON users
    USING (org_id = current_setting('app.current_org_id', true));

DROP POLICY IF EXISTS tenant_isolation_agents ON agents;
CREATE POLICY tenant_isolation_agents ON agents
    USING (org_id = current_setting('app.current_org_id', true));

DROP POLICY IF EXISTS tenant_isolation_alert_rules ON alert_rules;
CREATE POLICY tenant_isolation_alert_rules ON alert_rules
    USING (org_id = current_setting('app.current_org_id', true));

DROP POLICY IF EXISTS tenant_isolation_alerts ON alerts;
CREATE POLICY tenant_isolation_alerts ON alerts
    USING (org_id = current_setting('app.current_org_id', true));

DROP POLICY IF EXISTS tenant_isolation_notification_channels ON notification_channels;
CREATE POLICY tenant_isolation_notification_channels ON notification_channels
    USING (org_id = current_setting('app.current_org_id', true));

DROP POLICY IF EXISTS tenant_isolation_billing_events ON billing_events;
CREATE POLICY tenant_isolation_billing_events ON billing_events
    USING (org_id = current_setting('app.current_org_id', true));

DROP POLICY IF EXISTS tenant_isolation_integrations ON integrations;
CREATE POLICY tenant_isolation_integrations ON integrations
    USING (org_id = current_setting('app.current_org_id', true));

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_agents_org_id ON agents(org_id);
CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status);
CREATE INDEX IF NOT EXISTS idx_alerts_org_id ON alerts(org_id);
CREATE INDEX IF NOT EXISTS idx_alerts_state ON alerts(state);
CREATE INDEX IF NOT EXISTS idx_alert_rules_org_id ON alert_rules(org_id);
CREATE INDEX IF NOT EXISTS idx_billing_events_org_id ON billing_events(org_id);
CREATE INDEX IF NOT EXISTS idx_billing_events_recorded_at ON billing_events(recorded_at);

-- +goose Down
DROP POLICY IF EXISTS tenant_isolation_integrations ON integrations;
DROP POLICY IF EXISTS tenant_isolation_billing_events ON billing_events;
DROP POLICY IF EXISTS tenant_isolation_notification_channels ON notification_channels;
DROP POLICY IF EXISTS tenant_isolation_alerts ON alerts;
DROP POLICY IF EXISTS tenant_isolation_alert_rules ON alert_rules;
DROP POLICY IF EXISTS tenant_isolation_agents ON agents;
DROP POLICY IF EXISTS tenant_isolation_users ON users;

ALTER TABLE integrations DISABLE ROW LEVEL SECURITY;
ALTER TABLE billing_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE notification_channels DISABLE ROW LEVEL SECURITY;
ALTER TABLE alerts DISABLE ROW LEVEL SECURITY;
ALTER TABLE alert_rules DISABLE ROW LEVEL SECURITY;
ALTER TABLE agents DISABLE ROW LEVEL SECURITY;
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
