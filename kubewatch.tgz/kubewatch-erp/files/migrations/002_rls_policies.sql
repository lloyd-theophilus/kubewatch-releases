-- +goose Up
-- Enable row-level security on all tenant-scoped tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE billing_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations ENABLE ROW LEVEL SECURITY;

-- RLS policies: app sets current_setting('app.current_org_id') per transaction
CREATE POLICY tenant_isolation_users ON users
    USING (org_id = current_setting('app.current_org_id', true));

CREATE POLICY tenant_isolation_agents ON agents
    USING (org_id = current_setting('app.current_org_id', true));

CREATE POLICY tenant_isolation_alert_rules ON alert_rules
    USING (org_id = current_setting('app.current_org_id', true));

CREATE POLICY tenant_isolation_alerts ON alerts
    USING (org_id = current_setting('app.current_org_id', true));

CREATE POLICY tenant_isolation_notification_channels ON notification_channels
    USING (org_id = current_setting('app.current_org_id', true));

CREATE POLICY tenant_isolation_billing_events ON billing_events
    USING (org_id = current_setting('app.current_org_id', true));

CREATE POLICY tenant_isolation_integrations ON integrations
    USING (org_id = current_setting('app.current_org_id', true));

-- Indexes for common query patterns
CREATE INDEX IF NOT EXISTS idx_agents_org_id ON agents(org_id);
CREATE INDEX IF NOT EXISTS idx_agents_status ON agents(status);
CREATE INDEX IF NOT EXISTS idx_alerts_org_id ON alerts(org_id);
CREATE INDEX IF NOT EXISTS idx_alerts_state ON alerts(state);
CREATE INDEX IF NOT EXISTS idx_alert_rules_org_id ON alert_rules(org_id);
CREATE INDEX IF NOT EXISTS idx_billing_events_org_id ON billing_events(org_id);
CREATE INDEX IF NOT EXISTS idx_billing_events_recorded_at ON billing_events(recorded_at);

-- +goose Down
DROP POLICY IF EXISTS tenant_isolation_integrations ON integrations;
DROP POLICY IF EXISTS tenant_isolation_billing_events ON billing_events;
DROP POLICY IF EXISTS tenant_isolation_notification_channels ON notification_channels;
DROP POLICY IF EXISTS tenant_isolation_alerts ON alerts;
DROP POLICY IF EXISTS tenant_isolation_alert_rules ON alert_rules;
DROP POLICY IF EXISTS tenant_isolation_agents ON agents;
DROP POLICY IF EXISTS tenant_isolation_users ON users;

ALTER TABLE integrations DISABLE ROW LEVEL SECURITY;
ALTER TABLE billing_events DISABLE ROW LEVEL SECURITY;
ALTER TABLE notification_channels DISABLE ROW LEVEL SECURITY;
ALTER TABLE alerts DISABLE ROW LEVEL SECURITY;
ALTER TABLE alert_rules DISABLE ROW LEVEL SECURITY;
ALTER TABLE agents DISABLE ROW LEVEL SECURITY;
ALTER TABLE users DISABLE ROW LEVEL SECURITY;
