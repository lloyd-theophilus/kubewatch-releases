-- +goose Up
-- Latest GPU snapshot per agent+device (upserted on each agent push). Powers the
-- GPU section of AI Observability. Time-series history goes to VictoriaMetrics.
CREATE TABLE IF NOT EXISTS gpu_snapshots (
    org_id          TEXT NOT NULL,
    agent_id        TEXT NOT NULL,
    gpu_index       INTEGER NOT NULL,
    name            TEXT NOT NULL DEFAULT '',
    utilization_pct DOUBLE PRECISION NOT NULL DEFAULT 0,
    mem_used_mb     DOUBLE PRECISION NOT NULL DEFAULT 0,
    mem_total_mb    DOUBLE PRECISION NOT NULL DEFAULT 0,
    temp_c          DOUBLE PRECISION NOT NULL DEFAULT 0,
    power_w         DOUBLE PRECISION NOT NULL DEFAULT 0,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (agent_id, gpu_index)
);
CREATE INDEX IF NOT EXISTS idx_gpu_snapshots_org ON gpu_snapshots (org_id);

-- +goose Down
DROP TABLE IF EXISTS gpu_snapshots;
