-- +goose Up
-- Bulk log collection and search: container/pod logs are now continuously
-- collected by the agent (agent/cmd/agent/bulklogs.go) and written to
-- VictoriaLogs regardless of whether anyone has the Logs page open, not
-- only streamed on-demand while a viewer is watching (the pre-existing
-- log_streaming-gated behavior, which stays Pro+ and untouched). This is a
-- distinct capability from that one — available on every plan, including
-- Free, per explicit product decision — so it gets its own flag rather
-- than reusing log_streaming or leaving it ungated (every other feature in
-- this codebase has an explicit plan_limits flag, even when the current
-- answer is "on for everyone," so it stays consistent and toggleable later
-- without a code change).
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS bulk_log_storage_enabled BOOLEAN NOT NULL DEFAULT true;
UPDATE plan_limits SET bulk_log_storage_enabled = true WHERE plan IN ('free', 'pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS bulk_log_storage_enabled;
