-- +goose Up
-- Closes the gap a product-feedback review called out directly: "require
-- every remediation to declare evidence, confidence, blast radius,
-- rollback, and a success predicate tied to an SLO... the strongest
-- differentiator will be verifiable recovery, not the number of actions
-- the platform can trigger." Before this migration, remediation_executions
-- already captured evidence (triggered_by_alert_id/labels/resource_*) and
-- had an unused outcome column anticipating rollback tracking, but nothing
-- computed a confidence signal, declared a blast radius, enforced a
-- per-resource cooldown (only an hourly org-wide budget existed), or ever
-- checked whether an executed action actually fixed the thing that
-- triggered it.

-- cooldown_seconds: minimum spacing between two executions of this
-- playbook on the SAME resource. Distinct from max_auto_executions_per_hour
-- (a budget across ALL resources this playbook might act on) -- this is
-- what actually prevents a restart-loop oscillating on one flapping
-- container/pod, which a shared hourly budget alone doesn't guarantee
-- (five different resources could each burn one slot without ever
-- tripping the org-wide breaker, while the same single resource could
-- legally be restarted repeatedly within an hour under the budget alone).
ALTER TABLE remediation_playbooks ADD COLUMN IF NOT EXISTS cooldown_seconds INTEGER NOT NULL DEFAULT 300;

-- verify_recovery_after_seconds: how long to wait after an executed action
-- before checking whether the alert that triggered it actually resolved.
ALTER TABLE remediation_playbooks ADD COLUMN IF NOT EXISTS verify_recovery_after_seconds INTEGER NOT NULL DEFAULT 300;

-- blast_radius: the human-readable scope of what this specific execution
-- could affect (e.g. "docker container web-1", "all pods of Deployment/web
-- in default") -- computed server-side from the actual target at execution
-- time (restartTarget.describe(), already used for dry-run/deferred log
-- text), never free-text input, so it can't be misleading.
ALTER TABLE remediation_executions ADD COLUMN IF NOT EXISTS blast_radius TEXT;

-- confidence_pct: this playbook's own historical recovery-verified success
-- rate (recovered ÷ (recovered + not_recovered) among its past executions)
-- at the moment this execution was considered -- a computed, grounded
-- signal, not a self-reported number. NULL until the playbook has any
-- verified history yet to compute from.
ALTER TABLE remediation_executions ADD COLUMN IF NOT EXISTS confidence_pct INTEGER;

-- recovery_check_at / recovery_outcome: the actual verifiable-recovery
-- check. recovery_check_at is set to executed_at + the playbook's
-- verify_recovery_after_seconds only for a real 'executed' decision (dry
-- runs/deferred/blocked/skipped executions have nothing to verify);
-- recovery_outcome is filled in by a periodic sweep once that time has
-- passed, by checking whether the triggering alert (or any alert on the
-- same rule+resource) is still firing.
ALTER TABLE remediation_executions ADD COLUMN IF NOT EXISTS recovery_check_at TIMESTAMPTZ;
ALTER TABLE remediation_executions ADD COLUMN IF NOT EXISTS recovery_outcome TEXT; -- recovered | not_recovered | null

CREATE INDEX IF NOT EXISTS idx_remediation_executions_recovery_pending
  ON remediation_executions (recovery_check_at)
  WHERE recovery_check_at IS NOT NULL AND recovery_outcome IS NULL;

-- +goose Down
DROP INDEX IF EXISTS idx_remediation_executions_recovery_pending;
ALTER TABLE remediation_executions DROP COLUMN IF EXISTS recovery_outcome;
ALTER TABLE remediation_executions DROP COLUMN IF EXISTS recovery_check_at;
ALTER TABLE remediation_executions DROP COLUMN IF EXISTS confidence_pct;
ALTER TABLE remediation_executions DROP COLUMN IF EXISTS blast_radius;
ALTER TABLE remediation_playbooks DROP COLUMN IF EXISTS verify_recovery_after_seconds;
ALTER TABLE remediation_playbooks DROP COLUMN IF EXISTS cooldown_seconds;
