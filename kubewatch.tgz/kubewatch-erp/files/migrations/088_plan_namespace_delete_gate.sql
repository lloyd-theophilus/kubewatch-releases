-- +goose Up
-- Dedicated plan gate for namespace delete, deliberately separate from
-- cluster_edit_enabled (which Deployment/StatefulSet/DaemonSet delete and
-- workload editing both reuse): this is a materially higher blast-radius
-- action than either of those, so a plan/org shouldn't get it automatically
-- just by having workload editing enabled.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_namespace_delete_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_namespace_delete_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_namespace_delete_enabled;
