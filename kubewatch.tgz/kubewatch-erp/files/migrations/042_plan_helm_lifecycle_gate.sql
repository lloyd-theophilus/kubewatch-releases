-- +goose Up
-- Plan gate for Helm release lifecycle management (Phase 6), mirroring
-- cluster_generic_apply_enabled (038_plan_generic_apply_gate.sql).
-- Independent of every other cluster_*_enabled flag.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_helm_lifecycle_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_helm_lifecycle_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_helm_lifecycle_enabled;
