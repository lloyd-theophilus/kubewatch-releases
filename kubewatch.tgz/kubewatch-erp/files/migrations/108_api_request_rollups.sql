-- +goose Up
-- Pre-computed API-request observability aggregates (summary/timeseries/
-- routes/error-latency-correlation), refreshed by services/query's rollup
-- ticker (rollups.go) so the Observability "API Requests" tab's read
-- endpoints can serve a cache hit instead of re-running percentile_cont/corr
-- over the raw api_request_events table on every poll. Storage is full JSON
-- blobs per (org, range) so the cron job and the live-query fallback can
-- share the exact same Go structs/marshaling.
CREATE TABLE IF NOT EXISTS api_request_rollups (
    org_id           TEXT NOT NULL,
    range_key        TEXT NOT NULL, -- '1h' | '24h' | '7d' | '30d'
    summary_json     JSONB NOT NULL DEFAULT '{}',
    timeseries_json  JSONB NOT NULL DEFAULT '[]',
    routes_json      JSONB NOT NULL DEFAULT '[]',
    correlation_json JSONB NOT NULL DEFAULT '[]',
    computed_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (org_id, range_key)
);

-- +goose Down
DROP TABLE IF EXISTS api_request_rollups;
