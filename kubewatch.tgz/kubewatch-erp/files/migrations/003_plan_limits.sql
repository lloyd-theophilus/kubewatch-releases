-- +goose Up
CREATE TABLE IF NOT EXISTS plan_limits (
    plan            TEXT PRIMARY KEY,
    max_agents      INTEGER NOT NULL,
    max_users       INTEGER NOT NULL,
    retention_days  INTEGER NOT NULL,
    max_alert_rules INTEGER NOT NULL,
    log_streaming   BOOLEAN NOT NULL DEFAULT false,
    sso_enabled     BOOLEAN NOT NULL DEFAULT false
);

INSERT INTO plan_limits (plan, max_agents, max_users, retention_days, max_alert_rules, log_streaming, sso_enabled) VALUES
    ('free',       2,   1,   3,   5,  false, false),
    ('pro',        20,  10,  30,  50, true,  false),
    ('enterprise', -1,  -1,  365, -1, true,  true)
ON CONFLICT (plan) DO NOTHING;

-- +goose Down
DROP TABLE IF EXISTS plan_limits;
