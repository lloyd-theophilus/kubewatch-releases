-- +goose Up
CREATE TABLE IF NOT EXISTS plan_limits (
    plan            TEXT PRIMARY KEY,
    max_agents      INTEGER NOT NULL,
    max_users       INTEGER NOT NULL,
    retention_days  INTEGER NOT NULL,
    max_alert_rules INTEGER NOT NULL,
    log_streaming   BOOLEAN NOT NULL DEFAULT false,
    sso_enabled     BOOLEAN NOT NULL DEFAULT false
);

-- WHERE NOT EXISTS, not ON CONFLICT (plan): 125_plan_limits_period.sql later
-- widens this table's primary key to (plan, period), which drops the plain
-- `plan` unique constraint ON CONFLICT (plan) depends on -- since this
-- migration runner re-applies every file on every deploy (no
-- applied-migrations tracking), this file re-runs on an already-migrated
-- database where that constraint no longer exists. A plain existence check
-- has no such dependency on any particular constraint shape.
INSERT INTO plan_limits (plan, max_agents, max_users, retention_days, max_alert_rules, log_streaming, sso_enabled)
SELECT v.plan, v.max_agents, v.max_users, v.retention_days, v.max_alert_rules, v.log_streaming, v.sso_enabled
FROM (VALUES
    ('free',       2,   1,   3,   5,  false, false),
    ('pro',        20,  10,  30,  50, true,  false),
    ('enterprise', -1,  -1,  365, -1, true,  true)
) AS v(plan, max_agents, max_users, retention_days, max_alert_rules, log_streaming, sso_enabled)
WHERE NOT EXISTS (SELECT 1 FROM plan_limits WHERE plan_limits.plan = v.plan);

-- +goose Down
DROP TABLE IF EXISTS plan_limits;
