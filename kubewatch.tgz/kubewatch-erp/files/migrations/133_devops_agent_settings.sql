-- +goose Up
-- Log Intelligence spec (intelligence_log/KUBEWATCH-LOG-INTELLIGENCE.md) §6
-- Safety: "confidence gating, default 0.6" -- an admin-configurable minimum
-- rootCauseConfidence a completed ai_diagnoses row must clear before
-- services/devops-agent's engine.go will even draft a dry-run playbook for
-- it. Below the threshold the suggestion stays purely advisory (shown in the
-- UI, never linked into remediation_playbooks) -- same one-row-per-org
-- singleton shape as dr_settings (025_disaster_recovery.sql).
CREATE TABLE IF NOT EXISTS devops_agent_settings (
    org_id                 TEXT PRIMARY KEY,
    min_confidence_to_apply NUMERIC(3,2) NOT NULL DEFAULT 0.60,
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
