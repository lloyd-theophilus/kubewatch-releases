-- +goose Up
-- Mirrors infra/tenant-migrations/047_devops_agent.sql (self-hosted/control-
-- plane copy, applied by the external one-shot migrate job in every
-- deployment mode). See that file's header comment for the full design;
-- see services/devops-agent for the service itself. No plan_limits column
-- here -- diagnosis is deliberately ungated on every plan; autonomous
-- playbook creation reuses the existing autonomous_remediation_enabled
-- column from 064_remediation.sql, unchanged.

CREATE TABLE IF NOT EXISTS devops_agent_llm_connections (
    id                TEXT PRIMARY KEY,
    org_id            TEXT NOT NULL,
    provider          TEXT NOT NULL,
    name              TEXT NOT NULL,
    api_base_url      TEXT,
    model             TEXT NOT NULL,
    encrypted_api_key TEXT NOT NULL,
    is_default        BOOLEAN NOT NULL DEFAULT false,
    status            TEXT NOT NULL DEFAULT 'untested',
    last_checked_at   TIMESTAMPTZ,
    last_error        TEXT,
    created_by        TEXT,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_devops_agent_llm_connections_org ON devops_agent_llm_connections (org_id);
CREATE UNIQUE INDEX IF NOT EXISTS uq_devops_agent_llm_connections_default ON devops_agent_llm_connections (org_id) WHERE is_default;

CREATE TABLE IF NOT EXISTS ai_diagnoses (
    id                             TEXT PRIMARY KEY,
    org_id                         TEXT NOT NULL,
    llm_connection_id              TEXT REFERENCES devops_agent_llm_connections(id) ON DELETE SET NULL,
    trigger_source                 TEXT NOT NULL,
    alert_id                       TEXT REFERENCES alerts(id),
    alert_rule_id                  TEXT REFERENCES alert_rules(id),
    resource_type                  TEXT NOT NULL,
    resource_id                    TEXT NOT NULL,
    agent_id                       TEXT,
    labels                         JSONB,
    log_query                      TEXT,
    log_excerpt                    JSONB,
    status                         TEXT NOT NULL DEFAULT 'pending',
    diagnosis_summary              TEXT,
    diagnosis_detail               TEXT,
    root_cause_confidence          NUMERIC(3,2),
    suggested_action_command_type  TEXT,
    suggested_action_target        JSONB,
    suggested_action_rationale     TEXT,
    remediation_playbook_id        TEXT REFERENCES remediation_playbooks(id) ON DELETE SET NULL,
    llm_provider                   TEXT,
    llm_model                      TEXT,
    prompt_tokens                  INTEGER,
    completion_tokens              INTEGER,
    error                          TEXT,
    created_at                     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at                   TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_ai_diagnoses_org_ts ON ai_diagnoses (org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_diagnoses_resource ON ai_diagnoses (org_id, resource_type, resource_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_ai_diagnoses_alert ON ai_diagnoses (alert_id) WHERE alert_id IS NOT NULL;

ALTER TABLE remediation_playbooks ADD COLUMN IF NOT EXISTS origin TEXT NOT NULL DEFAULT 'manual';
ALTER TABLE remediation_playbooks ADD COLUMN IF NOT EXISTS source_ai_diagnosis_id TEXT REFERENCES ai_diagnoses(id) ON DELETE SET NULL;

-- +goose Down
ALTER TABLE remediation_playbooks DROP COLUMN IF EXISTS source_ai_diagnosis_id;
ALTER TABLE remediation_playbooks DROP COLUMN IF EXISTS origin;
DROP TABLE IF EXISTS ai_diagnoses;
DROP TABLE IF EXISTS devops_agent_llm_connections;
