-- +goose Up
-- Add seeded column to alert_rules for onboarding status
ALTER TABLE alert_rules ADD COLUMN IF NOT EXISTS seeded BOOLEAN NOT NULL DEFAULT false;

-- Add trial columns to organizations
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS trial_ends_at TIMESTAMPTZ;
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS trial_plan TEXT NOT NULL DEFAULT 'pro';

-- Index for trial expiry job
CREATE INDEX IF NOT EXISTS idx_organizations_trial_ends_at ON organizations (trial_ends_at) WHERE trial_ends_at IS NOT NULL;
