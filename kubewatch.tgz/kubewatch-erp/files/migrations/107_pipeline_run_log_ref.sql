-- +goose Up
-- Run-level log reference, parallel to stages.log_ref (075_vcs_cicd.sql) --
-- for providers whose adapter never builds a per-stage breakdown (Jenkins,
-- GitHub Actions this pass), "detailed build logs" falls back to the whole
-- run instead of per-stage. Same opaque provider-specific reference string
-- shape as stages.log_ref (e.g. "build:42", "run:12345"), resolved by
-- services/pipelines' new log-fetch endpoints, not a Loki pointer.
ALTER TABLE pipeline_runs ADD COLUMN IF NOT EXISTS log_ref TEXT;

-- +goose Down
ALTER TABLE pipeline_runs DROP COLUMN IF EXISTS log_ref;
