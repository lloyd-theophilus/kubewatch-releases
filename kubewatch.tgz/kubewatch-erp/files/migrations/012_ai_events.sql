-- +goose Up
-- AI / LLM inference events reported by customer applications (via the org API
-- key). Powers AI Observability: performance (latency), reliability (errors),
-- and cost control (tokens + cost) per model. Tenant-scoped by org_id; works in
-- both self-hosted and SaaS.
CREATE TABLE IF NOT EXISTS ai_events (
    id                BIGSERIAL PRIMARY KEY,
    org_id            TEXT NOT NULL,
    ts                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    provider          TEXT NOT NULL DEFAULT '',
    model             TEXT NOT NULL DEFAULT '',
    operation         TEXT NOT NULL DEFAULT 'chat',
    prompt_tokens     INTEGER NOT NULL DEFAULT 0,
    completion_tokens INTEGER NOT NULL DEFAULT 0,
    total_tokens      INTEGER NOT NULL DEFAULT 0,
    latency_ms        INTEGER NOT NULL DEFAULT 0,
    cost_usd          DOUBLE PRECISION NOT NULL DEFAULT 0,
    status            TEXT NOT NULL DEFAULT 'success',
    error             TEXT,
    metadata          JSONB
);
CREATE INDEX IF NOT EXISTS idx_ai_events_org_ts ON ai_events (org_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_ai_events_org_model ON ai_events (org_id, model);

-- +goose Down
DROP TABLE IF EXISTS ai_events;
