-- Custom branding: per-org accent color and logo, shown in the dashboard
-- shell and (via slug lookup / single-org self-hosted) on the pre-auth
-- login page. All nullable: unset means "use default KubeWatch branding".
ALTER TABLE organizations
  ADD COLUMN brand_color TEXT,
  ADD COLUMN logo_data BYTEA,
  ADD COLUMN logo_content_type TEXT;
