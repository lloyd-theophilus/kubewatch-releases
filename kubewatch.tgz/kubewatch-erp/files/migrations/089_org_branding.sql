-- +goose Up
-- Custom branding: per-org accent color and logo, shown in the dashboard
-- shell and (via slug lookup / single-org self-hosted) on the pre-auth
-- login page. All nullable: unset means "use default KubeWatch branding".
ALTER TABLE organizations
  ADD COLUMN IF NOT EXISTS brand_color TEXT,
  ADD COLUMN IF NOT EXISTS logo_data BYTEA,
  ADD COLUMN IF NOT EXISTS logo_content_type TEXT;
