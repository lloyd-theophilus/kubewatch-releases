-- +goose Up
-- Mirrors infra/tenant-migrations/054_fs_listings.sql exactly -- self-hosted
-- uses this shared control-plane DB directly (never runs tenant-migrations),
-- SaaS gets the same table per-org via that mirror.
CREATE TABLE IF NOT EXISTS fs_listings (
    id           TEXT PRIMARY KEY,
    org_id       TEXT NOT NULL,
    agent_id     TEXT NOT NULL,
    namespace    TEXT,
    pod_name     TEXT,
    container    TEXT NOT NULL,
    path         TEXT NOT NULL,
    requested_by TEXT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    outcome      TEXT NOT NULL DEFAULT 'pending',
    entries      JSONB,
    error        TEXT
);
CREATE INDEX IF NOT EXISTS idx_fs_listings_org_agent ON fs_listings (org_id, agent_id);

-- +goose Down
DROP TABLE IF EXISTS fs_listings;
