-- +goose Up
-- Dedicated plan gate for agent self-update, deliberately separate from
-- cluster_generic_apply_enabled: this pushes a real image update to the
-- Docker-socket-privileged agent container itself (Docker mode) or patches
-- the agent's own DaemonSet (Kubernetes mode) — a materially different risk
-- profile than editing a customer's own cluster resources, so a plan
-- shouldn't get it automatically just by having generic apply enabled.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS agent_self_update_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET agent_self_update_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS agent_self_update_enabled;
