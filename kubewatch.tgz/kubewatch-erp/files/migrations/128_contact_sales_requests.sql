-- +goose Up
-- Public "Contact sales" form submissions (Custom self-hosted/SaaS tiers,
-- past-Enterprise agent counts). Control-plane, not tenant-scoped -- these
-- are prospects, not necessarily existing orgs, same reasoning as
-- 124_bug_reports.sql/121_marketing_traffic.sql.
CREATE TABLE IF NOT EXISTS contact_sales_requests (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    email       TEXT NOT NULL,
    company     TEXT NOT NULL DEFAULT '',
    agent_count TEXT NOT NULL DEFAULT '',
    message     TEXT NOT NULL DEFAULT '',
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- +goose Down
DROP TABLE IF EXISTS contact_sales_requests;
