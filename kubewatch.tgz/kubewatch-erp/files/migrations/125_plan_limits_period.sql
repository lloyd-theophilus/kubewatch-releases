-- +goose Up
-- SaaS agent-cap pricing update: Pro and Enterprise now grant a materially
-- higher agent ceiling on yearly billing than monthly, rather than the same
-- cap regardless of period. plan_limits was keyed by plan alone (one row per
-- plan); widen the key to (plan, period) so both periods' caps coexist under
-- the same table every enforcement path already reads.
--
-- 'free' has no real period distinction (it's never sold monthly or yearly),
-- but a 'yearly' row is added for it anyway so a lookup by either period
-- never misses -- organizations.license_period defaults to 'monthly' via
-- COALESCE everywhere it's read (see services/tenant-mgmt/operator.go), but
-- nothing guarantees a free-tier org's column is actually NULL/'monthly' in
-- every historical row.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS period TEXT NOT NULL DEFAULT 'monthly';
ALTER TABLE plan_limits DROP CONSTRAINT IF EXISTS plan_limits_pkey;
ALTER TABLE plan_limits ADD PRIMARY KEY (plan, period);

INSERT INTO plan_limits (plan, period, max_agents, max_users, retention_days, max_alert_rules, log_streaming, sso_enabled, overage_price_per_agent_cents)
SELECT plan, 'yearly', max_agents, max_users, retention_days, max_alert_rules, log_streaming, sso_enabled, overage_price_per_agent_cents
FROM plan_limits WHERE period = 'monthly'
ON CONFLICT (plan, period) DO NOTHING;

UPDATE plan_limits SET max_agents = 50   WHERE plan = 'pro'        AND period = 'monthly';
UPDATE plan_limits SET max_agents = 100  WHERE plan = 'pro'        AND period = 'yearly';
UPDATE plan_limits SET max_agents = 1000 WHERE plan = 'enterprise' AND period = 'monthly';
UPDATE plan_limits SET max_agents = 1500 WHERE plan = 'enterprise' AND period = 'yearly';

-- +goose Down
DELETE FROM plan_limits WHERE period = 'yearly';
ALTER TABLE plan_limits DROP CONSTRAINT IF EXISTS plan_limits_pkey;
ALTER TABLE plan_limits ADD PRIMARY KEY (plan);
ALTER TABLE plan_limits DROP COLUMN IF EXISTS period;
