-- +goose Up
-- Migration 003 seeded plan_limits via INSERT ... ON CONFLICT (plan) DO
-- NOTHING, so if these rows already existed in a deployed database before
-- 003's current values were introduced, they were never corrected — exactly
-- what 056 found for log_streaming (pro stuck at false), and now sso_enabled
-- (enterprise stuck at false, discovered via the SSO settings page
-- reporting "available on the Enterprise plan" for an org that already is
-- Enterprise). Every later gate migration (030-056) uses a proper
-- ALTER+UPDATE and isn't at risk; this closes the whole risk class for
-- migration 003's original columns in one shot, rather than one column at
-- a time as each is discovered broken.
UPDATE plan_limits SET max_agents = 2, max_users = 1, retention_days = 3, max_alert_rules = 5, log_streaming = false, sso_enabled = false WHERE plan = 'free';
UPDATE plan_limits SET max_agents = 20, max_users = 10, retention_days = 30, max_alert_rules = 50, log_streaming = true, sso_enabled = false WHERE plan = 'pro';
UPDATE plan_limits SET max_agents = -1, max_users = -1, retention_days = 365, max_alert_rules = -1, log_streaming = true, sso_enabled = true WHERE plan = 'enterprise';

-- +goose Down
-- No-op: reverting to "whatever drifted value happened to be there before"
-- isn't a meaningful rollback.
