-- +goose Up
-- Native synthetic/uptime monitoring (services/synthetics): scheduled
-- HTTP/TCP checks against arbitrary targets, independent of the
-- integrations table's own health-check ticker, since these check
-- customer-chosen endpoints (often the customer's own public product),
-- not a connected tool. Also created directly by services/synthetics'
-- own self-managed migrate() in self-hosted mode -- this file is what
-- reaches a fresh SaaS control-plane database and documents the schema.
CREATE TABLE IF NOT EXISTS synthetic_checks (
	id SERIAL PRIMARY KEY,
	org_id TEXT NOT NULL,
	name TEXT NOT NULL,
	check_type TEXT NOT NULL,
	target TEXT NOT NULL,
	http_method TEXT NOT NULL DEFAULT 'GET',
	expected_status_min INTEGER NOT NULL DEFAULT 200,
	expected_status_max INTEGER NOT NULL DEFAULT 299,
	interval_seconds INTEGER NOT NULL DEFAULT 300,
	timeout_seconds INTEGER NOT NULL DEFAULT 10,
	enabled BOOLEAN NOT NULL DEFAULT TRUE,
	status TEXT NOT NULL DEFAULT 'unknown',
	latency_ms INTEGER NOT NULL DEFAULT 0,
	last_checked_at TIMESTAMPTZ,
	last_error TEXT NOT NULL DEFAULT '',
	last_status_code INTEGER NOT NULL DEFAULT 0,
	created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_synthetic_checks_org_id ON synthetic_checks (org_id);

-- Append-only probe history, used for uptime-percentage calculations and a
-- recent-results list; trimmed to a 30-day rolling window by
-- services/synthetics' own background cleanup job, not by this migration.
CREATE TABLE IF NOT EXISTS synthetic_check_results (
	id BIGSERIAL PRIMARY KEY,
	check_id INTEGER NOT NULL REFERENCES synthetic_checks(id) ON DELETE CASCADE,
	org_id TEXT NOT NULL,
	checked_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	success BOOLEAN NOT NULL,
	latency_ms INTEGER NOT NULL,
	status_code INTEGER NOT NULL DEFAULT 0,
	error TEXT NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS idx_synthetic_results_check_id ON synthetic_check_results (check_id, checked_at DESC);
