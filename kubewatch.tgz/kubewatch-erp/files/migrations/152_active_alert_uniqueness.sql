-- Preserve one active lifecycle per (organization, rule, resource). Resolve
-- duplicates in place, retaining notification/audit references to their IDs.
WITH ranked AS (
    SELECT id, ROW_NUMBER() OVER (
        PARTITION BY org_id, rule_id, COALESCE(resource_id, '')
        ORDER BY CASE WHEN state='acknowledged' THEN 0 ELSE 1 END, fired_at, id
    ) AS position
    FROM alerts WHERE state IN ('firing','acknowledged') AND rule_id IS NOT NULL
)
UPDATE alerts SET state='resolved', resolved_at=COALESCE(resolved_at,NOW())
WHERE id IN (SELECT id FROM ranked WHERE position > 1);
CREATE UNIQUE INDEX IF NOT EXISTS idx_alerts_one_active_resource
    ON alerts (org_id, rule_id, (COALESCE(resource_id,'')))
    WHERE state IN ('firing','acknowledged') AND rule_id IS NOT NULL;
