-- +goose Up
-- Application logs ingested via OTLP (OpenTelemetry logs). Surfaced on the Logs
-- page; tenant-scoped by org_id.
CREATE TABLE IF NOT EXISTS app_logs (
    id              BIGSERIAL PRIMARY KEY,
    org_id          TEXT NOT NULL,
    ts              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    severity_number INTEGER NOT NULL DEFAULT 0,
    severity        TEXT NOT NULL DEFAULT '',
    service         TEXT NOT NULL DEFAULT '',
    body            TEXT NOT NULL DEFAULT '',
    trace_id        TEXT,
    attributes      JSONB
);
CREATE INDEX IF NOT EXISTS idx_app_logs_org_ts ON app_logs (org_id, ts DESC);

-- +goose Down
DROP TABLE IF EXISTS app_logs;
