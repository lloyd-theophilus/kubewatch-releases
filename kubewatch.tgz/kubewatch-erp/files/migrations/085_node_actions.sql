-- +goose Up
-- Node power actions (Restart/Stop/Terminate a cloud VM backing a
-- Kubernetes node). Deliberately its OWN table, not another extension of
-- resource_edits: resource_edits is Deployment/StatefulSet/DaemonSet/Pod
-- object-shaped (namespace/kind/name/container, applied by the in-cluster
-- agent), whereas this is a cloud-API-shaped action (instance id/region,
-- applied directly by services/clusters using org-stored cloud credentials,
-- never touching the agent at all).
--
-- No cluster_id/cloud_provider_id FK on purpose: a node here is identified
-- purely by (cloud_provider, instance_id, region/zone/azure_resource_group)
-- as reported by the agent (see agent/internal/collectors/kubernetes.go's
-- providerFromID), and credentials are looked up at approval time by org +
-- cloud_provider type (loadAnyAWSCredsForOrg and its GCP/Azure equivalents
-- in services/clusters/discover.go) rather than a specific cloud_providers
-- row — same reasoning as loadAnyAWSCredsForOrg's existing doc comment: a
-- node isn't tied to one specific connected cloud account any more tightly
-- than a pasted-kubeconfig cluster is.
--
-- Unlike every other approval gate in this codebase (workload edits, pod
-- delete, manifest apply, Helm release: any single admin, including the
-- requester, may approve), Restart/Stop/Terminate require TWO DIFFERENT
-- admins: first_approved_by/first_approved_at record the first approval
-- (outcome moves to 'pending_second_approval'), and the second approve
-- call is rejected with 403 if the approver matches first_approved_by.
-- Terminate is irreversible and Stop/Restart both cause a real outage on
-- that node, which is why this table gets a stricter gate than anything
-- else in the platform. Denial never needs two people: any single admin
-- can deny at either stage, since blocking a destructive action is the
-- fail-safe direction.
CREATE TABLE IF NOT EXISTS node_actions (
    id                   TEXT PRIMARY KEY,
    org_id               TEXT NOT NULL,
    node_name            TEXT NOT NULL,
    action               TEXT NOT NULL, -- 'restart' | 'stop' | 'terminate'
    cloud_provider       TEXT NOT NULL, -- 'aws' | 'gcp' | 'azure'
    instance_id          TEXT NOT NULL,
    region               TEXT NOT NULL DEFAULT '',
    zone                 TEXT NOT NULL DEFAULT '',
    azure_resource_group TEXT NOT NULL DEFAULT '',
    requested_by         TEXT NOT NULL,
    requested_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    first_approved_by    TEXT,
    first_approved_at    TIMESTAMPTZ,
    approved_by          TEXT,
    approved_at          TIMESTAMPTZ,
    denied_by            TEXT,
    denied_at            TIMESTAMPTZ,
    outcome              TEXT NOT NULL DEFAULT 'pending_first_approval',
    apply_error          TEXT,
    applied_at           TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_node_actions_org_outcome ON node_actions(org_id, outcome);

-- +goose Down
DROP TABLE IF EXISTS node_actions;
