-- +goose Up
ALTER TABLE users ADD COLUMN IF NOT EXISTS auth_version BIGINT NOT NULL DEFAULT 1;

-- Keep revocation atomic even when credentials are changed through the CLI.
-- +goose StatementBegin
CREATE OR REPLACE FUNCTION invalidate_user_sessions() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    IF OLD.role IS DISTINCT FROM NEW.role OR OLD.password_hash IS DISTINCT FROM NEW.password_hash THEN
        NEW.auth_version := OLD.auth_version + 1;
    END IF;
    IF OLD.auth_version IS DISTINCT FROM NEW.auth_version THEN
        DELETE FROM trusted_devices WHERE user_id = OLD.id AND org_id = OLD.org_id;
        UPDATE login_otp_codes SET consumed_at = NOW() WHERE user_id = OLD.id AND org_id = OLD.org_id AND consumed_at IS NULL;
    END IF;
    RETURN NEW;
END;
$$;
-- +goose StatementEnd
DROP TRIGGER IF EXISTS users_invalidate_sessions ON users;
CREATE TRIGGER users_invalidate_sessions BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION invalidate_user_sessions();

-- +goose Down
DROP TRIGGER IF EXISTS users_invalidate_sessions ON users;
DROP FUNCTION IF EXISTS invalidate_user_sessions();
ALTER TABLE users DROP COLUMN IF EXISTS auth_version;
