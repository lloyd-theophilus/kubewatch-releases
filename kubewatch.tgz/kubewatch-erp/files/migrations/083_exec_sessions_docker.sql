-- +goose Up
-- Interactive container exec (Docker-mode counterpart of the Kubernetes pod
-- exec 029_exec_sessions.sql added). A Docker-sourced session has no
-- namespace or pod, so both columns need to allow it — the container column
-- already fits either case (a container name within a pod for Kubernetes,
-- the container's own ID for Docker), so no new column is needed for that.
ALTER TABLE exec_sessions ALTER COLUMN namespace DROP NOT NULL;
ALTER TABLE exec_sessions ALTER COLUMN pod_name DROP NOT NULL;

-- +goose Down
ALTER TABLE exec_sessions ALTER COLUMN pod_name SET NOT NULL;
ALTER TABLE exec_sessions ALTER COLUMN namespace SET NOT NULL;
