-- +goose Up
-- GPU and Inference Cost Control (AI-Ops roadmap Feature 2, Phase 2 — see
-- assets/KUBEWATCH-AI-OPS-COMPLETE.md). GPU utilization/memory telemetry and
-- inference-engine scraping already existed before this migration (agent's
-- nvidia-smi and Prometheus-scrape collectors, gpu_utilization_percent/
-- inference_* in VictoriaMetrics, gpu_snapshots/inference_snapshots in
-- Postgres) — this migration adds only the genuinely new pieces: pricing,
-- and GPU-aware autoscaling policy types.
--
-- New policy types extend scaling_policies directly rather than a new table
-- (spec §4.4: "extends the existing autoscaler policy table — new rows, not
-- a new table"), reusing its previous_state/dry_run/decision-log machinery
-- and — for Kubernetes — the exact same declarative desired-manifest/
-- server-side-apply channel (services/live-data/scaling.go,
-- agent/cmd/agent/scaling.go) already built for HPA/NodePool: that
-- reconciler applies whatever manifest it's given, so a Deployment
-- replica-patch (scale_to_zero_on_idle), a GPU resource-request patch
-- (rightsize), or a pair of weighted NodePools (spot_shift) all flow through
-- it with no new agent code.
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS policy_type TEXT NOT NULL DEFAULT 'cpu_memory';
  -- cpu_memory | scale_to_zero_on_idle | rightsize | spot_shift
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS gpu_type TEXT; -- matches gpu_snapshots.name / the gpu_name VM label
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS idle_threshold_seconds INTEGER;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS target_gpu_utilization_percent INTEGER;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS max_spot_fraction NUMERIC;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS current_gpu_count INTEGER;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS desired_gpu_count INTEGER;
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS last_non_idle_at TIMESTAMPTZ;

CREATE TABLE IF NOT EXISTS gpu_pricing (
    gpu_type        TEXT PRIMARY KEY,
    hourly_cost_usd NUMERIC NOT NULL,
    is_spot         BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS gpu_cost_control_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET gpu_cost_control_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS gpu_cost_control_enabled;
DROP TABLE IF EXISTS gpu_pricing;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS last_non_idle_at;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS desired_gpu_count;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS current_gpu_count;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS max_spot_fraction;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS target_gpu_utilization_percent;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS idle_threshold_seconds;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS gpu_type;
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS policy_type;
