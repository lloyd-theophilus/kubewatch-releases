-- +goose Up
-- Control-plane/self-hosted copy of infra/tenant-migrations/071_login_otp.sql
-- (same DDL) -- this file must stay in sync with that one, since a
-- tenant-migrations miss has broken a feature before (rbac_edits shipped
-- broken when only one side was migrated). Self-hosted never writes to
-- these tables (it stays on password auth, see services/auth/service.go's
-- s.tenants branch) but gets the same schema for symmetry with every other
-- users-table-adjacent column/table in this codebase.
CREATE TABLE IF NOT EXISTS login_otp_codes (
    id         TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL,
    user_id    TEXT NOT NULL,
    email      TEXT NOT NULL,
    code_hash  TEXT NOT NULL,
    attempts   INTEGER NOT NULL DEFAULT 0,
    expires_at TIMESTAMPTZ NOT NULL,
    consumed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_login_otp_codes_email ON login_otp_codes (org_id, email);

CREATE TABLE IF NOT EXISTS trusted_devices (
    id               TEXT PRIMARY KEY,
    org_id           TEXT NOT NULL,
    user_id          TEXT NOT NULL,
    device_token_hash TEXT NOT NULL,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_used_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at       TIMESTAMPTZ NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_trusted_devices_user ON trusted_devices (org_id, user_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_trusted_devices_token_hash ON trusted_devices (device_token_hash);
