-- +goose Up
-- Namespace delete (Read-Write Cluster IDE) — by far the most destructive
-- action in the platform if approved: it cascades to every object inside
-- the namespace (pods, services, secrets, configmaps, PVCs, deployments,
-- and so on), unlike a single Deployment/StatefulSet/DaemonSet delete
-- (resource_edits.requested_delete). Its own table for the same reason
-- node_actions (infra/migrations/085_node_actions.sql) got its own table
-- instead of reusing resource_edits: this needs a stricter, purpose-built
-- state machine, not another column bolted onto an envelope built for a
-- narrower risk tier.
--
-- Dispatch is agent-command-shaped (like resource_edits), not
-- cloud-API-shaped (like node_actions): approval enqueues a
-- "namespace.delete" command for the agent that already reports this
-- namespace's resources (see services/live-data's FindAgentForNamespace),
-- which runs the equivalent of `kubectl delete namespace` via the same
-- generic Applier.Delete every other delete action in this codebase uses,
-- then reports back success/failure asynchronously — hence apply_error/
-- applied_at below, mirroring resource_edits' own columns of the same name.
--
-- Requires TWO DIFFERENT admins to approve (first_approved_by/at record the
-- first; the second approve call is rejected if it comes from the same
-- admin), the same gate node_actions uses for irreversible cloud VM
-- actions. Any single admin may deny at either stage — blocking a
-- destructive action is always the fail-safe direction and never needs a
-- second person.
CREATE TABLE IF NOT EXISTS namespace_deletions (
    id                TEXT PRIMARY KEY,
    org_id            TEXT NOT NULL,
    agent_id          TEXT NOT NULL,
    namespace         TEXT NOT NULL,
    requested_by      TEXT NOT NULL,
    requested_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    first_approved_by TEXT,
    first_approved_at TIMESTAMPTZ,
    approved_by       TEXT,
    approved_at       TIMESTAMPTZ,
    denied_by         TEXT,
    denied_at         TIMESTAMPTZ,
    outcome           TEXT NOT NULL DEFAULT 'pending_first_approval',
    apply_error       TEXT,
    applied_at        TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_namespace_deletions_org_outcome ON namespace_deletions(org_id, outcome);

-- +goose Down
DROP TABLE IF EXISTS namespace_deletions;
