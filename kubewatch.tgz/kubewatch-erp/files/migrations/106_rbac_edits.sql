-- +goose Up
-- RBAC edit requests -- namespaced Role/RoleBinding only, never
-- ClusterRole/ClusterRoleBinding (enforced in application code, see
-- services/live-data/rbac_edits.go). Same request -> second-admin-approval
-- -> apply shape as resource_edits (034_resource_edits.sql), kept as its own
-- table rather than folded into resource_edits since RBAC objects carry a
-- full proposed manifest (rules, or subjects+roleRef) rather than a handful
-- of scalar fields (image/replicas), and mixing the two shapes into one wide
-- table would leave most columns NULL for whichever kind of row it isn't.
CREATE TABLE IF NOT EXISTS rbac_edits (
    id                 TEXT PRIMARY KEY,   -- rbacedit_<hex>
    org_id             TEXT NOT NULL,
    agent_id           TEXT NOT NULL,
    kind               TEXT NOT NULL,      -- Role | RoleBinding
    namespace          TEXT NOT NULL,      -- always set -- empty namespace would be a ClusterRole/ClusterRoleBinding in disguise
    name               TEXT NOT NULL,
    action             TEXT NOT NULL,      -- create | update | delete
    manifest           JSONB,              -- proposed object (rules, or subjects+roleRef); NULL for delete
    previous_manifest  JSONB,              -- snapshot before this edit; NULL on create
    requested_by       TEXT NOT NULL,
    requested_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_by        TEXT,
    approved_at        TIMESTAMPTZ,
    denied_by          TEXT,
    denied_at          TIMESTAMPTZ,
    outcome            TEXT NOT NULL DEFAULT 'pending_approval',
        -- pending_approval | approved_pending_apply | applied | apply_failed | denied
    apply_error        TEXT,
    applied_at         TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_rbac_edits_org_status ON rbac_edits (org_id, outcome);
CREATE INDEX IF NOT EXISTS idx_rbac_edits_agent ON rbac_edits (agent_id, outcome);

-- +goose Down
DROP TABLE IF EXISTS rbac_edits;
