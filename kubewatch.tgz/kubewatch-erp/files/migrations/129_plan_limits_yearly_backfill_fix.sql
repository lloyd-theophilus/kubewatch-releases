-- +goose Up
-- Fixes a real bug in 125_plan_limits_period.sql: its INSERT ... SELECT that
-- created the new 'yearly' rows only listed a handful of columns (plan,
-- max_agents, max_users, retention_days, max_alert_rules, log_streaming,
-- sso_enabled, overage_price_per_agent_cents) -- but plan_limits has since
-- grown dozens more boolean feature-gate columns (ai_observability_enabled,
-- vcs_cicd_enabled, auto_scaling_enabled, iac_enabled, and many others added
-- by migrations 030-117). Every one of those columns was silently left at
-- its schema default (false) on every newly-inserted yearly row instead of
-- copying the real value from that plan's monthly row -- meaning any org on
-- yearly billing lost every one of those entitlements outright (caught by a
-- CI smoke-test failure: Enterprise/Pro features 403ing with "available on
-- the X plan" for the yearly test org).
--
-- The fix copies every column except plan/period/max_agents from each
-- plan's monthly row onto its yearly row, using dynamic SQL so it covers
-- whatever columns exist today without needing them named here individually
-- (and so it doesn't silently rot the next time a plan_*_gate migration
-- adds one more). max_agents is deliberately excluded -- that's the one
-- column 125/126/127 intentionally made different between periods.
-- +goose StatementBegin
DO $$
DECLARE
    col_list text;
    set_clause text;
BEGIN
    SELECT string_agg(quote_ident(column_name), ', ')
      INTO col_list
      FROM information_schema.columns
     WHERE table_name = 'plan_limits'
       AND column_name NOT IN ('plan', 'period', 'max_agents');

    SELECT string_agg(quote_ident(column_name) || ' = m.' || quote_ident(column_name), ', ')
      INTO set_clause
      FROM information_schema.columns
     WHERE table_name = 'plan_limits'
       AND column_name NOT IN ('plan', 'period', 'max_agents');

    IF col_list IS NOT NULL THEN
        EXECUTE format(
            'UPDATE plan_limits y SET %s FROM plan_limits m WHERE m.plan = y.plan AND m.period = ''monthly'' AND y.period = ''yearly''',
            set_clause
        );
    END IF;
END $$;
-- +goose StatementEnd

-- +goose Down
-- No-op: reverting to "whatever incomplete value happened to be there
-- before" isn't a meaningful rollback (same reasoning as 058/067's own
-- down migrations for this table).
