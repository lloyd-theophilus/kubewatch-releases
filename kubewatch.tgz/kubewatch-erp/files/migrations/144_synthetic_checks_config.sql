-- Catchpoint import support (services/synthetics' "catchpoint" check_type):
-- an existing Catchpoint test's API key + test ID, vault-encrypted at rest
-- the same way integrations.config/vcs_connections.config already are.
-- Blank for every http/tcp check, which need no credential at all.
ALTER TABLE synthetic_checks ADD COLUMN IF NOT EXISTS config TEXT NOT NULL DEFAULT '';
