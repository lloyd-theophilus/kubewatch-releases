-- +goose Up
-- VCS & CI/CD Observability bug-sweep fixes, round 2 — control-plane /
-- self-hosted copy. SaaS's per-org copy lives in
-- infra/tenant-migrations/029_vcs_cicd_bugfix2.sql (same DDL).
--
-- uq_pipeline_runs_natural_key (075_vcs_cicd.sql) is
-- (connection_id, pipeline_name, COALESCE(run_number, -1)) — fine for every
-- provider that supplies a real run_number, but Tekton's PipelineRuns
-- (agent/internal/crdwatch/tekton.go) never do, and a future generic
-- webhook-mapping connection wouldn't either. For those, every distinct run
-- of the same pipeline_name with no run_number collapses onto the same
-- COALESCE(-1) key and gets merged into one row via the upsert's DO UPDATE.
-- Tekton avoids this in practice today by using each PipelineRun's own
-- (Kubernetes-unique) object name as pipeline_name, but the schema itself
-- shouldn't rely on that being true of every future no-run_number producer.
-- Adding triggering_commit_sha as a second fallback component is a no-op
-- for every provider that already has a real run_number (their identity is
-- unaffected — commit_sha stays constant across repeated pushes of the same
-- run, so it never turns an update into a spurious duplicate insert), and
-- gives no-run_number producers a real, if imperfect, second axis of
-- distinction instead of none at all.
DROP INDEX IF EXISTS uq_pipeline_runs_natural_key;
CREATE UNIQUE INDEX IF NOT EXISTS uq_pipeline_runs_natural_key
    ON pipeline_runs (connection_id, pipeline_name, COALESCE(run_number, -1), COALESCE(triggering_commit_sha, ''));

-- +goose Down
DROP INDEX IF EXISTS uq_pipeline_runs_natural_key;
CREATE UNIQUE INDEX IF NOT EXISTS uq_pipeline_runs_natural_key
    ON pipeline_runs (connection_id, pipeline_name, COALESCE(run_number, -1));
