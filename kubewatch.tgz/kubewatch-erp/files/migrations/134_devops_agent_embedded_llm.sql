-- Log Intelligence spec (intelligence_log/KUBEWATCH-LOG-INTELLIGENCE.md) §2
-- Provider Router "embedded" tier: a locally-run model (see
-- installer/docker-compose.selfhost.yml's embedded-llm service), so a
-- self-hosted install gets AI log diagnosis with no BYOK key and no
-- per-token cost out of the box. is_embedded distinguishes the
-- auto-provisioned connection services/devops-agent/embedded.go seeds from
-- one an admin configured by hand, purely for the frontend badge/guardrails
-- (e.g. warning before deleting the org's only free option) -- it changes
-- no request-handling behavior of its own.
ALTER TABLE devops_agent_llm_connections ADD COLUMN IF NOT EXISTS is_embedded BOOLEAN NOT NULL DEFAULT false;
