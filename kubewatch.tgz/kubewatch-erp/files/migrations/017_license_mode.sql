-- +goose Up
-- How an org's license was activated: 'saas' (subscribed/paid on the platform)
-- or 'selfhost' (issued an offline Ed25519 key to run their own ERP). Shown on
-- the operator console.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_mode TEXT NOT NULL DEFAULT 'saas';

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS license_mode;
