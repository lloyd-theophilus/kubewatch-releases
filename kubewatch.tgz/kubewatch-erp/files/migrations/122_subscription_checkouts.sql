-- +goose Up
-- Tracks a SaaS subscription checkout from initiation (handleUpgrade) through
-- confirmation (handlePaystackWebhook / handleVerify), mirroring
-- selfhost_purchases' exact reference-tracking shape
-- (028_selfhost_purchases.sql) -- that table already solved this same
-- problem for the self-hosted purchase flow; the SaaS subscription flow had
-- no equivalent at all, so applyUpgrade could be replayed with an old but
-- still-validly-signed webhook body (nothing recorded which reference had
-- already been processed), and handleUpgrade had no way to notice a
-- still-outstanding checkout before minting a brand new one on a
-- double-click. Control-plane table (not tenant-scoped): a checkout belongs
-- to the control-plane organizations row, not any tenant database.
CREATE TABLE IF NOT EXISTS subscription_checkouts (
    reference  TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL,
    plan       TEXT NOT NULL,
    period     TEXT NOT NULL,
    amount     BIGINT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'pending', -- pending | applied
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    applied_at TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_subscription_checkouts_org_pending ON subscription_checkouts (org_id, status, created_at);

-- +goose Down
DROP TABLE IF EXISTS subscription_checkouts;
