-- +goose Up
-- Integrations (Slack, PagerDuty, webhooks) is a Pro-and-above feature per
-- the marketing pricing page. Gated the same way as every other plan-limits
-- flag: one boolean column, enforced via a fresh DB join in
-- services/integrations rather than trusting a header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS integrations_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET integrations_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS integrations_enabled;
