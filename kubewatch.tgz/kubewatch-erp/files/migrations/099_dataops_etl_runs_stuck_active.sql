-- +goose Up
-- services/dataops/poller.go's pollOrgActiveRuns now keeps polling 'stuck'
-- runs (a run past etlStuckAfter with no terminal vendor status yet) instead
-- of abandoning them forever -- Glue/Dataflow-style batch jobs routinely run
-- well past the 6-hour stuck threshold, and the vendor DOES eventually
-- report a real terminal status for them, unlike agent self-update's
-- identically-named 'stuck' state (services/live-data/agent_updates.go),
-- which has no reliable success signal at all. idx_dataops_etl_runs_active
-- (095_dataops.sql) predates this and only covers
-- pending/running/cancel_requested, so the poller's query for 'stuck' rows
-- would fall back to a full scan without this update.
DROP INDEX IF EXISTS idx_dataops_etl_runs_active;
CREATE INDEX IF NOT EXISTS idx_dataops_etl_runs_active ON dataops_etl_runs(org_id)
    WHERE outcome IN ('pending','running','cancel_requested','stuck');

-- +goose Down
DROP INDEX IF EXISTS idx_dataops_etl_runs_active;
CREATE INDEX IF NOT EXISTS idx_dataops_etl_runs_active ON dataops_etl_runs(org_id)
    WHERE outcome IN ('pending','running','cancel_requested');
