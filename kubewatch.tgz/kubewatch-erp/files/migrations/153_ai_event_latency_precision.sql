-- OTLP durations retain sub-millisecond precision. Integer milliseconds rejected
-- those events instead of recording them. Existing integer values remain exact.
ALTER TABLE ai_events
    ALTER COLUMN latency_ms TYPE DOUBLE PRECISION USING latency_ms::DOUBLE PRECISION;
