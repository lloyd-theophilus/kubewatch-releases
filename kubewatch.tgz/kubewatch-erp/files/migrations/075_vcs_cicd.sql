-- +goose Up
-- VCS & CI/CD Observability (kubewatch-vcs-cicd/KUBEWATCH-VCS-CICD-OBSERVABILITY.md,
-- Phase 1) — control-plane / self-hosted copy. SaaS's per-org copy lives in
-- infra/tenant-migrations/026_vcs_cicd.sql (same DDL, applied to each org's
-- own tenant database instead); self-hosted has only the one shared database
-- this file targets. Gated to Pro/Enterprise via plan_limits.vcs_cicd_enabled
-- below (added after the spec's own silence on plan-gating was overridden).
CREATE TABLE IF NOT EXISTS vcs_connections (
    id                              TEXT PRIMARY KEY,
    org_id                          TEXT NOT NULL,
    provider                        TEXT NOT NULL,
    tier                            INTEGER NOT NULL,
    scope                           TEXT NOT NULL,
    auth_type                       TEXT NOT NULL DEFAULT '',
    config                          JSONB NOT NULL DEFAULT '{}',
    poll_interval_seconds           INTEGER NOT NULL DEFAULT 60,
    enabled                         BOOLEAN NOT NULL DEFAULT TRUE,
    last_success_at                 TIMESTAMPTZ,
    consecutive_failures            INTEGER NOT NULL DEFAULT 0,
    effective_poll_interval_seconds INTEGER,
    created_at                      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_vcs_connections_org_id ON vcs_connections (org_id);

CREATE TABLE IF NOT EXISTS code_events (
    id            TEXT PRIMARY KEY,
    org_id        TEXT NOT NULL,
    connection_id TEXT NOT NULL REFERENCES vcs_connections(id) ON DELETE CASCADE,
    event_type    TEXT NOT NULL,
    branch        TEXT,
    commit_sha    TEXT,
    author        TEXT,
    message       TEXT,
    additions     INTEGER,
    deletions     INTEGER,
    files_changed INTEGER,
    pr_number     INTEGER,
    occurred_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_code_events_org_id ON code_events (org_id);
CREATE INDEX IF NOT EXISTS idx_code_events_connection_id ON code_events (connection_id);
CREATE INDEX IF NOT EXISTS idx_code_events_occurred_at ON code_events (occurred_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_code_events_natural_key
    ON code_events (connection_id, event_type, commit_sha, COALESCE(branch, ''));

CREATE TABLE IF NOT EXISTS pipeline_runs (
    id                    TEXT PRIMARY KEY,
    org_id                TEXT NOT NULL,
    connection_id         TEXT NOT NULL REFERENCES vcs_connections(id) ON DELETE CASCADE,
    pipeline_name         TEXT NOT NULL,
    run_number            INTEGER,
    trigger_type          TEXT,
    triggering_commit_sha TEXT,
    triggering_branch     TEXT,
    status                TEXT NOT NULL DEFAULT 'running',
    started_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    finished_at           TIMESTAMPTZ,
    duration_seconds      INTEGER,
    artifacts             JSONB NOT NULL DEFAULT '[]'
);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_org_id ON pipeline_runs (org_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_connection_id ON pipeline_runs (connection_id);
CREATE INDEX IF NOT EXISTS idx_pipeline_runs_started_at ON pipeline_runs (started_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_pipeline_runs_natural_key
    ON pipeline_runs (connection_id, pipeline_name, COALESCE(run_number, -1));

CREATE TABLE IF NOT EXISTS stages (
    id              TEXT PRIMARY KEY,
    pipeline_run_id TEXT NOT NULL REFERENCES pipeline_runs(id) ON DELETE CASCADE,
    name            TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'running',
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    log_ref         TEXT
);
CREATE INDEX IF NOT EXISTS idx_stages_pipeline_run_id ON stages (pipeline_run_id);

CREATE TABLE IF NOT EXISTS deployment_markers (
    id                         TEXT PRIMARY KEY,
    org_id                     TEXT NOT NULL,
    connection_id              TEXT NOT NULL REFERENCES vcs_connections(id) ON DELETE CASCADE,
    pipeline_run_id            TEXT REFERENCES pipeline_runs(id) ON DELETE SET NULL,
    commit_sha                 TEXT,
    target_type                TEXT NOT NULL,
    target_ref                 TEXT NOT NULL,
    version_tag                TEXT,
    deployed_at                TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    status                     TEXT NOT NULL DEFAULT 'success',
    rolled_back_from_marker_id TEXT REFERENCES deployment_markers(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_deployment_markers_org_id ON deployment_markers (org_id);
CREATE INDEX IF NOT EXISTS idx_deployment_markers_connection_id ON deployment_markers (connection_id);
CREATE INDEX IF NOT EXISTS idx_deployment_markers_target_ref ON deployment_markers (target_ref);
CREATE INDEX IF NOT EXISTS idx_deployment_markers_deployed_at ON deployment_markers (deployed_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS uq_deployment_markers_natural_key
    ON deployment_markers (connection_id, target_ref, COALESCE(commit_sha, ''));

-- VCS & CI/CD Observability is a Pro/Enterprise feature, same gating
-- mechanism as Disaster Recovery/Edge Fleet (065_edge_devices.sql,
-- 074_dr_schedule_index.sql) — org_effective_plan already treats an active
-- 30-day trial as enterprise, so trial orgs get full access until their
-- trial ends without any extra logic here.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS vcs_cicd_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET vcs_cicd_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS vcs_cicd_enabled;
DROP TABLE IF EXISTS deployment_markers;
DROP TABLE IF EXISTS stages;
DROP TABLE IF EXISTS pipeline_runs;
DROP TABLE IF EXISTS code_events;
DROP TABLE IF EXISTS vcs_connections;
