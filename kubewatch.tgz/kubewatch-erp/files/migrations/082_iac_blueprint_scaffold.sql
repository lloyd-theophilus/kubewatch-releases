-- +goose Up
-- Blueprint gallery scaffolding: creating a Stack from a built-in
-- blueprint (see services/iac/blueprints.go's static builtinBlueprints
-- catalog) enqueues a 'scaffold' run that writes the blueprint's starter
-- files into the project's own Git repo and pushes a new commit, so the
-- Stack has real content to plan/check against immediately. The files and
-- commit message for one specific scaffold run are stored here rather
-- than re-derived from the blueprint catalog at execution time, so the
-- worker (services/iac-worker) never needs its own copy of the catalog
-- and a later edit to a blueprint's template can't change what an
-- already-queued run pushes.
--
-- scaffold_payload never holds a real secret value: a blueprint's files
-- reference configurable/sensitive values as var.<name> (OpenTofu) or
-- {{ name }} (Ansible), resolved only at plan/apply/check/run time from
-- iac_variables/iac_secrets the same way any other Stack's files are,
-- never baked into what gets committed to Git.
ALTER TABLE iac_runs ADD COLUMN IF NOT EXISTS scaffold_payload JSONB;

ALTER TABLE iac_runs DROP CONSTRAINT IF EXISTS iac_runs_operation_check;
ALTER TABLE iac_runs ADD CONSTRAINT iac_runs_operation_check CHECK (operation IN ('plan', 'plan_destroy', 'apply', 'destroy', 'refresh', 'check', 'run', 'scaffold'));

-- +goose Down
ALTER TABLE iac_runs DROP CONSTRAINT IF EXISTS iac_runs_operation_check;
ALTER TABLE iac_runs ADD CONSTRAINT iac_runs_operation_check CHECK (operation IN ('plan', 'plan_destroy', 'apply', 'destroy', 'refresh', 'check', 'run'));
ALTER TABLE iac_runs DROP COLUMN IF EXISTS scaffold_payload;
