-- +goose Up
-- Jira/ServiceNow/Statuspage/Salesforce incident-sync (services/notification/
-- incidents_notify.go) need to update the SAME external ticket across an
-- incident's declared -> updated -> resolved lifecycle, not create a new
-- one each time. notification_deliveries already upserts one row per
-- (alert_id, channel_id) pair across that whole lifecycle (see
-- recordDelivery's ON CONFLICT), so this column just rides along on that
-- existing row instead of needing a new table.
ALTER TABLE notification_deliveries ADD COLUMN IF NOT EXISTS external_ref TEXT NOT NULL DEFAULT '';
