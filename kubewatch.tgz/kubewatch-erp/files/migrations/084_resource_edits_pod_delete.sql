-- +goose Up
-- Pod delete/restart (Read-Write Cluster IDE) — reuses the resource_edits
-- approval envelope already built for Deployment/StatefulSet/DaemonSet edits,
-- extended to a fourth kind: "Pod" (container stored as '' for these rows,
-- since the action targets the whole pod, not one container within it).
-- requested_restart=true and requested_delete=true both resolve to the exact
-- same agent action (delete the pod, letting its controller recreate it) —
-- the two columns exist only so the audit trail is honest about which one
-- was actually requested: restart implies "expected to come back" (only
-- offered when the pod has an owner), delete is offered unconditionally.
ALTER TABLE resource_edits ADD COLUMN IF NOT EXISTS requested_delete BOOLEAN NOT NULL DEFAULT false;

-- +goose Down
ALTER TABLE resource_edits DROP COLUMN IF EXISTS requested_delete;
