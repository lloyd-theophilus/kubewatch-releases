-- +goose Up
-- Self-hosted purchases are now a one-time, perpetual-use license (see
-- services/billing/selfhost.go) rather than a recurring monthly/yearly
-- subscription, so `period` no longer has a meaningful value to store for
-- new rows -- kept (nullable) rather than dropped so existing historical
-- rows stay intact and queryable.
ALTER TABLE selfhost_purchases ALTER COLUMN period DROP NOT NULL;

-- Distinguishes an original license purchase from a later "renew updates
-- for another year" purchase against an already-issued license -- a renewal
-- extends licenses.update_eligible_until on the existing license rather
-- than issuing a new key (see handleSelfhostRenew).
ALTER TABLE selfhost_purchases ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'purchase'
    CHECK (kind IN ('purchase', 'renewal'));

-- +goose Down
ALTER TABLE selfhost_purchases DROP COLUMN IF EXISTS kind;
ALTER TABLE selfhost_purchases ALTER COLUMN period SET NOT NULL;
