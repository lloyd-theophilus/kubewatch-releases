-- Log Intelligence spec §3/§6/§7: "redaction_enabled bool. Default true;
-- embedded and self_hosted may disable, since neither sends data outside
-- the deployment's own trust boundary" -- an admin-configurable toggle per
-- connection, not just the automatic exception for the built-in embedded
-- one (services/devops-agent/embedded.go). A customer's own self-hosted
-- endpoint (configured as a regular BYOK "openai_compatible" connection)
-- has the same trust-boundary argument the spec makes for `self_hosted`,
-- but this service has no way to infer that automatically -- so it stays a
-- deliberate, explicit admin choice, defaulting to the safe "on".
ALTER TABLE devops_agent_llm_connections ADD COLUMN IF NOT EXISTS redaction_enabled BOOLEAN NOT NULL DEFAULT true;
