-- +goose Up
-- SaaS Enterprise's yearly agent cap now matches self-hosted Enterprise's
-- flat 2,000-agent ceiling exactly (services/billing/selfhost.go's
-- selfhostPlans["enterprise"].maxAgents), rather than sitting below it at
-- 1,500 (set by 125_plan_limits_period.sql). Monthly stays at 1,000 --
-- yearly billing is still the one that unlocks the higher ceiling.
UPDATE plan_limits SET max_agents = 2000 WHERE plan = 'enterprise' AND period = 'yearly';

-- +goose Down
UPDATE plan_limits SET max_agents = 1500 WHERE plan = 'enterprise' AND period = 'yearly';
