-- +goose Up
-- Plan gate for secret metadata viewing (Phase 3b), mirroring
-- cluster_exec_enabled (030_plan_exec_gate.sql) and cluster_portforward_enabled
-- (032_plan_portforward_gate.sql). Independent of both — a customer may want
-- any combination of these three enabled.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_secrets_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_secrets_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_secrets_enabled;
