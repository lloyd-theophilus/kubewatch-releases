-- +goose Up
-- Lets a Stack declare which already-monitored cluster or host it actually
-- targets, cross-referencing services/clusters' cluster registry and the
-- agents table rather than inventing a parallel one — Infrastructure
-- Automation still never owns state or decides what a Stack talks to (that's
-- entirely the Stack's own OpenTofu provider config); this is purely a
-- declared, informational link so the dashboard can show "this Stack
-- manages that cluster/host" and cross-navigate between them.
ALTER TABLE iac_stacks ADD COLUMN IF NOT EXISTS target_kind TEXT CHECK (target_kind IN ('cluster', 'agent'));
ALTER TABLE iac_stacks ADD COLUMN IF NOT EXISTS target_id TEXT;

-- +goose Down
ALTER TABLE iac_stacks DROP COLUMN IF EXISTS target_kind;
ALTER TABLE iac_stacks DROP COLUMN IF EXISTS target_id;
