-- +goose Up
-- Self-hosted license activation stamps this so a later organization rename
-- can be reported back to the central license server (which the operator
-- console reads for its License registry), without ever storing or needing
-- the raw key again — see services/query/settings.go's updateOrg and
-- services/license's /v1/report-org-name.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_key_hash TEXT;

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS license_key_hash;
