-- +goose Up
-- Full Helm release lifecycle (install/upgrade/rollback/uninstall), the
-- riskiest capability in the Read-Write Cluster IDE roadmap: Helm's SDK
-- applies directly via its own internal client, bypassing
-- k8sapply.Applier's generic-apply allow-list entirely — a chart can define
-- almost any namespaced object with no field restrictions Phase 5 imposes.
-- A dedicated table, not a generalization of manifest_applies: chart ref/
-- version, values YAML, release identity, target revision, and rendered
-- manifest have no analog there.
CREATE TABLE IF NOT EXISTS helm_releases_requests (
    id                        TEXT PRIMARY KEY,     -- hop_<hex>
    org_id                    TEXT NOT NULL,
    agent_id                  TEXT NOT NULL,
    operation                 TEXT NOT NULL,        -- install | upgrade | rollback | uninstall
    repo_id                   TEXT REFERENCES helm_trusted_repos(id), -- NULL for rollback/uninstall
    chart_name                TEXT,
    chart_version             TEXT,
    release_name              TEXT NOT NULL,
    release_namespace         TEXT NOT NULL,
    values_yaml               TEXT,
    target_revision           INTEGER,              -- rollback only
    previous_release_snapshot JSONB,                 -- {revision, chartVersion, valuesYaml} captured pre-op
    -- Rendering (action.Install{ClientOnly:true}/Upgrade{DryRun:true}) needs
    -- no live cluster RBAC at all — pure local chart-template execution — so
    -- it happens eagerly at request time, before any approval. Immutable
    -- once set: approval echoes rendered_manifest_sha256, a mismatch is a
    -- 409, rather than re-rendering in place.
    rendered_manifest         TEXT,
    rendered_manifest_sha256  TEXT,
    rendered_at               TIMESTAMPTZ,
    render_error              TEXT,
    requested_by              TEXT NOT NULL,
    requested_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    approved_by               TEXT,
    approved_at               TIMESTAMPTZ,
    denied_by                 TEXT,
    denied_at                 TIMESTAMPTZ,
    outcome                   TEXT NOT NULL DEFAULT 'pending_render',
        -- pending_render | render_failed | pending_approval | approved_pending_apply
        -- | applied | apply_failed | denied
    apply_error               TEXT,
    applied_at                TIMESTAMPTZ,
    reverts_id                TEXT REFERENCES helm_releases_requests(id)
);
CREATE INDEX IF NOT EXISTS idx_helm_releases_requests_org_status ON helm_releases_requests (org_id, outcome);
CREATE INDEX IF NOT EXISTS idx_helm_releases_requests_agent ON helm_releases_requests (agent_id, outcome);

-- +goose Down
DROP TABLE IF EXISTS helm_releases_requests;
