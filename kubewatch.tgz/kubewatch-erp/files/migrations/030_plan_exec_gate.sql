-- +goose Up
-- Plan gate for interactive pod exec (Phase 1), mirroring sso_enabled
-- (003_plan_limits.sql). Kept as its own migration, separate from
-- 029_exec_sessions.sql, so a `goose down` of either doesn't entangle the
-- other.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_exec_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_exec_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_exec_enabled;
