-- +goose Up
-- Autonomous Remediation (AI-Ops roadmap Feature 5, Phase 3 — see
-- assets/KUBEWATCH-AI-OPS-COMPLETE.md). The spec envisions playbooks
-- matching a generic condition_type + source_feature pair shared across every
-- alerting subsystem; in this codebase the only thing that actually publishes
-- to NATS is the original Alert-Engine (alerts.fire.<org>, from alert_rules/
-- alerts), and Phase 1/2's own policy engines (agent-ops, scaling-engine)
-- already self-remediate internally — they never publish an event for this
-- engine to consume. So a playbook here matches a specific alert_rules row
-- (trigger_rule_id) rather than an abstract condition_type/source_feature
-- pair, which is the real available matching key and is unambiguous where
-- the spec's imagined taxonomy would otherwise be speculative.
CREATE TABLE IF NOT EXISTS remediation_playbooks (
    id                           TEXT PRIMARY KEY,
    org_id                       TEXT NOT NULL REFERENCES organizations(id),
    name                         TEXT NOT NULL,
    trigger_rule_id              TEXT NOT NULL REFERENCES alert_rules(id) ON DELETE CASCADE,
    -- docker.restart | k8s.rolling_restart — validated against the firing
    -- alert's resource_type at match time (services/remediation-engine),
    -- not here, since resource_type varies per alert instance, not per rule.
    action_command_type          TEXT NOT NULL,
    -- requires_human_approval defaults to true for any action type until a
    -- human deliberately downgrades it (spec §7) — both action types this
    -- feature ships with start in that tier.
    requires_human_approval      BOOLEAN NOT NULL DEFAULT true,
    max_auto_executions_per_hour INTEGER NOT NULL DEFAULT 3,
    dry_run_required_first       BOOLEAN NOT NULL DEFAULT true,
    -- draft | dry_run_only | active | disabled. A playbook is created in
    -- dry_run_only and can only move to active after its first match has
    -- been reviewed (enforced in services/remediation-engine, not just here).
    status                       TEXT NOT NULL DEFAULT 'dry_run_only',
    created_by                   TEXT,
    created_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at                   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_remediation_playbooks_org ON remediation_playbooks (org_id);
CREATE INDEX IF NOT EXISTS idx_remediation_playbooks_rule ON remediation_playbooks (trigger_rule_id) WHERE status <> 'disabled';

-- Append-only audit trail (spec §7: "never edited after creation, only
-- superseded by new rows") — same convention as scaling_decisions /
-- agent_policy_decisions. Denormalizes resource_type/resource_id from the
-- triggering alert so the audit view never needs a join to be readable.
CREATE TABLE IF NOT EXISTS remediation_executions (
    id                  BIGSERIAL PRIMARY KEY,
    org_id              TEXT NOT NULL,
    playbook_id         TEXT NOT NULL REFERENCES remediation_playbooks(id) ON DELETE CASCADE,
    triggered_by_alert_id TEXT REFERENCES alerts(id),
    agent_id            TEXT,      -- the KubeWatch Agent to execute on, denormalized
                                    -- from the alert so an approval never joins alerts
    resource_type       TEXT,
    resource_id         TEXT,
    -- Full label set from the triggering alert (namespace/owner_kind/
    -- owner_name for a pod, etc.) — denormalized here too, not just on
    -- resource_type/resource_id, so an approval (services/query) can build
    -- the exact same restart manifest services/remediation-engine would
    -- have, without joining back to alerts (which the audit trail
    -- shouldn't depend on staying around).
    labels              JSONB,
    dry_run             BOOLEAN NOT NULL DEFAULT true,
    previous_state      JSONB,
    -- executed | deferred_to_human | blocked_by_circuit_breaker | dry_run_only
    decision            TEXT NOT NULL,
    outcome             TEXT,              -- success | failure | rolled_back, null until known
    command_id          TEXT,              -- the agent_commands row issued, if any
    detail              TEXT,              -- human-readable explanation, same role as scaling_decisions.outcome text
    approved            BOOLEAN,           -- null until a human approves/rejects a deferred execution
    resolved_at         TIMESTAMPTZ,
    executed_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_remediation_executions_org_ts ON remediation_executions (org_id, executed_at DESC);
CREATE INDEX IF NOT EXISTS idx_remediation_executions_playbook_ts ON remediation_executions (playbook_id, executed_at DESC);
-- Circuit breaker budget check: COUNT(*) WHERE playbook_id=$1 AND decision='executed' AND executed_at > now()-interval.
-- A rolling-window COUNT against this index is cheap enough at this volume
-- that a separate counter table (spec §4.3's "or a fast key-value store")
-- isn't warranted, same reasoning already used for cost attribution in
-- Feature 2 being computed live rather than via a rollup job.
CREATE INDEX IF NOT EXISTS idx_remediation_executions_playbook_decision_ts ON remediation_executions (playbook_id, decision, executed_at DESC);

-- Highest tier: this is the highest blast-radius feature in the AI-Ops
-- roadmap (it takes automated action on production infrastructure), gated
-- at the same tier as Self-Hosted AI Stack Observability.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS autonomous_remediation_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET autonomous_remediation_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS autonomous_remediation_enabled;
DROP TABLE IF EXISTS remediation_executions;
DROP TABLE IF EXISTS remediation_playbooks;
