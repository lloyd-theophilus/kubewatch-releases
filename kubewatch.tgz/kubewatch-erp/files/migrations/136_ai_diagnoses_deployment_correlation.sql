-- +goose Up
-- Log Intelligence spec §3/§7: "correlated_deployment_marker_id... the
-- correlated deployment marker with a link to the relevant commit or
-- pipeline run" in the diagnosis panel. services/devops-agent/
-- deployment_context.go's gatherRecentDeployment already computed this for
-- the LLM prompt, but never persisted it, so the UI had nothing to show
-- after the fact -- this column is what closes that gap.
ALTER TABLE ai_diagnoses ADD COLUMN IF NOT EXISTS correlated_deployment_marker_id TEXT REFERENCES deployment_markers(id) ON DELETE SET NULL;
