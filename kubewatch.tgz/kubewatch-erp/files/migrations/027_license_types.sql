-- +goose Up
-- Normalize license_type vocabulary to trial | license | subscription.
-- Previously issued "actual" licenses become fixed-term "license" grants;
-- recurring Paystack-billed orgs are marked "subscription" going forward.
UPDATE organizations SET license_type = 'license' WHERE license_type = 'actual';

-- +goose Down
UPDATE organizations SET license_type = 'actual' WHERE license_type IN ('license', 'subscription');
