-- +goose Up
-- Edge AI Fleet Observability (AI-Ops roadmap Feature 6, Phase 4 — see
-- assets/KUBEWATCH-AI-OPS-COMPLETE.md). An edge device is registered as a
-- normal `agents` row (mode='edge') — the spec's "Device Registry" is these
-- few extra columns on the table that already has id/org_id/name/
-- last_push_at/status, not a separate table (same reasoning as GPU-aware
-- scaling reusing scaling_policies rather than a parallel table).
ALTER TABLE agents ADD COLUMN IF NOT EXISTS location TEXT;
ALTER TABLE agents ADD COLUMN IF NOT EXISTS hardware_profile TEXT;
ALTER TABLE agents ADD COLUMN IF NOT EXISTS model_version_deployed TEXT;
-- online | offline_expected | offline_unexpected. Only meaningful for
-- mode='edge' rows — computed by services/alert-engine's
-- checkEdgeDeviceOffline, not by the agent itself (a device that's actually
-- offline can't self-report anything).
ALTER TABLE agents ADD COLUMN IF NOT EXISTS connectivity_state TEXT NOT NULL DEFAULT 'online';

-- A bounded recurring-window model (day-of-week + a UTC time range),
-- deliberately simpler than general cron: covers "goes quiet every night
-- during a maintenance window" without a cron parser, matching this
-- roadmap's own "don't over-build past what the spec actually needs"
-- pattern elsewhere (e.g. GPU spot-shift's approximate bin-packing).
CREATE TABLE IF NOT EXISTS device_offline_windows (
    id            BIGSERIAL PRIMARY KEY,
    org_id        TEXT NOT NULL REFERENCES organizations(id),
    agent_id      TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    -- 0=Sunday..6=Saturday, Postgres's own EXTRACT(DOW) convention so the
    -- alert-engine check can compare directly with no reindexing.
    days_of_week  INTEGER[] NOT NULL,
    starts_at_utc TIME NOT NULL,
    ends_at_utc   TIME NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_device_offline_windows_agent ON device_offline_windows (agent_id);

-- Same tier as Auto Scaling/GPU Cost Control/Workload Advisor — fleet-scale
-- infrastructure observability, not the sovereignty/blast-radius-driven
-- Enterprise tier Self-Hosted AI Observability and Autonomous Remediation
-- sit at.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS edge_fleet_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET edge_fleet_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS edge_fleet_enabled;
DROP TABLE IF EXISTS device_offline_windows;
ALTER TABLE agents DROP COLUMN IF EXISTS connectivity_state;
ALTER TABLE agents DROP COLUMN IF EXISTS model_version_deployed;
ALTER TABLE agents DROP COLUMN IF EXISTS hardware_profile;
ALTER TABLE agents DROP COLUMN IF EXISTS location;
