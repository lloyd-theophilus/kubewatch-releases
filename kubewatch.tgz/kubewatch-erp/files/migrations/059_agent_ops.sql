-- +goose Up
-- Agent Cost-and-Reliability Ops (AI-Ops roadmap Feature 1, Phase 1 —
-- see assets/KUBEWATCH-AI-OPS-COMPLETE.md). Brings customer AI agent
-- processes (LangChain/CrewAI/custom OTel-instrumented systems) into
-- KubeWatch as a first-class monitored entity, distinct from the existing
-- ai_events table (services/query/ai.go), which tracks individual model
-- calls with no agent/session grouping or automated-response machinery.
--
-- Mirrors services/scaling-engine's policy/decision/rollback conventions
-- (see infra/migrations/019_scaling.sql, 020_agent_commands.sql): a policy
-- table with dry_run + previous_state, an append-only decision log, and
-- actions issued through the existing agent_commands table (new `type`
-- values only — see services/live-data/commands.go's allow-list).

CREATE TABLE IF NOT EXISTS agent_registrations (
    id                 TEXT PRIMARY KEY,
    org_id             TEXT NOT NULL REFERENCES organizations(id),
    kubewatch_agent_id TEXT,                          -- which KubeWatch Agent (agents.id) is reporting on this AI agent
    name               TEXT NOT NULL,
    framework          TEXT NOT NULL DEFAULT 'custom', -- langchain | crewai | custom | otel
    agent_version      TEXT,                           -- customer-supplied version/tag, used by agent.rollback
    model_primary      TEXT,                           -- e.g. claude-sonnet-5, informational
    status             TEXT NOT NULL DEFAULT 'active',  -- active | throttled | killed | rolled_back
    registered_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_seen_at       TIMESTAMPTZ,
    created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_agent_registrations_org ON agent_registrations (org_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_agent_registrations_kw_agent ON agent_registrations (kubewatch_agent_id);

CREATE TABLE IF NOT EXISTS agent_policies (
    id                      TEXT PRIMARY KEY,
    org_id                  TEXT NOT NULL REFERENCES organizations(id),
    agent_id                TEXT NOT NULL REFERENCES agent_registrations(id) ON DELETE CASCADE,
    condition_type          TEXT NOT NULL,                    -- cost_per_hour | error_rate | runaway_loop
    threshold               NUMERIC NOT NULL,
    action                  TEXT NOT NULL DEFAULT 'alert_only', -- throttle | kill | rollback | alert_only
    max_concurrent_sessions INTEGER,                          -- used by the throttle action
    enabled                 BOOLEAN NOT NULL DEFAULT TRUE,
    dry_run                 BOOLEAN NOT NULL DEFAULT TRUE,    -- every new policy starts in dry-run (§7)
    armed_after             TIMESTAMPTZ,                      -- earliest time a customer may flip dry_run off; NULL once armed
    previous_state          JSONB,                             -- agent config/version snapshot at time of last action, for rollback
    last_evaluated_at       TIMESTAMPTZ,
    last_triggered_at       TIMESTAMPTZ,
    last_decision           TEXT,
    created_by              TEXT,
    updated_by               TEXT,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_agent_policies_org ON agent_policies (org_id);
CREATE INDEX IF NOT EXISTS idx_agent_policies_agent ON agent_policies (agent_id);
CREATE INDEX IF NOT EXISTS idx_agent_policies_enabled ON agent_policies (enabled) WHERE enabled = TRUE;

-- Append-only audit/decision log, same shape and conventions as
-- scaling_decisions (019_scaling.sql): one row per evaluation that produced
-- a decision, never mutated, a rollback references the entry it reverts.
CREATE TABLE IF NOT EXISTS agent_policy_decisions (
    id             BIGSERIAL PRIMARY KEY,
    org_id         TEXT NOT NULL,
    policy_id      TEXT NOT NULL,
    agent_id       TEXT NOT NULL,
    ts             TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    condition_type TEXT NOT NULL,
    trigger_value  DOUBLE PRECISION,
    threshold      DOUBLE PRECISION,
    action         TEXT NOT NULL,                 -- dry_run | throttled | killed | rolled_back | skipped_cooldown | rollback
    dry_run        BOOLEAN NOT NULL DEFAULT TRUE,
    outcome        TEXT,
    actor          TEXT NOT NULL DEFAULT 'system',
    reverts_id     BIGINT
);
CREATE INDEX IF NOT EXISTS idx_agent_policy_decisions_org_ts ON agent_policy_decisions (org_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_agent_policy_decisions_policy_ts ON agent_policy_decisions (policy_id, ts DESC);

-- Gated the same way as every other plan-limits flag (auto_scaling_enabled,
-- ai_observability_enabled, ...): one boolean column, enforced via a fresh
-- DB join in services/query rather than trusting a header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS agent_ops_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET agent_ops_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS agent_ops_enabled;
DROP TABLE IF EXISTS agent_policy_decisions;
DROP TABLE IF EXISTS agent_policies;
DROP TABLE IF EXISTS agent_registrations;
