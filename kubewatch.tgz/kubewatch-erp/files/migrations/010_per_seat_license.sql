-- +goose Up
-- License tracking on organizations. Keeps the existing agent-count + plan-tier
-- model (Free/Pro/Enterprise); these columns let the operator console issue and
-- track licenses: trial vs actual, the licensed agent limit, and expiry.

ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_type       TEXT NOT NULL DEFAULT 'trial';  -- trial | actual
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_max_agents INTEGER;                         -- agent limit on the issued license
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_expires_at TIMESTAMPTZ;
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_issued_at  TIMESTAMPTZ;
-- Dedup marker so expiry-warning emails aren't resent every cycle.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS expiry_alerted_at  TIMESTAMPTZ;

-- Backfill: existing trials inherit their trial expiry; the platform org gets a
-- long-lived actual license so the operator account is never locked out.
UPDATE organizations
   SET license_expires_at = COALESCE(license_expires_at, trial_ends_at)
 WHERE license_expires_at IS NULL;

UPDATE organizations
   SET license_type = 'actual',
       license_expires_at = NOW() + INTERVAL '100 years',
       license_issued_at = NOW()
 WHERE id = 'org_platform';

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS license_type;
ALTER TABLE organizations DROP COLUMN IF EXISTS license_max_agents;
ALTER TABLE organizations DROP COLUMN IF EXISTS license_expires_at;
ALTER TABLE organizations DROP COLUMN IF EXISTS license_issued_at;
ALTER TABLE organizations DROP COLUMN IF EXISTS expiry_alerted_at;
