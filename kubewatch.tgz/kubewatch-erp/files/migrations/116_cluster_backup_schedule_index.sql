-- +goose Up
-- cluster_backup_schedule_index is a control-plane routing index, same shape
-- and purpose as dr_schedule_index (074_dr_schedule_index.sql): an agent's
-- backup schedule (enabled/interval) lives in that org's own tenant database
-- (infra/tenant-migrations/058_cluster_backups.sql's cluster_backup_settings),
-- so services/dr-scheduler needs a cheap way to find which agents are due
-- for a backup without resolving every org's tenant database just to check.
-- Keyed by agent_id, not org_id or a clusters-table id: an org can have
-- several agents each with their own independent backup schedule, and
-- `clusters` (023_clusters.sql, services/clusters' own cloud-API-discovered
-- inventory) is a genuinely separate, unlinked concept from `agents` --
-- confirmed directly, no FK or join table exists between them anywhere in
-- this schema, and a `clusters` row doesn't even exist for a Docker host,
-- which this feature also backs up. org_id is still stored so the
-- published NATS event carries enough to resolve the right tenant database
-- without a second lookup. Written-through whenever cluster_backup_settings
-- changes. Self-hosted-compatible (harmless/unused there, same as
-- dr_schedule_index).
CREATE TABLE IF NOT EXISTS cluster_backup_schedule_index (
    agent_id       TEXT PRIMARY KEY,
    org_id         TEXT NOT NULL,
    enabled        BOOLEAN NOT NULL DEFAULT FALSE,
    interval_hours INTEGER NOT NULL DEFAULT 24,
    next_due_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_cluster_backup_schedule_index_due ON cluster_backup_schedule_index (next_due_at) WHERE enabled;

-- Monitored-infrastructure backup is a Pro/Enterprise feature, same gating
-- mechanism as Disaster Recovery (074_dr_schedule_index.sql) and the
-- cluster-upgrade feature (114_cluster_upgrade_gate.sql).
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_backup_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_backup_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_backup_enabled;
DROP TABLE IF EXISTS cluster_backup_schedule_index;
