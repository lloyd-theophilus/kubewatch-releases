-- +goose Up
-- Port-forward (Read-Write Cluster IDE, Phase 2) reuses exec_sessions' audit
-- shape rather than a near-duplicate table — org/agent/namespace/pod/outcome/
-- bytes/timestamps all already fit; portforward just doesn't use
-- container/command and needs a target port.
ALTER TABLE exec_sessions ADD COLUMN IF NOT EXISTS kind TEXT NOT NULL DEFAULT 'exec'; -- 'exec' | 'portforward'
ALTER TABLE exec_sessions ADD COLUMN IF NOT EXISTS target_port INTEGER;
ALTER TABLE exec_sessions ALTER COLUMN container DROP NOT NULL; -- unused for kind='portforward'

-- +goose Down
ALTER TABLE exec_sessions ALTER COLUMN container SET NOT NULL;
ALTER TABLE exec_sessions DROP COLUMN IF EXISTS target_port;
ALTER TABLE exec_sessions DROP COLUMN IF EXISTS kind;
