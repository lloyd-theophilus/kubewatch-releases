-- Cleanup for the "N agents are running an outdated version" banner bug
-- (services/query/settings.go's countOutdatedAgents) on self-hosted's
-- single shared database. Mirrors
-- infra/tenant-migrations/038_cleanup_removed_agents.sql — see that file's
-- comment for the full story: agent re-registration has always retired the
-- prior row for the same org_id + name to status='removed' instead of
-- deleting it, so a long-lived agent that has restarted/redeployed many
-- times (once per platform release, in practice) accumulates one harmless
-- 'removed' row per past registration, each frozen at whatever version it
-- reported back then. countOutdatedAgents didn't filter status='removed'
-- before this fix, so it counted every one of those historical rows as
-- currently outdated.
--
-- Filtering the live query (done alongside this migration) is what actually
-- fixes the banner; this is just housekeeping so the table doesn't grow
-- without bound.
--
-- Guarded against alerts.agent_id (001_initial_schema.sql), the only FK
-- into agents(id) without ON DELETE CASCADE.
DELETE FROM agents
WHERE status = 'removed'
  AND NOT EXISTS (SELECT 1 FROM alerts WHERE alerts.agent_id = agents.id);
