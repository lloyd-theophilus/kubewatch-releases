-- +goose Up
-- Marketing site traffic, for the operator console's traffic/country
-- breakdown. Control-plane table (not tenant-scoped): a pageview isn't
-- owned by any one org, so it lives here rather than in
-- infra/tenant-migrations/, same reasoning as feature_requests
-- (119_feature_requests.sql). One row per (day, country); a view increments
-- the counter rather than being stored as its own event row -- daily,
-- weekly, monthly, and yearly are all just different date_trunc groupings
-- over this same table. country is Cloudflare's CF-IPCountry value verbatim
-- (ISO 3166-1 alpha-2, or 'XX' when the header is absent/unknown) -- see
-- services/tenant-mgmt/marketing_traffic.go.
CREATE TABLE IF NOT EXISTS marketing_traffic_daily (
    day     DATE NOT NULL,
    country TEXT NOT NULL,
    views   BIGINT NOT NULL DEFAULT 0,
    PRIMARY KEY (day, country)
);
CREATE INDEX IF NOT EXISTS idx_marketing_traffic_daily_day ON marketing_traffic_daily (day);

-- +goose Down
DROP TABLE IF EXISTS marketing_traffic_daily;
