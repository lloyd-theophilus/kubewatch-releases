-- +goose Up
-- Synthetic Monitoring (services/synthetics) and Export Targets
-- (services/export-targets) shipped with no plan gating at all -- any org on
-- any plan, including Free, could use both. Gated to Enterprise only, same
-- shape as 054_plan_ai_observability_gate.sql: one boolean column per
-- feature, enforced via a fresh DB join in each service rather than trusting
-- a header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS synthetics_enabled BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS export_targets_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET synthetics_enabled = true, export_targets_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS synthetics_enabled;
ALTER TABLE plan_limits DROP COLUMN IF EXISTS export_targets_enabled;
