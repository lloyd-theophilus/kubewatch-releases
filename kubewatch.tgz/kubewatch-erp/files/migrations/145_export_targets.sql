-- Outbound export targets (services/export-targets): forwards KubeWatch's
-- own already-collected metrics OUT to a competing/adjacent observability
-- platform's ingest API (Datadog, Dynatrace, Honeycomb, New Relic,
-- AppDynamics, Splunk, Splunk Infrastructure Monitoring, Sumo Logic,
-- Wavefront) -- the reverse direction from every pull-based connector in
-- the integrations table. Also created directly by services/export-targets'
-- own self-managed migrate() in self-hosted mode.
CREATE TABLE IF NOT EXISTS export_targets (
	id SERIAL PRIMARY KEY,
	org_id TEXT NOT NULL,
	name TEXT NOT NULL,
	platform TEXT NOT NULL,
	config TEXT NOT NULL DEFAULT '',
	metric_names TEXT NOT NULL DEFAULT '',
	interval_seconds INTEGER NOT NULL DEFAULT 60,
	enabled BOOLEAN NOT NULL DEFAULT TRUE,
	status TEXT NOT NULL DEFAULT 'unknown',
	last_export_at TIMESTAMPTZ,
	last_error TEXT NOT NULL DEFAULT '',
	last_export_count INTEGER NOT NULL DEFAULT 0,
	created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
	updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_export_targets_org_id ON export_targets (org_id);
