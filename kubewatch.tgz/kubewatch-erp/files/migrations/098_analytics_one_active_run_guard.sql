-- +goose Up
-- Closes a check-then-insert race in services/analytics/cleaning_jobs.go's
-- createCleaningRun and scheduler.go's queueDueScheduledJobs: both guard
-- "no run already pending/running for this job" with a plain SELECT
-- followed by a separate INSERT, no transaction or row lock between them.
-- Two near-simultaneous triggers for the same job (a double-click on "Run
-- now", or a scheduled tick firing while a manual trigger is in flight)
-- could both pass the SELECT before either INSERT commits, producing two
-- concurrent runs for one job that race on the same job's dataset rows
-- (see engine.go's executeCleaningRun, which deletes then repopulates
-- analytics_datasets/analytics_dataset_rows for the job). A partial unique
-- index is the only way to close this atomically -- a check-then-insert in
-- Go has the exact same race the code it's meant to guard already had.
CREATE UNIQUE INDEX IF NOT EXISTS uq_analytics_cleaning_runs_one_active_per_job
    ON analytics_cleaning_runs (job_id)
    WHERE outcome IN ('pending', 'running');

-- +goose Down
DROP INDEX IF EXISTS uq_analytics_cleaning_runs_one_active_per_job;
