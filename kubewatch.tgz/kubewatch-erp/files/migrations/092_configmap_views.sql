-- +goose Up
-- On-demand "show me this ConfigMap's current live YAML" read path (Read-
-- Write Cluster IDE) — the view-only counterpart to manifest_applies
-- (037_manifest_applies.sql). Deliberately no approval columns: this is a
-- read, there is nothing to approve. A row is created pending, the agent
-- reports the object's current YAML (or an error) back via a dedicated
-- result endpoint, and the frontend polls this row until it's ready/failed.
CREATE TABLE IF NOT EXISTS configmap_views (
    id           TEXT PRIMARY KEY,   -- cmview_<hex>
    org_id       TEXT NOT NULL,
    agent_id     TEXT NOT NULL,
    namespace    TEXT NOT NULL,
    name         TEXT NOT NULL,
    requested_by TEXT NOT NULL,
    requested_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    outcome      TEXT NOT NULL DEFAULT 'pending',   -- pending | ready | failed
    yaml         TEXT,
    error        TEXT
);
CREATE INDEX IF NOT EXISTS idx_configmap_views_org ON configmap_views(org_id, id);

-- +goose Down
DROP TABLE IF EXISTS configmap_views;
