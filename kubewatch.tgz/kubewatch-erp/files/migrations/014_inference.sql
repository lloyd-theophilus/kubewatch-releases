-- +goose Up
-- Latest inference-server metric snapshot (upserted per agent push). One row per
-- (agent, server, metric); a synthetic `_up` metric carries reachability.
-- Time-series history goes to VictoriaMetrics.
CREATE TABLE IF NOT EXISTS inference_snapshots (
    org_id     TEXT NOT NULL,
    agent_id   TEXT NOT NULL,
    server     TEXT NOT NULL,
    metric     TEXT NOT NULL,
    value      DOUBLE PRECISION NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (agent_id, server, metric)
);
CREATE INDEX IF NOT EXISTS idx_inference_org ON inference_snapshots (org_id);

-- +goose Down
DROP TABLE IF EXISTS inference_snapshots;
