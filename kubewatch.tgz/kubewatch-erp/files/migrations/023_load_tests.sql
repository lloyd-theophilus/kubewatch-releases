-- +goose Up
-- Persisted load tests for the Performance page. The dashboard creates a test
-- (POST), which runs asynchronously in live-data, and polls its status until it
-- completes. Replaces the old synchronous /performance/run, which could not work
-- through the gateway's 30s request timeout for 30 to 300 second tests.
CREATE TABLE IF NOT EXISTS load_tests (
    id              BIGSERIAL PRIMARY KEY,
    org_id          TEXT NOT NULL,
    name            TEXT NOT NULL DEFAULT '',
    target_url      TEXT NOT NULL,
    method          TEXT NOT NULL DEFAULT 'GET',
    concurrency     INTEGER NOT NULL DEFAULT 10,
    duration_sec    INTEGER NOT NULL DEFAULT 30,
    status          TEXT NOT NULL DEFAULT 'pending', -- pending | running | complete | failed
    total_requests  BIGINT NOT NULL DEFAULT 0,
    success_count   BIGINT NOT NULL DEFAULT 0,
    error_count     BIGINT NOT NULL DEFAULT 0,
    avg_latency_ms  DOUBLE PRECISION NOT NULL DEFAULT 0,
    p50_latency_ms  DOUBLE PRECISION NOT NULL DEFAULT 0,
    p90_latency_ms  DOUBLE PRECISION NOT NULL DEFAULT 0,
    p99_latency_ms  DOUBLE PRECISION NOT NULL DEFAULT 0,
    max_latency_ms  DOUBLE PRECISION NOT NULL DEFAULT 0,
    req_per_sec     DOUBLE PRECISION NOT NULL DEFAULT 0,
    error_rate      DOUBLE PRECISION NOT NULL DEFAULT 0,
    error_messages  TEXT NOT NULL DEFAULT '',
    started_at      TIMESTAMPTZ,
    finished_at     TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_load_tests_org ON load_tests (org_id, created_at DESC);

-- +goose Down
DROP TABLE IF EXISTS load_tests;
