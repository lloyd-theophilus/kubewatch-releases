CREATE TABLE IF NOT EXISTS scheduled_emails (
    id           TEXT PRIMARY KEY,
    org_id       TEXT NOT NULL,
    user_id      TEXT NOT NULL,
    template     TEXT NOT NULL,
    send_after   TIMESTAMPTZ NOT NULL,
    sent_at      TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_scheduled_emails_send_after
    ON scheduled_emails (send_after)
    WHERE sent_at IS NULL AND cancelled_at IS NULL;

ALTER TABLE users ADD COLUMN IF NOT EXISTS email_marketing_opt_out BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS unsubscribe_token TEXT;
