-- +goose Up
-- Tracks self-serve self-hosted license purchases so the Paystack callback and
-- webhook can issue a license key exactly once per transaction. The plaintext
-- key is never stored here — only the license server's opaque license_id, for
-- support lookups and re-issue.
CREATE TABLE IF NOT EXISTS selfhost_purchases (
    reference   TEXT PRIMARY KEY,
    email       TEXT NOT NULL,
    plan        TEXT NOT NULL,
    period      TEXT NOT NULL,
    amount      BIGINT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'pending', -- pending | paid
    key_issued  BOOLEAN NOT NULL DEFAULT FALSE,
    license_id  TEXT,
    expires_at  TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    paid_at     TIMESTAMPTZ
);

-- +goose Down
DROP TABLE IF EXISTS selfhost_purchases;
