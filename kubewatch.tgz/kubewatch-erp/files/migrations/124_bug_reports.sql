-- +goose Up
-- Bug reports submitted from either the public marketing site (no login) or
-- the authenticated dashboard (an "Admin > Report a Bug" page). Control-plane
-- table (not tenant-scoped), same reasoning as feature_requests
-- (119_feature_requests.sql): a bug report isn't owned by any one org's
-- tenant database, and the operator console needs to see every org's reports
-- in one place regardless of source. org_id is set only for dashboard-
-- sourced reports (a plain label referencing organizations.id in this same
-- control-plane database, not a foreign key -- an org can be soft-deleted
-- without needing its historical bug reports to disappear or block deletion).
--
-- status mirrors the standard support-ticket lifecycle ("whose court is the
-- ball in"): open (new, unactioned) -> in_progress (operator is on it) ->
-- needs_info (waiting on the reporter) -> resolved -> closed.
CREATE TABLE IF NOT EXISTS bug_reports (
    id              TEXT PRIMARY KEY,
    title           TEXT NOT NULL,
    description     TEXT NOT NULL,
    source          TEXT NOT NULL, -- marketing | dashboard
    severity        TEXT NOT NULL DEFAULT 'medium', -- low | medium | high | critical
    status          TEXT NOT NULL DEFAULT 'open', -- open | in_progress | needs_info | resolved | closed
    submitter_email TEXT NOT NULL,
    submitter_name  TEXT,
    org_id          TEXT, -- set only for source='dashboard'
    page_url        TEXT, -- set only for source='dashboard' (which page the reporter was on)
    user_agent      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_bug_reports_status ON bug_reports(status);
CREATE INDEX IF NOT EXISTS idx_bug_reports_source ON bug_reports(source);
CREATE INDEX IF NOT EXISTS idx_bug_reports_submitter_email ON bug_reports(submitter_email);

-- Operator-only internal notes on a report -- triage commentary, not a
-- reporter-visible reply thread (a two-way support inbox is a bigger,
-- separate feature). One row per note, oldest first for a timeline read.
CREATE TABLE IF NOT EXISTS bug_report_notes (
    id             TEXT PRIMARY KEY,
    bug_report_id  TEXT NOT NULL REFERENCES bug_reports(id) ON DELETE CASCADE,
    body           TEXT NOT NULL,
    created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_bug_report_notes_bug_report_id ON bug_report_notes(bug_report_id);

-- +goose Down
DROP TABLE IF EXISTS bug_report_notes;
DROP TABLE IF EXISTS bug_reports;
