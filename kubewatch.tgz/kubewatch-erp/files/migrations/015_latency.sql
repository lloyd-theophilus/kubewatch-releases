-- +goose Up
-- Latest latency-probe snapshot per agent (push RTT, per-node probes, and
-- configured HTTP/TCP targets). Kind is agent | node | probe. History → VM.
CREATE TABLE IF NOT EXISTS latency_probes (
    org_id     TEXT NOT NULL,
    agent_id   TEXT NOT NULL,
    kind       TEXT NOT NULL DEFAULT 'probe',
    name       TEXT NOT NULL,
    target     TEXT NOT NULL DEFAULT '',
    latency_ms DOUBLE PRECISION NOT NULL DEFAULT 0,
    up         BOOLEAN NOT NULL DEFAULT true,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (agent_id, kind, name)
);
CREATE INDEX IF NOT EXISTS idx_latency_org ON latency_probes (org_id);

-- +goose Down
DROP TABLE IF EXISTS latency_probes;
