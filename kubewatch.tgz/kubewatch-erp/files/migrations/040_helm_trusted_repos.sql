-- +goose Up
-- Helm release lifecycle management (Read-Write Cluster IDE, Phase 6).
-- Install/upgrade requests reference a repo by ID from this admin-managed
-- table — never a raw URL per-request. The agent runs inside the customer's
-- cluster; a free-text URL on every request would let it fetch and render
-- arbitrary attacker-specified remote content on demand (an SSRF/supply-
-- chain gap). Adding a repo alone doesn't mutate the cluster, so a single
-- admin can add one — the two-person gate stays anchored on the actual
-- install/upgrade/rollback/uninstall action, same as everywhere else in
-- this codebase.
CREATE TABLE IF NOT EXISTS helm_trusted_repos (
    id          TEXT PRIMARY KEY,   -- hrepo_<hex>
    org_id      TEXT NOT NULL,
    name        TEXT NOT NULL,
    url         TEXT NOT NULL,      -- https:// only, enforced in app code
    created_by  TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    disabled_at TIMESTAMPTZ         -- soft revoke; never hard-delete (audit trail)
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_helm_trusted_repos_org_name ON helm_trusted_repos (org_id, name) WHERE disabled_at IS NULL;

-- +goose Down
DROP TABLE IF EXISTS helm_trusted_repos;
