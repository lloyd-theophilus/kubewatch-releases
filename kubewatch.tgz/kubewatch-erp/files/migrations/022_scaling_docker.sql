-- +goose Up
-- Autoscaler Phase 3: Docker dry-run + placement.
--
-- max_replicas_per_host caps how many replicas of a container group the placement
-- algorithm will put on any single Docker host, so one host cannot silently absorb
-- an entire group's scale-out and become a new single point of failure
-- (KubeWatch_ERP_Autoscaler_Architecture.md §6.1). Nullable = no cap. The default
-- is intentionally left to the operator (§11.3 open question).
ALTER TABLE scaling_policies ADD COLUMN IF NOT EXISTS max_replicas_per_host INTEGER;

-- +goose Down
ALTER TABLE scaling_policies DROP COLUMN IF EXISTS max_replicas_per_host;
