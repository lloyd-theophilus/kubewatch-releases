-- +goose Up
-- AI Observability is an Enterprise-only feature per the marketing pricing
-- page (unlike most plan-limits flags, Pro does NOT get this one). Gated
-- the same way as every other plan-limits flag: one boolean column,
-- enforced via a fresh DB join in services/query rather than trusting a
-- header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS ai_observability_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET ai_observability_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS ai_observability_enabled;
