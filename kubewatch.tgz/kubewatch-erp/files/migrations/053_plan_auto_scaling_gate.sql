-- +goose Up
-- Auto Scaling is a Pro-and-above feature per the marketing pricing page.
-- Gated the same way as every other plan-limits flag: one boolean column,
-- enforced via a fresh DB join in services/query (policy CRUD) and
-- services/live-data (agent-facing desired-state endpoints) rather than
-- trusting a header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS auto_scaling_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET auto_scaling_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS auto_scaling_enabled;
