-- +goose Up
-- Application API request events reported by customer apps (via the org API
-- key). Powers request-rate, error-rate, and latency tracking per route.
CREATE TABLE IF NOT EXISTS api_request_events (
    id          BIGSERIAL PRIMARY KEY,
    org_id      TEXT NOT NULL,
    ts          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    service     TEXT NOT NULL DEFAULT '',
    route       TEXT NOT NULL DEFAULT '',
    method      TEXT NOT NULL DEFAULT '',
    status_code INTEGER NOT NULL DEFAULT 0,
    latency_ms  DOUBLE PRECISION NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_api_req_org_ts ON api_request_events (org_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_api_req_org_route ON api_request_events (org_id, route);

-- +goose Down
DROP TABLE IF EXISTS api_request_events;
