-- +goose Up
-- log_streaming (migration 003) was seeded true for pro/enterprise via
-- ON CONFLICT DO NOTHING, so it never applied to plan_limits rows that
-- already existed in a deployed database — leaving live log streaming
-- 403ing for Pro (and possibly Enterprise) orgs. Force it on explicitly.
UPDATE plan_limits SET log_streaming = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
UPDATE plan_limits SET log_streaming = false WHERE plan IN ('pro', 'enterprise');
