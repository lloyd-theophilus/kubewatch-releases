-- +goose Up
-- Organizations table
CREATE TABLE IF NOT EXISTS organizations (
    id          TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    slug        TEXT UNIQUE NOT NULL,
    plan        TEXT NOT NULL DEFAULT 'free',
    status      TEXT NOT NULL DEFAULT 'active',
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    deleted_at  TIMESTAMPTZ
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id            TEXT PRIMARY KEY,
    org_id        TEXT NOT NULL REFERENCES organizations(id),
    email         TEXT NOT NULL,
    name          TEXT,
    role          TEXT NOT NULL DEFAULT 'viewer',
    password_hash TEXT,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(org_id, email)
);

-- API Keys (hashed)
CREATE TABLE IF NOT EXISTS api_keys (
    id           TEXT PRIMARY KEY,
    org_id       TEXT NOT NULL REFERENCES organizations(id),
    name         TEXT,
    key_hash     TEXT NOT NULL,
    key_prefix   TEXT NOT NULL,
    created_by   TEXT REFERENCES users(id),
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    last_used_at TIMESTAMPTZ,
    revoked_at   TIMESTAMPTZ
);

-- Agents
CREATE TABLE IF NOT EXISTS agents (
    id           TEXT PRIMARY KEY,
    org_id       TEXT NOT NULL REFERENCES organizations(id),
    name         TEXT,
    mode         TEXT NOT NULL,
    token_hash   TEXT NOT NULL,
    last_push_at TIMESTAMPTZ,
    version      TEXT,
    node_count   INTEGER DEFAULT 0,
    pod_count    INTEGER DEFAULT 0,
    container_count INTEGER DEFAULT 0,
    status       TEXT DEFAULT 'active',
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Alert Rules
CREATE TABLE IF NOT EXISTS alert_rules (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL REFERENCES organizations(id),
    name        TEXT NOT NULL,
    description TEXT,
    metric      TEXT NOT NULL,
    operator    TEXT NOT NULL,
    threshold   NUMERIC NOT NULL,
    severity    TEXT NOT NULL DEFAULT 'warning',
    enabled     BOOLEAN DEFAULT true,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Alert Instances
CREATE TABLE IF NOT EXISTS alerts (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL REFERENCES organizations(id),
    rule_id     TEXT REFERENCES alert_rules(id),
    agent_id    TEXT REFERENCES agents(id),
    resource_id TEXT,
    resource_type TEXT,
    state       TEXT NOT NULL DEFAULT 'firing',
    message     TEXT,
    value       NUMERIC,
    threshold   NUMERIC,
    severity    TEXT,
    fired_at    TIMESTAMPTZ NOT NULL,
    acked_at    TIMESTAMPTZ,
    acked_by    TEXT REFERENCES users(id),
    resolved_at TIMESTAMPTZ
);

-- Notification Channels
CREATE TABLE IF NOT EXISTS notification_channels (
    id         TEXT PRIMARY KEY,
    org_id     TEXT NOT NULL REFERENCES organizations(id),
    name       TEXT NOT NULL,
    type       TEXT NOT NULL,
    config     JSONB NOT NULL DEFAULT '{}',
    enabled    BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notification Deliveries (idempotency tracking)
CREATE TABLE IF NOT EXISTS notification_deliveries (
    id         TEXT PRIMARY KEY,
    alert_id   TEXT NOT NULL,
    channel_id TEXT NOT NULL,
    state      TEXT NOT NULL DEFAULT 'pending',
    attempts   INTEGER DEFAULT 0,
    delivered_at TIMESTAMPTZ,
    error      TEXT,
    UNIQUE(alert_id, channel_id)
);

-- Billing Events (append-only)
CREATE TABLE IF NOT EXISTS billing_events (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL REFERENCES organizations(id),
    event_type  TEXT NOT NULL,
    quantity    NUMERIC DEFAULT 1,
    metadata    JSONB,
    recorded_at TIMESTAMPTZ DEFAULT NOW()
);

-- Audit Log (append-only, immutable)
CREATE TABLE IF NOT EXISTS audit_log (
    id          TEXT PRIMARY KEY,
    org_id      TEXT NOT NULL,
    user_id     TEXT,
    action      TEXT NOT NULL,
    resource    TEXT,
    resource_id TEXT,
    ip_address  TEXT,
    user_agent  TEXT,
    metadata    JSONB,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Integrations
CREATE TABLE IF NOT EXISTS integrations (
    id         SERIAL PRIMARY KEY,
    org_id     TEXT NOT NULL REFERENCES organizations(id),
    name       TEXT NOT NULL,
    type       TEXT NOT NULL,
    host       TEXT NOT NULL,
    port       INTEGER,
    username   TEXT,
    password   TEXT,
    tls_enabled BOOLEAN DEFAULT false,
    status     TEXT DEFAULT 'unknown',
    latency_ms INTEGER DEFAULT 0,
    uptime_pct NUMERIC DEFAULT 0,
    last_ping_at TIMESTAMPTZ,
    last_error TEXT,
    enabled    BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- +goose Down
DROP TABLE IF EXISTS integrations;
DROP TABLE IF EXISTS audit_log;
DROP TABLE IF EXISTS billing_events;
DROP TABLE IF EXISTS notification_deliveries;
DROP TABLE IF EXISTS notification_channels;
DROP TABLE IF EXISTS alerts;
DROP TABLE IF EXISTS alert_rules;
DROP TABLE IF EXISTS agents;
DROP TABLE IF EXISTS api_keys;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS organizations;
