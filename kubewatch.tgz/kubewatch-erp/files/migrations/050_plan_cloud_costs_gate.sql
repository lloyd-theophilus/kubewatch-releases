-- +goose Up
-- Cloud cost tracking is a Pro-and-above feature per the marketing pricing
-- page. Gated the same way as every other plan-limits flag: one boolean
-- column, enforced via a fresh DB join in services/cloud rather than
-- trusting a header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cloud_costs_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cloud_costs_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cloud_costs_enabled;
