-- +goose Up
-- Log Intelligence spec §2/§9: "Reports token usage and cost to GPU/
-- Inference Cost Control (existing) as another cost source, rather than
-- standing up separate cost tracking." That existing feature
-- (services/query/gpu.go) is built entirely around a customer's own
-- monitored GPU fleet (gpu_pricing + Mimir utilization) -- a
-- fundamentally different cost dimension from a hosted LLM API's per-token
-- billing, with no natural join key between the two. Rather than force-fit
-- BYOK token spend into that dashboard, this adds admin-entered pricing
-- directly on the connection it applies to (nullable: pricing is unknown/
-- untracked until an admin sets it, never guessed or hardcoded from a
-- provider's published rate this codebase can't keep current). ai_diagnoses
-- already stores prompt_tokens/completion_tokens per diagnosis; multiplying
-- those by this connection's price is what actually produces an honest
-- estimated cost, computed live rather than a separate rollup table.
ALTER TABLE devops_agent_llm_connections ADD COLUMN IF NOT EXISTS price_per_million_prompt_tokens NUMERIC;
ALTER TABLE devops_agent_llm_connections ADD COLUMN IF NOT EXISTS price_per_million_completion_tokens NUMERIC;
