-- +goose Up

-- Closes two races found in the bug-sweep review of the cluster-upgrade
-- feature (056_cluster_upgrades.sql):
--
-- 1. requestClusterUpgrade's "is one already in flight" check and its INSERT
--    are two separate statements with no lock between them -- two concurrent
--    requests (double-submit, retried click) can both pass the check and
--    both insert a 'queued' row for the same cluster. A partial unique index
--    makes the second INSERT fail instead, so the app can translate that
--    into the same 409 the pre-check already returns for the common case.
--
-- 2. dispatchQueuedUpgrades calls the cloud provider's mutating upgrade API
--    and only marks the row 'running' *after* that call returns -- if the
--    worker crashes/restarts in between, the row is stuck 'queued' forever
--    and the next tick dispatches the SAME cloud API call a second time.
--    The app now atomically claims a row ('queued' -> 'dispatching') before
--    calling the cloud API; dispatch_claimed_at lets a periodic sweep detect
--    a claim that never resolved (worker died mid-dispatch) and fail it
--    instead of silently retrying, since retrying risks a genuine double
--    cloud-side upgrade call.
ALTER TABLE cluster_upgrades ADD COLUMN IF NOT EXISTS dispatch_claimed_at TIMESTAMPTZ;

CREATE UNIQUE INDEX IF NOT EXISTS uq_cluster_upgrades_one_active
    ON cluster_upgrades (cluster_id) WHERE status IN ('queued', 'dispatching', 'running');

-- +goose Down
DROP INDEX IF EXISTS uq_cluster_upgrades_one_active;
ALTER TABLE cluster_upgrades DROP COLUMN IF EXISTS dispatch_claimed_at;
