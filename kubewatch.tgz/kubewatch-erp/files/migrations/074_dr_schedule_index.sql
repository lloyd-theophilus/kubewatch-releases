-- +goose Up
-- dr_schedule_index is a control-plane routing index, same shape and purpose
-- as 071_auth_lookup_indexes.sql/072_agent_token_index.sql: an org's DR
-- schedule (enabled/interval) lives in that org's own tenant database
-- (infra/tenant-migrations/025_disaster_recovery.sql's dr_settings), so the
-- new services/dr-scheduler service needs a cheap way to find which orgs are
-- due for a backup without resolving every org's tenant database just to
-- check. Written-through whenever dr_settings changes (see
-- services/query/backup.go's updateDRSettings). Self-hosted-compatible
-- (harmless/unused there, exactly like the tables in 071/072).
CREATE TABLE IF NOT EXISTS dr_schedule_index (
    org_id         TEXT PRIMARY KEY,
    enabled        BOOLEAN NOT NULL DEFAULT FALSE,
    interval_hours INTEGER NOT NULL DEFAULT 24,
    next_due_at    TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_dr_schedule_index_due ON dr_schedule_index (next_due_at) WHERE enabled;

-- Disaster Recovery is a Pro/Enterprise feature, same gating mechanism as
-- Edge Fleet (065_edge_devices.sql).
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS dr_backup_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET dr_backup_enabled = true WHERE plan IN ('pro', 'enterprise');

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS dr_backup_enabled;
DROP TABLE IF EXISTS dr_schedule_index;
