-- +goose Up
-- Mirrors infra/tenant-migrations/078_ai_diagnosis_messages.sql. Follow-up
-- chat turns on top of an already-completed ai_diagnoses row -- the system
-- prompt (diagnosis summary/detail/log excerpt) is rebuilt fresh from
-- ai_diagnoses on every call rather than stored here, so only the actual
-- back-and-forth (role IN 'user'/'assistant') is persisted. See
-- services/devops-agent/diagnosis_messages.go.
CREATE TABLE IF NOT EXISTS ai_diagnosis_messages (
    id                TEXT PRIMARY KEY,
    diagnosis_id      TEXT NOT NULL REFERENCES ai_diagnoses(id) ON DELETE CASCADE,
    org_id            TEXT NOT NULL,
    role              TEXT NOT NULL,
    content           TEXT NOT NULL,
    prompt_tokens     INTEGER,
    completion_tokens INTEGER,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_ai_diagnosis_messages_diagnosis ON ai_diagnosis_messages (diagnosis_id, created_at);

-- +goose Down
DROP TABLE IF EXISTS ai_diagnosis_messages;
