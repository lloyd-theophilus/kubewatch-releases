-- +goose Up
-- Every existing plan gate (ssoEnabledForPlan, execEnabledForPlan,
-- portforwardEnabledForPlan, etc.) joins plan_limits on organizations.plan
-- directly, so a trial has never actually granted elevated access — the
-- trial_plan/trial_ends_at columns sat there unused by every enforcement
-- path except two purely cosmetic reads (the JWT eff_plan claim and the
-- Settings > License display). This view is the single place "what plan
-- actually applies right now" is computed, so every gate can switch to it
-- with a one-line FROM/JOIN change instead of re-deriving trial logic in
-- N places. During an active trial (license_type = 'trial' and
-- trial_ends_at hasn't passed), the effective plan is 'enterprise' — the
-- trial is a full-feature preview, not a preview of one specific paid tier.
CREATE OR REPLACE VIEW org_effective_plan AS
SELECT
    id AS org_id,
    CASE
        WHEN license_type = 'trial'
         AND trial_ends_at IS NOT NULL
         AND trial_ends_at > NOW()
        THEN 'enterprise'
        ELSE plan
    END AS effective_plan
FROM organizations;

-- +goose Down
DROP VIEW IF EXISTS org_effective_plan;
