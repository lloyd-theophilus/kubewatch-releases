-- +goose Up
-- Audit Trail viewing is an Enterprise-only feature per the marketing
-- pricing page. This gates VIEWING only — writing audit rows
-- (shared/audit.RecordReq, called from ~14 files across every plan) stays
-- ungated intentionally, so audit data keeps accumulating on Free/Pro in
-- case of a later upgrade, or for internal/compliance purposes. Gated the
-- same way as every other plan-limits flag: one boolean column, enforced
-- via a fresh DB join in services/query rather than trusting a header.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS audit_trail_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET audit_trail_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS audit_trail_enabled;
