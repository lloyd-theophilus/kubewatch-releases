-- +goose Up
-- NULL means "same as license_expires_at" (every recurring license,
-- self-hosted or SaaS-tied, where use and update eligibility lapse
-- together) -- only a perpetual self-hosted license (one-time purchase,
-- see services/billing/selfhost.go) ever sets this apart from
-- license_expires_at. Mirrors services/license's own licenses.update_eligible_until
-- column and the same NULL-defaults-to-expiry convention.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS license_update_eligible_until TIMESTAMPTZ;

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS license_update_eligible_until;
