-- +goose Up
-- Marks which orgs are subject to the "suspend on trial expiry" policy
-- (no more indefinite Free plan -- see services/tenant-mgmt/jobs/trial.go's
-- checkTrialExpiry). New signups get the new behavior by default; every
-- org that already exists at the time this migration runs is explicitly
-- grandfathered onto the old behavior (fall back to Free, keep working)
-- so shipping this doesn't suddenly lock out real, currently-active accounts.
--
-- Guarded to run the backfill only once: this migration runner re-applies
-- every file on every deploy (no applied-migrations tracking) -- an
-- unconditional UPDATE here would reset EVERY org back to false on every
-- subsequent deploy, including brand-new orgs that should get
-- strict_trial = true from the column's own default, permanently undoing
-- the "new signups get the new behavior" policy this migration exists to
-- introduce.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'organizations' AND column_name = 'strict_trial'
  ) THEN
    ALTER TABLE organizations ADD COLUMN strict_trial BOOLEAN NOT NULL DEFAULT true;
    UPDATE organizations SET strict_trial = false;
  END IF;
END $$;

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS strict_trial;
