-- +goose Up
-- Marks which orgs are subject to the "suspend on trial expiry" policy
-- (no more indefinite Free plan -- see services/tenant-mgmt/jobs/trial.go's
-- checkTrialExpiry). New signups get the new behavior by default; every
-- org that already exists at the time this migration runs is explicitly
-- grandfathered onto the old behavior (fall back to Free, keep working)
-- so shipping this doesn't suddenly lock out real, currently-active accounts.
ALTER TABLE organizations ADD COLUMN IF NOT EXISTS strict_trial BOOLEAN NOT NULL DEFAULT true;
UPDATE organizations SET strict_trial = false;

-- +goose Down
ALTER TABLE organizations DROP COLUMN IF EXISTS strict_trial;
