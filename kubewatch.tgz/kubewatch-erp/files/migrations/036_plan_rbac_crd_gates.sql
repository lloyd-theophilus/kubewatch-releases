-- +goose Up
-- Plan gates for RBAC object viewing and CRD instance viewing (Phase 3
-- leftover), mirroring cluster_secrets_enabled (033_plan_secrets_gate.sql).
-- Both reveal potentially sensitive data (RBAC objects: the cluster's
-- security posture; CRD instances: whatever a given CRD happens to store),
-- unlike CRD definitions (schema only), which stay free like ConfigMaps/
-- Deployments and need no gate at all. Independent of each other and of
-- every other cluster_*_enabled flag — a customer may want any combination.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_rbac_view_enabled BOOLEAN NOT NULL DEFAULT false;
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_crd_instances_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_rbac_view_enabled = true, cluster_crd_instances_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_rbac_view_enabled;
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_crd_instances_enabled;
