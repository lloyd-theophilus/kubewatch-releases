-- +goose Up
-- Closes a duplicate-dispatch gap left by the removal of manifest applies'
-- approval step (see services/live-data/manifest_apply.go's
-- rollbackManifestApply): with no admin-approval buffer between "request a
-- rollback" and "dispatch it", nothing previously stopped two overlapping
-- requests (a double-click beating the client's busy-state, or a duplicated
-- POST) from each inserting their own new manifest_applies row and
-- independently dispatching a manifest.rollback command for the SAME
-- original apply. A partial unique index is the only way to close this
-- atomically across concurrent transactions -- a check-then-insert in Go
-- has the exact same race the code it's meant to guard already had.
CREATE UNIQUE INDEX IF NOT EXISTS uq_manifest_applies_active_rollback
    ON manifest_applies (reverts_id)
    WHERE reverts_id IS NOT NULL AND outcome NOT IN ('applied', 'apply_failed', 'denied');

-- +goose Down
DROP INDEX IF EXISTS uq_manifest_applies_active_rollback;
