-- +goose Up
-- Plan gate for RBAC object editing (Role/RoleBinding create/update/delete),
-- distinct from cluster_rbac_view_enabled (036_plan_rbac_crd_gates.sql) --
-- viewing and editing are independent capabilities, same as every other
-- cluster_*_enabled pair in this codebase (e.g. cluster_edit_enabled vs the
-- always-on read side for workloads). Enterprise-only, matching
-- clusterWriteActions/secretsRbacCrd in the marketing pricing plan.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS cluster_rbac_edit_enabled BOOLEAN NOT NULL DEFAULT false;
UPDATE plan_limits SET cluster_rbac_edit_enabled = true WHERE plan = 'enterprise';

-- +goose Down
ALTER TABLE plan_limits DROP COLUMN IF EXISTS cluster_rbac_edit_enabled;
