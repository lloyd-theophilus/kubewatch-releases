-- +goose Up
-- Per-organization SAML 2.0 SSO configuration. Each org pastes its IdP metadata
-- XML; SSO is an Enterprise-plan feature (enforced in the auth service).
CREATE TABLE IF NOT EXISTS sso_configs (
    org_id           TEXT PRIMARY KEY REFERENCES organizations(id),
    enabled          BOOLEAN NOT NULL DEFAULT false,
    idp_metadata_xml TEXT NOT NULL,
    default_role     TEXT NOT NULL DEFAULT 'viewer',
    created_at       TIMESTAMPTZ DEFAULT NOW(),
    updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- +goose Down
DROP TABLE IF EXISTS sso_configs;
