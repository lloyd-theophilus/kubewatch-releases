-- +goose Up
-- Adds page/device/traffic-source breakdown to marketing_traffic_daily
-- (121_marketing_traffic.sql), so the operator console can show which pages
-- are getting traffic and how visitors are arriving, not just a country
-- total. Same model as the existing country column: path, device, and
-- referrer_source are new grouping dimensions on the same "one row per
-- distinct combination, a view increments the counter" table -- there's
-- still no per-event row and no per-visitor identifier of any kind. device
-- and referrer_source are small controlled vocabularies assigned by
-- frontend/marketing's own middleware (mobile/tablet/desktop/unknown, and
-- direct/search/social/referral), never the raw User-Agent or raw referrer
-- URL -- same privacy stance as country's own "verbatim from a bounded
-- CF-IPCountry set, never a raw IP" (see
-- services/tenant-mgmt/marketing_traffic.go). path is just the request
-- pathname.
--
-- The table has zero rows in every environment today, so this could be a
-- plain backfill-free ALTER, but the DEFAULTs below are there anyway so this
-- migration stays correct if that ever stops being true: existing rows get
-- '/' / 'unknown' / 'direct', which folds them into the same buckets the old
-- (day, country)-only data implicitly represented.
ALTER TABLE marketing_traffic_daily
    DROP CONSTRAINT marketing_traffic_daily_pkey,
    ADD COLUMN path TEXT NOT NULL DEFAULT '/',
    ADD COLUMN device TEXT NOT NULL DEFAULT 'unknown',
    ADD COLUMN referrer_source TEXT NOT NULL DEFAULT 'direct',
    ADD PRIMARY KEY (day, country, path, device, referrer_source);

-- +goose Down
ALTER TABLE marketing_traffic_daily
    DROP CONSTRAINT marketing_traffic_daily_pkey,
    DROP COLUMN path,
    DROP COLUMN device,
    DROP COLUMN referrer_source,
    ADD PRIMARY KEY (day, country);
