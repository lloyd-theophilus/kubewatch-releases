-- +goose Up
-- SaaS pricing restructure: Enterprise moves from unlimited agents to a real
-- 50-agent cap (competitor research showed the flat unlimited-agent price
-- has no cost ceiling -- one "agent" can represent an entire unbounded
-- Kubernetes cluster). overage_price_per_agent_cents is a defined, UI-
-- surfaced rate for scaling past the cap; this codebase has no recurring/
-- metered Paystack billing today (checkout is a one-off transaction per
-- period, no Subscription object, no renewal webhook), so nothing auto-
-- charges this yet -- it's for support/sales to invoice against and for
-- customers to see the real cost before they ask.
ALTER TABLE plan_limits ADD COLUMN IF NOT EXISTS overage_price_per_agent_cents INTEGER NOT NULL DEFAULT 0;
UPDATE plan_limits SET max_agents = 50 WHERE plan = 'enterprise';
UPDATE plan_limits SET overage_price_per_agent_cents = 500 WHERE plan = 'enterprise';

-- +goose Down
UPDATE plan_limits SET max_agents = -1, overage_price_per_agent_cents = 0 WHERE plan = 'enterprise';
ALTER TABLE plan_limits DROP COLUMN IF EXISTS overage_price_per_agent_cents;
