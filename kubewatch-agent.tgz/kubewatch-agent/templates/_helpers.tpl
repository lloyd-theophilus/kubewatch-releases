{{/*
Expand the name of the chart.
*/}}
{{- define "kubewatch-agent.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "kubewatch-agent.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "kubewatch-agent.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "kubewatch-agent.labels" -}}
helm.sh/chart: {{ include "kubewatch-agent.chart" . }}
app.kubernetes.io/name: {{ include "kubewatch-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "kubewatch-agent.selectorLabels" -}}
app.kubernetes.io/name: {{ include "kubewatch-agent.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Every RBAC flag kubewatch-rbac-controller knows how to manage
(rbac.managementMode: automatic) -- all 15 optional capabilities this chart
grants, matching services/live-data/rbac_capabilities.go's
pilotedCapabilityFlags exactly, which MUST stay in sync with this list.
Single source of truth for capability-clusterroles.yaml,
clusterrole-rbac-controller.yaml, and capability-admission-policy.yaml, so
the three never drift relative to each other. Excludes
rbac.genericApplyExtraGroups (a per-org, values-driven custom CRD list --
not statically known at template time the way every other flag's grant is,
so it stays a classic Helm-flag-only escape hatch regardless of management
mode) and the always-on baseline grants, neither of which are optional
capabilities with their own toggle.
*/}}
{{- define "kubewatch-agent.pilotedCapabilities" -}}
- allowExec
- allowPortForward
- allowViewSecrets
- allowEditWorkloads
- allowDeletePods
- allowDeleteWorkloads
- allowViewRBAC
- allowGenericApply
- allowHelmLifecycle
- allowHelmManagesRBAC
- allowEditRBAC
- allowAutonomousRollback
- allowDeleteNamespaces
- allowClusterBackup
- allowCordonDrainNodes
{{- end }}

{{/*
The ClusterRole (and identically-named ClusterRoleBinding) name for one
piloted capability flag. Takes a dict with "root" (the top-level context, for
fullname) and "flag" (the capability flag name).
*/}}
{{- define "kubewatch-agent.capabilityRoleName" -}}
{{- printf "%s-cap-%s" (include "kubewatch-agent.fullname" .root) .flag | lower }}
{{- end }}
